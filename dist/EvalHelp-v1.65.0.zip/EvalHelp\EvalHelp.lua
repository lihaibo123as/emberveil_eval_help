-- EvalHelp 1.65.0 —— 全职业施法工具：通用一键宏（条件规则引擎） + 状态日志 + 战斗信息UI + 配置窗口
--   1.25.0: 新增条件类型「选取目标」（TargetNearestEnemy 等 7 种，官方 Targetting API）；编辑窗类型下拉 24 种
--   1.26.0: 新增条件类型「目标职业」（UnitClass 英文 token 比对，编辑窗多选下拉=或关系；文本格式 目标职业:战士/法师）
--   1.31.0: 目标debuff层数条件（UnitDebuff 第二返回值入 st.targetDebuffs[tex]=层数，非堆叠归一1；
--           有debuff:名>=N / 无debuff:名<N；编辑窗 debuff 条件行加「层」下拉 不限/2-5层）
--   1.30.0: 特殊技能「宠物指令」（rule.skill=宠物:攻击 等 8 种，不占动作条直调 Pet API；EVAL_RULE_RUN/wuse 豁免动作条检查；
--           图标 wicon 兜底 GetPetIcon/问号；战斗信息UI亮金放行；技能下拉追加宠物段；刻意不含放弃/改名/兽栏系）
--   1.29.0: 选取目标扩展「目标的目标」(TargetUnit targettarget) 与「指定名称」(TargetByName，cd.nm 存名)；
--           编辑窗名称下拉=最近5敌名(循环枚举EVAL_NEARBY_ENEMY_NAMES)+自定义输入弹窗EVAL_TN_OPEN；文本 选取目标:指定名称:名
--   1.28.0: 新增条件类型「连击点数」（GetComboPoints，盗贼/德鲁伊专用，数值比较型；文本格式 连击>=3）
--   1.27.0: 光环类条件下拉追加实时项（◆当前目标debuff/○当前自身buff，GameTooltip SetUnitDebuff/SetPlayerBuff 读名）；
--           名称→纹理即时学习持久化 cfg.war.debuffTex，texOf 学习表回退——非动作条光环也能做 有/无debuff/buff 比对
--
-- 参考 OneJudge 开发流程的关键约定：
--   1) 目录规则：Interface/AddOns/EvalHelp/EvalHelp.toc（文件夹名 == toc 基名）
--   2) 插件暴露全局函数，一键宏正文就一行：/run EVAL_HELP()
--   3) 本客户端判断函数返回 true/false/nil（不是老 1.12 的 1/nil），必须宽松真值判断，
--      旧写法 UnitAffectingCombat("player") == 1 在 true 面前永远判假！
--   4) 配置用 SavedVariables（EVAL_HELP_CONFIG），要等 VARIABLES_LOADED 事件后才读。
--   5) 聊天输出用 DEFAULT_CHAT_FRAME:AddMessage；写日志文件用 Azeroth 专有 UELog()
--      （日志在 %LOCALAPPDATA%\Azeroth\Saved\Logs 下，不刷聊天框）。
--   6) 本客户端没有 /startattack、/castsequence；插件不能调 Protected 函数
--      （CastSpellByName 等），施法走 UseAction(动作条格子)。
--
-- 用法（/eh help 随时查看）：
--   一键宏：游戏内新建宏，正文一行  /run EVAL_GO()   拖到按键上连按（全职业通用框架）
--     前置：把 攻击/战斗姿态/冲锋/压制/断筋/撕裂/战斗怒吼/血性狂暴/猛击/英勇打击 拖上动作条，
--           然后 /eh war rescan 让插件识别槽位（/eh war 查看识别结果）
--     猛击需按住 Alt 再按宏键（本客户端无挥击计时 API，用 Alt 代替出手时机）
--   配置：小地图左侧金色 EH 图标 或 /eh cfg —— 日志开关、一键开关、怒气/血量阈值滑条
--   战斗信息UI：/eh ui —— 血/能量/目标条 + 技能图标行，按住标题栏拖动，滚轮缩放
--   状态信息UI：/eh st —— Cat 式角色状态变量总览（EVAL_HELP_STATE 实时值）
--   其他命令：/eh 输出状态日志 | /eh log 写日志开关 | /eh auto 进出战斗自动输出
--   日志文件：%LOCALAPPDATA%\Azeroth\Saved\Logs（/eh wdebug 后聊天框同步显示决策原因）

local VERSION = "1.65.0"
local cfg = nil -- VARIABLES_LOADED 后指向 EVAL_HELP_CONFIG

-- ===== 跨模块别名（Core.lua / Engine.lua 先于本文件加载，见 toc） =====
local say, logLine = EVAL_SAY, EVAL_LOGLINE
local L = EVAL_L
local st = EVAL_HELP_STATE
local uiOffscreen = EVAL_UIOFFSCREEN
local powerLabel, currentForm = EVAL_POWERLABEL, EVAL_CURRENTFORM
local formatStats, collectStats = EVAL_FORMAT_STATS, EVAL_COLLECT_STATS
local autoFrame, onCombatEvent = EVAL_AUTOFRAME, EVAL_ON_COMBAT
local ehResolveLang = EVAL_RESOLVE_LANG
local wslots = EVAL_WSLOTS
local wicon = EVAL_WICON
local groupsOK = EVAL_GROUPS_OK
local auraTexOf = EVAL_AURA_TEX
local petCmdOf, targetSelOf, itemOf = EVAL_PET_OF, EVAL_TGT_OF, EVAL_ITEM_OF
local stanceOf = EVAL_STANCE_OF -- 1.43.0 姿态切换（姿态:名称）
local condTrim = EVAL_COND_TRIM -- 1.44.0 拆分漏桥补：EVAL_PROFILE_FROM_TEXT 用裸 condTrim（旧例一直缺别名，游戏内点导入必炸）
local cancelCastOf = EVAL_CANCELCAST_OF -- 1.47.0 取消施法特殊行为
local TARGET_SEL, TARGET_SEL_NAME = EVAL_TARGET_SEL, EVAL_TSEL_NAME
local CLASS_LIST = EVAL_CLASS_LIST
-- ============ 状态 UI（参考 Cat 的 CatUI-Melee 布局，构件法用 OneJudge HUD 的已验证写法） ============
-- /eh ui 开关窗口；按住顶部标题栏拖动换位置（自动记忆）；悬停滚轮缩放（0.5~1.6，自动重建）。
-- 内容：血条 / 能量条（怒气红·法力蓝·能量黄）/ 目标条 / 状态行 / 技能图标行。
-- 刷新：OnUpdate 每 0.15s 一次，窗口隐藏时不刷新（Cat 的 MPCatUIMeleeRun 同款节流）。
-- 注意（OneJudge 实测教训）：不用 SetScale（会引发命中区/位置漂移），缩放 = 几何尺寸 × 系数后重建；
--      不用 StatusBar 控件，用纯色 Texture 按宽度填充；字体按 FZLBJW→FRIZQT→ARIALN 顺序尝试。

local ui = { root = nil }
local UI_TICK = 0.15
local uiLastTick = 0

local function uiCfg()
  if not cfg then cfg = EVAL_HELP_CONFIG or {}; EVAL_HELP_CONFIG = cfg end
  if not cfg.ui then cfg.ui = { enabled = false, x = 0, y = -180, scale = 1 } end
  return cfg.ui
end

-- 纯色纹理：SetTexture(RGB) 本客户端未文档化，先按颜色试，失败退回官方底图+顶点色（OneJudge 同款）
local function uiSolid(t, r, g, b, a)
  local ok = pcall(t.SetTexture, t, r, g, b)
  if not ok then
    pcall(t.SetTexture, t, "Interface\\Buttons\\WHITE8X8")
    pcall(t.SetVertexColor, t, r, g, b, a or 1)
  end
end

-- 字体字符串：中文字体优先（FZLBJW=方正隶变），失败逐级回退
-- 1.61.2 显示转义：| 在 FontString/聊天框里是颜色转义符，单个 | 会被吞；|| 转义在本客户端渲染异常（小方块）——
-- 改用全角竖线 ｜（U+FF5C，FZLBJW 中文字体自带全角字符，视觉与 | 一致）。数据层不受影响
local function uiEsc(s) return (string.gsub(tostring(s or ""), "|", "｜")) end

local function uiText(parent, size, r, g, b)
  local fs = parent:CreateFontString(nil, "OVERLAY", "GameFontNormalSmall")
  local set = false
  for _, fp in ipairs({ "Fonts\\FZLBJW.TTF", "Fonts\\FRIZQT__.TTF", "Fonts\\ARIALN.TTF" }) do
    local okF, ok2 = pcall(fs.SetFont, fs, fp, size, "OUTLINE")
    if not (okF and ok2) then okF, ok2 = pcall(fs.SetFont, fs, fp, size) end
    if okF and ok2 then set = true break end
  end
  if not set then pcall(fs.SetTextHeight, fs, size) end
  fs:SetTextColor(r, g, b)
  return fs
end

-- 一条状态条：深色底框 + 彩色填充层（宽度=比例）+ 居中文字
local function uiMakeBar(parent, w, h)
  local bar = CreateFrame("Frame", nil, parent)
  bar:SetWidth(w) bar:SetHeight(h)
  local bg = bar:CreateTexture(nil, "BACKGROUND")
  uiSolid(bg, 0.08, 0.08, 0.10, 0.9)
  bg:SetPoint("TOPLEFT", bar, "TOPLEFT", 0, 0)
  bg:SetPoint("BOTTOMRIGHT", bar, "BOTTOMRIGHT", 0, 0)
  local fill = bar:CreateTexture(nil, "ARTWORK")
  uiSolid(fill, 0.5, 0.5, 0.5, 1)
  fill:SetPoint("TOPLEFT", bar, "TOPLEFT", 1, -1)
  fill:SetHeight(h - 2)
  pcall(fill.SetWidth, fill, 1)
  local text = uiText(bar, math.max(8, h - 6), 1, 1, 1)
  text:SetPoint("CENTER", bar, "CENTER", 0, 0)
  return bar, fill, text, w - 2
end

-- 技能图标行（1.45.0 起）：内容以【激活方案的技能】为准，旧版固定战士清单（UI_ICONS）已废弃

-- 方案配置访问（配置段的 warCfg 在本段之后定义，这里直接走全局 SavedVariables + 迁移函数）
local function uiWarCfg()
  local cc = EVAL_HELP_CONFIG
  if type(cc) ~= "table" then cc = {} EVAL_HELP_CONFIG = cc end
  if type(cc.war) ~= "table" then cc.war = {} end
  EVAL_WAR_ENSURE_PROFILES(cc.war)
  return cc.war
end

-- 当前方案第 i 条规则（技能编辑窗/方案技能行共用）
local function uiWarActiveRule(i)
  local w2 = uiWarCfg()
  local p = w2.profiles and w2.profiles[w2.activeProfile or 1]
  return (p and p.skills) and p.skills[i] or nil
end

-- 重建/新建战斗信息UI（改缩放时整帧重建，见上方 SetScale 说明）
function EVAL_HELP_UI_BUILD()
  local u = uiCfg()
  local z = (type(u.scale) == "number" and u.scale >= 0.4) and u.scale or 1
  if ui.root then
    ui.root:Hide()
    pcall(ui.root.SetScript, ui.root, "OnUpdate", nil)
  end

  local root = CreateFrame("Frame", "EVAL_HELP_UI", UIParent)
  pcall(root.SetFrameStrata, root, "MEDIUM")
  pcall(root.SetFrameLevel, root, 10)
  pcall(root.EnableMouse, root, true)   -- 本体只接收滚轮（缩放），不注册拖动
  pcall(root.SetMovable, root, true)

  local W = math.floor(240 * z)
  local pad = math.floor(8 * z)
  local barH = math.floor(14 * z)
  local gap = math.floor(4 * z)
  local cell = math.floor(26 * z)

  -- 标题栏 = 拖动手柄：只有按住标题条才能拖动窗口（需求 1）。
  -- UnrealQuest 实测五件套：Handle 必须是【Button】（Frame 的拖拽在本客户端不触发）、
  -- SetFrameLevel 抬高 +10（用 strata 抬高是记录在案的失败做法）、EnableMouse、
  -- RegisterForClicks、RegisterForDrag。
  local titleBarH = math.floor(16 * z)
  local titleBar = CreateFrame("Button", nil, root)
  -- 标题条与内容条同宽（内缩 pad；1.20.1 修复标题条两边超出内容区的问题）
  titleBar:SetPoint("TOPLEFT", root, "TOPLEFT", pad, 0)
  titleBar:SetPoint("TOPRIGHT", root, "TOPRIGHT", -pad, 0)
  titleBar:SetHeight(titleBarH)
  local okLvl, rootLvl = pcall(root.GetFrameLevel, root)
  if okLvl and type(rootLvl) == "number" then
    pcall(titleBar.SetFrameLevel, titleBar, rootLvl + 10)
  end
  pcall(titleBar.RegisterForClicks, titleBar, "LeftButtonUp")
  local tbBg = titleBar:CreateTexture(nil, "BACKGROUND")
  uiSolid(tbBg, 0.16, 0.13, 0.08, 0.95)
  tbBg:SetPoint("TOPLEFT", titleBar, "TOPLEFT", 0, 0)
  tbBg:SetPoint("BOTTOMRIGHT", titleBar, "BOTTOMRIGHT", 0, 0)
  pcall(titleBar.EnableMouse, titleBar, true)
  pcall(titleBar.RegisterForDrag, titleBar, "LeftButton")
  local title = uiText(titleBar, math.max(9, math.floor(11 * z)), 0.9, 0.8, 0.4)
  title:SetPoint("CENTER", titleBar, "CENTER", 0, 0)
  title:SetText("战斗信息")

  -- 三条状态条：血 / 能量 / 目标
  local y = titleBarH + gap
  local barW = W - pad * 2
  local hpBar, hpFill, hpText, hpW = uiMakeBar(root, barW, barH)
  hpBar:SetPoint("TOPLEFT", root, "TOPLEFT", pad, -y)
  y = y + barH + gap
  local pwBar, pwFill, pwText, pwW = uiMakeBar(root, barW, barH)
  pwBar:SetPoint("TOPLEFT", root, "TOPLEFT", pad, -y)
  y = y + barH + gap
  local tgBar, tgFill, tgText, tgW = uiMakeBar(root, barW, barH)
  tgBar:SetPoint("TOPLEFT", root, "TOPLEFT", pad, -y)
  y = y + barH + gap

  -- 状态行：战斗状态 · 姿态 · 普攻
  local status = uiText(root, math.max(8, math.floor(10 * z)), 0.75, 0.75, 0.75)
  -- 施法读条（1.38.1）：目标条下方细条，仅读条中显示（进度=剩余/总时长，反向填充=正在消耗的时间）
  local castBar, castFill, castText, castW = uiMakeBar(root, barW, math.max(6, math.floor(8 * z)))
  castBar:SetPoint("TOPLEFT", root, "TOPLEFT", pad, -y)
  y = y + math.max(6, math.floor(8 * z)) + gap
  ui.castBar, ui.castFill, ui.castText, ui.castW = castBar, castFill, castText, castW
  -- 挥击计时条（1.55.0）：读条下方细条——进度=距下次挥击（自学习锚点+攻速），金色
  local swBar, swFill, swText, swW = uiMakeBar(root, barW, math.max(6, math.floor(8 * z)))
  swBar:SetPoint("TOPLEFT", root, "TOPLEFT", pad, -y)
  y = y + math.max(6, math.floor(8 * z)) + gap
  ui.swingBar, ui.swingFill, ui.swingText, ui.swingW = swBar, swFill, swText, swW
  status:SetPoint("TOPLEFT", root, "TOPLEFT", pad, -y)
  y = y + math.floor(13 * z) + gap

  -- 方案切换行：点击按钮换激活方案（一键宏立即换套路；Shift+按宏 / /eh war next 也可切）
  -- 1.56.0 自适应布局：行宽与上方状态条对齐（右缘一致）；方案多时自动换行——
  -- 第 1 行（带「方案」标签）与后续行各自按可用宽装满，每行按钮拉伸填满整行
  local profBtns = {}
  local w20 = uiWarCfg()
  local nProf = (w20.profiles and table.getn(w20.profiles)) or 1
  local labelW = math.floor(28 * z)
  local btnH = math.floor(15 * z)
  local barAvailW = W - pad * 2
  local minBW = math.floor(34 * z) -- 单按钮最小宽（名字可读）
  local plabel = uiText(root, math.max(8, math.floor(9 * z)), 0.95, 0.82, 0.35)
  plabel:SetPoint("TOPLEFT", root, "TOPLEFT", pad, -(y + math.floor(3 * z)))
  plabel:SetText("方案")
  local perRow0 = math.max(1, math.floor((barAvailW - labelW + 2) / (minBW + 2))) -- 首行容量（扣标签）
  local perRowN = math.max(1, math.floor((barAvailW + 2) / (minBW + 2)))           -- 后续行容量
  local remP = math.max(0, nProf - perRow0)
  local rows = 1 + ((remP > 0) and math.ceil(remP / perRowN) or 0)
  local k0 = math.max(1, math.min(nProf, perRow0))
  local bw0 = math.floor((barAvailW - labelW - (k0 - 1) * 2) / k0) -- 首行按钮宽（填满）
  -- 1.58.1 修第二排宽度异常：后续行按钮宽按【整行容量】计算——不满的行保持同宽左对齐，不再按剩余数拉伸
  local bwN = math.floor((barAvailW - (perRowN - 1) * 2) / perRowN)
  for i = 1, 12 do
    local row0, col0, x0, bw0i
    if i <= perRow0 then
      row0, col0, x0, bw0i = 0, i - 1, pad + labelW + (i - 1) * (bw0 + 2), bw0
    else
      local j = i - perRow0
      row0 = 1 + math.floor((j - 1) / perRowN)
      col0 = (j - 1) - (row0 - 1) * perRowN
      x0, bw0i = pad + col0 * (bwN + 2), bwN
    end
    local pb = CreateFrame("Button", nil, root)
    pb:SetWidth(bw0i) pb:SetHeight(btnH)
    pb:SetPoint("TOPLEFT", root, "TOPLEFT", x0, -(y + row0 * (btnH + 2)))
    pcall(pb.EnableMouse, pb, true)
    pcall(pb.RegisterForClicks, pb, "LeftButtonUp")
    local pbg = pb:CreateTexture(nil, "BACKGROUND")
    uiSolid(pbg, 0.16, 0.13, 0.08, 1)
    pbg:SetPoint("TOPLEFT", pb, "TOPLEFT", 0, 0)
    pbg:SetPoint("BOTTOMRIGHT", pb, "BOTTOMRIGHT", 0, 0)
    local pt = uiText(pb, math.max(7, math.floor(9 * z)), 0.85, 0.80, 0.70)
    pt:SetPoint("CENTER", pb, "CENTER", 0, 0)
    local pidx = i
    pb:SetScript("OnClick", function()
      local w2 = uiWarCfg()
      if w2.profiles and w2.profiles[pidx] then
        w2.activeProfile = pidx
        say("切换到方案: " .. tostring(w2.profiles[pidx].name))
      end
    end)
    profBtns[i] = { btn = pb, bg = pbg, text = pt }
  end
  y = y + rows * (btnH + 2) + gap -- 1.56.0 多行高度

  -- 技能图标带（1.46.0 两行合一：内容=激活方案技能，8 格/行超过自动换第二行，最多 16 格；
  -- 悬停 tooltip 看触发条件；点击开编辑窗；亮金=条件当前满足；动作条技能带冷却倒数）
  local profCells = {}
  local pcell = math.floor(24 * z)
  local pgap2 = math.floor(3 * z)
  for i = 1, 16 do
    local row0 = math.floor((i - 1) / 8)
    local col0 = (i - 1) - row0 * 8
    local px = pad + col0 * (pcell + pgap2)
    local cb = CreateFrame("Button", nil, root)
    cb:SetWidth(pcell) cb:SetHeight(pcell)
    cb:SetPoint("TOPLEFT", root, "TOPLEFT", px, -(y + row0 * (pcell + pgap2)))
    pcall(cb.EnableMouse, cb, true)
    pcall(cb.RegisterForClicks, cb, "LeftButtonUp")
    local cbg = cb:CreateTexture(nil, "BACKGROUND")
    uiSolid(cbg, 0.45, 0.38, 0.15, 1)
    cbg:SetPoint("TOPLEFT", cb, "TOPLEFT", 0, 0)
    cbg:SetPoint("BOTTOMRIGHT", cb, "BOTTOMRIGHT", 0, 0)
    local cicon = cb:CreateTexture(nil, "ARTWORK")
    uiSolid(cicon, 0.2, 0.2, 0.2, 1)
    cicon:SetPoint("TOPLEFT", cb, "TOPLEFT", 1, -1)
    cicon:SetPoint("BOTTOMRIGHT", cb, "BOTTOMRIGHT", -1, 1)
    local ctext = uiText(cb, math.max(7, math.floor(9 * z)), 1, 1, 0.4)
    ctext:SetPoint("CENTER", cb, "CENTER", 0, 0)
    local ci = i
    cb:SetScript("OnEnter", function()
      local r = uiWarActiveRule(ci)
      if not r then return end
      GameTooltip:SetOwner(cb, "ANCHOR_RIGHT")
      GameTooltip:AddLine(tostring(r.skill), 1, 0.82, 0.3)
      GameTooltip:AddLine((r.enabled ~= false) and ("|cff00ff00" .. L("TIP_ON") .. "|r") or ("|cffff0000" .. L("TIP_OFF") .. "|r"))
      GameTooltip:AddLine(L("TIP_COND_H"), 0.62, 0.55, 0.40)
      local gcount = 0
      for gi, g in ipairs(r.groups or {}) do
        gcount = gi
        local cs = {}
        for _, cd in ipairs(g) do table.insert(cs, EVAL_COND_STR(cd)) end
        GameTooltip:AddLine(string.format("%d. %s", gi, table.concat(cs, " & ")), 0.85, 0.85, 0.85)
      end
      if gcount == 0 then
        GameTooltip:AddLine(L("TIP_NOCOND"), 0.6, 0.6, 0.6)
      end
      GameTooltip:AddLine(L("TIP_CLICK"), 0.5, 0.5, 0.5)
      GameTooltip:Show()
    end)
    cb:SetScript("OnLeave", function() GameTooltip:Hide() end)
    cb:SetScript("OnClick", function()
      local w2 = uiWarCfg()
      local p = w2.profiles and w2.profiles[w2.activeProfile or 1]
      if p and p.skills[ci] then EVAL_HELP_SE_OPEN(w2.activeProfile or 1, ci) end
    end)
    profCells[i] = { btn = cb, bg = cbg, icon = cicon, text = ctext }
  end
  y = y + 2 * (pcell + pgap2) + pad -- 固定预留两行高度（空位刷新时整格隐藏，窗口尺寸稳定）

  root:SetWidth(W)
  root:SetHeight(y)
  root:ClearAllPoints()
  root:SetPoint("CENTER", UIParent, "CENTER", u.x or 0, u.y or -180)
  if uiOffscreen(root) then -- 记忆位置飞出屏幕 → 回归视野中心
    root:ClearAllPoints()
    root:SetPoint("CENTER", UIParent, "CENTER", 0, -180)
    u.x, u.y = 0, -180
  end

  -- 按住标题栏拖动换位置，松手记坐标（GetCenter 已含 effectiveScale，要除回去——OneJudge 1.7.2 的修复）
  titleBar:SetScript("OnDragStart", function()
    pcall(root.SetMovable, root, true)
    pcall(root.StartMoving, root)          -- warm-up 两步（UnrealQuest StartFrameDrag 实测配方）
    pcall(root.StopMovingOrSizing, root)
    pcall(root.StartMoving, root)
  end)
  titleBar:SetScript("OnDragStop", function()
    pcall(root.StopMovingOrSizing, root)
    local ok, cx, cy = pcall(root.GetCenter, root)
    if ok and cx then
      local okw, w2 = pcall(UIParent.GetWidth, UIParent)
      local okh, h2 = pcall(UIParent.GetHeight, UIParent)
      if okw and okh and w2 and h2 then
        local oke, es = pcall(root.GetEffectiveScale, root)
        local k = (oke and type(es) == "number" and es > 0) and es or 1
        u.x = (cx - w2 / 2) / k
        u.y = (cy - h2 / 2) / k
      end
    end
  end)

  -- 悬停滚轮缩放（EnableMouseWheel 本客户端可能缺，全程 pcall——OneJudge 1.7.2 教训）
  if pcall(root.EnableMouseWheel, root, true) then
    pcall(root.SetScript, root, "OnMouseWheel", function(a, b)
      local d = 0
      if type(b) == "number" then d = b
      elseif type(a) == "number" then d = a
      elseif type(arg1) == "number" then d = arg1 end
      if d == 0 then return end
      local s = (u.scale or 1) + (d > 0 and 0.1 or -0.1)
      s = math.min(1.6, math.max(0.5, s))
      if math.abs(s - (u.scale or 1)) > 1e-9 then
        u.scale = s
        EVAL_HELP_UI_BUILD()
        if ui.root then ui.root:Show() end
      end
    end)
  end

  ui.root, ui.title = root, title
  ui.hpFill, ui.hpText, ui.hpW = hpFill, hpText, hpW
  ui.pwFill, ui.pwText, ui.pwW = pwFill, pwText, pwW
  ui.tgBar, ui.tgFill, ui.tgText, ui.tgW = tgBar, tgFill, tgText, tgW
  -- 目标距离文本（1.37.0）：目标条右缘（近战/冲锋距/远程外，EVAL_T_RANGE 分档）
  local tgRange = uiText(tgBar, math.max(8, math.floor(9 * z)), 1, 0.85, 0.4)
  tgRange:SetPoint("RIGHT", tgBar, "RIGHT", -4, 0)
  pcall(tgRange.SetJustifyH, tgRange, "RIGHT")
  ui.tgRange = tgRange
  ui.status = status
  ui.profBtns, ui.profCells = profBtns, profCells -- 1.46.0 技能带=profCells（两行合一，ui.cells 已废）

  root:SetScript("OnUpdate", function()
    local now = GetTime()
    if now - uiLastTick < UI_TICK then return end
    uiLastTick = now
    EVAL_HELP_UI_TICK()
  end)
end

-- 填充条刷新工具
local function uiSetBar(fill, text, maxW, frac, r, g, b, str)
  if frac < 0 then frac = 0 elseif frac > 1 then frac = 1 end
  pcall(fill.SetWidth, fill, math.max(1, maxW * frac))
  pcall(fill.SetVertexColor, fill, r, g, b, 1)
  text:SetText(str)
end

-- 每个心跳刷新（窗口隐藏时直接返回——Cat 同款）
function EVAL_HELP_UI_TICK()
  if not ui.root or not ui.root:IsVisible() then return end

  -- 统一走角色状态表（每次心跳刷新一次，之后只读变量——Cat 思路）
  EVAL_HELP_UPDATE_STATE()

  -- 血条：绿→红渐变
  local hfrac = (st.hpMax and st.hpMax > 0) and (st.hp / st.hpMax) or 0
  uiSetBar(ui.hpFill, ui.hpText, ui.hpW, hfrac, 1 - hfrac, hfrac, 0.15,
    string.format("%d/%d  %d%%", st.hp, st.hpMax, math.floor(hfrac * 100 + 0.5)))

  -- 能量条：按能量类型配色（0法力蓝 1怒气红 2集中橙 3能量黄）
  local pfrac = (st.powerMax and st.powerMax > 0) and (st.power / st.powerMax) or 0
  local pr, pg, pb = 0.25, 0.45, 0.90
  if st.powerType == 1 then pr, pg, pb = 0.90, 0.20, 0.25
  elseif st.powerType == 2 then pr, pg, pb = 0.90, 0.50, 0.20
  elseif st.powerType == 3 then pr, pg, pb = 1.00, 1.00, 0.40 end
  uiSetBar(ui.pwFill, ui.pwText, ui.pwW, pfrac, pr, pg, pb,
    string.format("%s %d/%d", powerLabel(), st.power, st.powerMax))

  -- 目标条
  if ui.tgRange then ui.tgRange:SetText(st.tRange or "") end -- 1.37.0 目标条右侧距离
  -- 1.38.1 施法读条：读条中=蓝底反向消耗进度+技能名+剩余秒；无读条=空条
  if ui.castBar then
    if st.castName then
      local total = (st.castStart and st.castUntil) and (st.castUntil - st.castStart) or 0
      local frac = (total > 0) and math.max(0, math.min(1, (st.castUntil - GetTime()) / total)) or 1
      uiSetBar(ui.castFill, ui.castText, ui.castW, frac, 0.25, 0.45, 0.85,
        tostring(st.castName) .. (st.castUntil and string.format(" %.1fs", math.max(0, st.castUntil - GetTime())) or ""))
    else
      uiSetBar(ui.castFill, ui.castText, ui.castW, 0, 0.1, 0.1, 0.1, "")
    end
  end
  -- 1.55.0 挥击计时条：有攻速+锚点数据时显示（进度=已过/攻速，文本=距下次攻击秒数/就绪）
  if ui.swingBar then
    local rem = EVAL_SWING_REMAIN and EVAL_SWING_REMAIN()
    if rem and st.atkSpd and st.atkSpd > 0 then
      local frac = math.max(0, math.min(1, 1 - rem / st.atkSpd))
      uiSetBar(ui.swingFill, ui.swingText, ui.swingW, frac, 0.85, 0.70, 0.25,
        rem > 0.05 and string.format("下次攻击 %.1fs", rem) or "攻击就绪")
    else
      uiSetBar(ui.swingFill, ui.swingText, ui.swingW, 0, 0.1, 0.1, 0.1, "")
    end
  end
  if st.hasTarget then
    local tfrac = st.tHpPct / 100
    uiSetBar(ui.tgFill, ui.tgText, ui.tgW, tfrac, 0.80, 0.20, 0.20,
      string.format("%s  %d%%", tostring(st.targetName), math.floor(tfrac * 100 + 0.5)))
  else
    uiSetBar(ui.tgFill, ui.tgText, ui.tgW, 0, 0.3, 0.3, 0.3, "无目标")
  end

  -- 状态行
  local inCombat = st.inCombat
  local form = st.form or "无姿态"
  local atkOn = false
  if wslots["攻击"] and type(IsCurrentAction) == "function" then
    local oka, cur = pcall(IsCurrentAction, wslots["攻击"].slot)
    atkOn = oka and cur and true or false
  end
  st.autoAttack = atkOn -- 同步进状态表（Cat 的 MPAutoAttack）
  ui.status:SetText(string.format("%s · %s · 普攻:%s",
    inCombat and "|cffff5040战斗中|r" or "|cff80ff80非战斗|r",
    form, atkOn and "|cff00ff00开|r" or "|cff909090关|r"))

  -- 方案切换行：当前激活金色高亮，不存在的方案位隐藏
  if ui.profBtns then
    local w2 = uiWarCfg()
    for i, pb in ipairs(ui.profBtns) do
      local prof = w2.profiles and w2.profiles[i]
      if prof then
        pb.btn:Show()
        pb.text:SetText(tostring(prof.name or i))
        local sel = (w2.activeProfile or 1) == i
        pcall(pb.bg.SetVertexColor, pb.bg, sel and 0.45 or 0.16, sel and 0.35 or 0.13, sel and 0.10 or 0.08, 1)
        pcall(pb.text.SetTextColor, pb.text, sel and 1 or 0.72, sel and 0.9 or 0.68, sel and 0.4 or 0.55)
      else
        pb.btn:Hide()
      end
    end
  end

  -- 技能图标带（1.46.0 两行合一）：亮金=条件当前满足，半暗=不满足，灰+停=已停用；动作条技能带冷却倒数
  if not EVAL_IS_SCANNED() then EVAL_GO_RESCAN(true) end
  if ui.profCells then
    for i, pc in ipairs(ui.profCells) do
      local r = uiWarActiveRule(i)
      if not r then
        pc.btn:Hide()
      else
        pc.btn:Show()
        local s = wslots[r.skill]
        local t0 = wicon(r.skill)
        if t0 then pcall(pc.icon.SetTexture, pc.icon, t0) end
        local enabled = r.enabled ~= false
        local pass = false
        if enabled and (s or petCmdOf(r.skill) or targetSelOf(r.skill) or itemOf(r.skill) or stanceOf(r.skill) or cancelCastOf(r.skill)) and r.groups then -- 宠物/选取目标/物品/姿态/取消施法不占动作条也参与亮金（1.30.0~1.47.0）
          local okp = groupsOK(r, true) -- dry: 亮金预览不触发选取目标等副作用
          pass = okp and true or false
        end
        if not enabled then
          pcall(pc.icon.SetVertexColor, pc.icon, 0.25, 0.25, 0.25)
          pc.text:SetText("停")
        elseif not s and not petCmdOf(r.skill) and not targetSelOf(r.skill) and not itemOf(r.skill) and not stanceOf(r.skill) and not cancelCastOf(r.skill) then -- 特殊技能不占动作条不算缺失（1.30.0~1.47.0）
          pcall(pc.icon.SetVertexColor, pc.icon, 0.35, 0.35, 0.35)
          pc.text:SetText("?")
        else
          -- 冷却倒数（仅动作条技能；1.46.0 自旧图标行并入）
          local left = 0
          if s then
            local okc, cst, dur = pcall(GetActionCooldown, s.slot)
            if okc and type(cst) == "number" and type(dur) == "number" and cst > 0 and dur > 0 then
              left = cst + dur - GetTime()
            end
          end
          if left > 0 then
            pc.text:SetText(left >= 10 and string.format("%d", math.floor(left + 0.5)) or string.format("%.1f", left))
            pcall(pc.icon.SetVertexColor, pc.icon, 0.4, 0.4, 0.4)
          elseif pass then
            pcall(pc.icon.SetVertexColor, pc.icon, 1, 1, 1)
            pc.text:SetText("")
          else
            pcall(pc.icon.SetVertexColor, pc.icon, 0.55, 0.55, 0.55)
            pc.text:SetText("")
          end
        end
        if pass and enabled then
          pcall(pc.bg.SetVertexColor, pc.bg, 1, 0.85, 0.3, 1) -- 条件满足：亮金描边
        else
          pcall(pc.bg.SetVertexColor, pc.bg, 0.45, 0.38, 0.15, 1)
        end
      end
    end
  end
end

-- /eh ui 开关
function EVAL_HELP_UI_TOGGLE()
  local u = uiCfg()
  if ui.root and ui.root:IsVisible() then
    ui.root:Hide()
    u.enabled = false
    say("战斗信息UI: |cffff0000关|r")
  else
    EVAL_HELP_UI_BUILD()
    if ui.root then ui.root:Show() end
    u.enabled = true
    say("战斗信息UI: |cff00ff00开|r（按住标题栏拖动换位置，滚轮缩放）")
  end
end

-- ============ 配置窗口 + 小地图图标（参考 UnrealQuest 设置面板：深底金边 + 金框勾选 + 滑条 + 底部关闭） ============
-- 打开方式：小地图左侧金色「EH」图标，或 /eh cfg。改动即时写入 EVAL_HELP_CONFIG（SavedVariables 自动存档）。
-- 窗口按 UnrealQuest 的实测构件法：纯色纹理(WHITE8X8)+金边、自绘勾选框/滑条，不依赖任何客户端贴图/模板/Slider 控件。

local cfgWin = { root = nil, refresh = nil }
local EVAL_WLASTHINT = 0

local function c()
  if not cfg then cfg = EVAL_HELP_CONFIG or {}; EVAL_HELP_CONFIG = cfg end
  return cfg
end

local function warCfg()
  local cc = c()
  if not cc.war then
    cc.war = { enabled = true, attack = true } -- 1.48.0 战士阈值缺省已随默认方案一起清理
  end
  EVAL_WAR_ENSURE_PROFILES(cc.war) -- 方案数据迁移（缺省生成默认方案）
  return cc.war
end

-- 金框勾选框（参考截图的方形金框 checkbox）：Button + 外金框 + 内暗底 + 打勾金色块
local function cfgCheck(parent, x, y, label, get, set, list, tip) -- 1.50.0 可选 tip=悬停提示
  local b = CreateFrame("Button", nil, parent)
  b:SetWidth(16) b:SetHeight(16)
  b:SetPoint("TOPLEFT", parent, "TOPLEFT", x, y)
  pcall(b.EnableMouse, b, true)
  pcall(b.RegisterForClicks, b, "LeftButtonUp")
  local outer = b:CreateTexture(nil, "BACKGROUND")
  uiSolid(outer, 0.85, 0.70, 0.20, 1)
  outer:SetPoint("TOPLEFT", b, "TOPLEFT", 0, 0)
  outer:SetPoint("BOTTOMRIGHT", b, "BOTTOMRIGHT", 0, 0)
  local inner = b:CreateTexture(nil, "ARTWORK")
  uiSolid(inner, 0.10, 0.09, 0.06, 1)
  inner:SetPoint("TOPLEFT", b, "TOPLEFT", 1, -1)
  inner:SetPoint("BOTTOMRIGHT", b, "BOTTOMRIGHT", -1, 1)
  local mark = b:CreateTexture(nil, "OVERLAY")
  uiSolid(mark, 0.95, 0.80, 0.25, 1)
  mark:SetPoint("TOPLEFT", b, "TOPLEFT", 3, -3)
  mark:SetPoint("BOTTOMRIGHT", b, "BOTTOMRIGHT", -3, 3)
  local text = uiText(parent, 11, 0.92, 0.88, 0.80)
  -- 1.45.1 对齐修复：文字相对勾选框 RIGHT 锚定（纵向共中心线），不再用父级 y-3 估算——旧写法视觉上方框偏低
  text:SetPoint("LEFT", b, "RIGHT", 6, 0)
  text:SetText(label)
  if list then table.insert(list, b) table.insert(list, text) end
  local function refresh()
    if get() then mark:Show() else mark:Hide() end
  end
  b:SetScript("OnClick", function()
    set(not get())
    refresh()
  end)
  if tip then -- 悬停提示（勾选框与文字共用）
    local function showTip()
      GameTooltip:SetOwner(b, "ANCHOR_RIGHT")
      GameTooltip:AddLine(tostring(label), 1, 0.82, 0.3)
      GameTooltip:AddLine(tip, 0.85, 0.85, 0.85, 1)
      GameTooltip:Show()
    end
    b:SetScript("OnEnter", showTip)
    b:SetScript("OnLeave", function() GameTooltip:Hide() end)
    pcall(text.EnableMouse, text, true)
    text:SetScript("OnEnter", showTip)
    text:SetScript("OnLeave", function() GameTooltip:Hide() end)
  end
  refresh()
  return refresh
end

-- 阈值滑条：UnrealQuest 实测配方——本客户端不用 Slider 控件，
-- 用 track Frame + thumb Button + RegisterForDrag 自绘；拖动含 warm-up 两步；OnUpdate 实时回写数值。
local function cfgSlider(parent, x, y, w, label, get, set, list)
  local text = uiText(parent, 10, 0.92, 0.88, 0.80)
  text:SetPoint("TOPLEFT", parent, "TOPLEFT", x, y)
  text:SetText(label)
  local valText = uiText(parent, 11, 1, 0.85, 0.35)
  valText:SetPoint("TOPLEFT", parent, "TOPLEFT", x + w + 6, y - 13)
  local track = CreateFrame("Frame", nil, parent)
  track:SetWidth(w) track:SetHeight(8)
  track:SetPoint("TOPLEFT", parent, "TOPLEFT", x, y - 14)
  local trackBg = track:CreateTexture(nil, "BACKGROUND")
  uiSolid(trackBg, 0.06, 0.05, 0.04, 1)
  trackBg:SetPoint("TOPLEFT", track, "TOPLEFT", 0, 0)
  trackBg:SetPoint("BOTTOMRIGHT", track, "BOTTOMRIGHT", 0, 0)
  local trackEdge = track:CreateTexture(nil, "BORDER")
  uiSolid(trackEdge, 0.85, 0.70, 0.20, 0.7)
  trackEdge:SetPoint("TOPLEFT", track, "TOPLEFT", 0, 1)
  trackEdge:SetPoint("TOPRIGHT", track, "TOPRIGHT", 0, 1)
  trackEdge:SetHeight(1)
  local thumb = CreateFrame("Button", nil, track)
  thumb:SetWidth(12) thumb:SetHeight(14)
  local thumbTex = thumb:CreateTexture(nil, "ARTWORK")
  uiSolid(thumbTex, 0.95, 0.80, 0.25, 1)
  thumbTex:SetPoint("TOPLEFT", thumb, "TOPLEFT", 0, 0)
  thumbTex:SetPoint("BOTTOMRIGHT", thumb, "BOTTOMRIGHT", 0, 0)
  pcall(thumb.EnableMouse, thumb, true)
  pcall(thumb.RegisterForClicks, thumb, "LeftButtonUp")
  pcall(thumb.RegisterForDrag, thumb, "LeftButton")
  local dragging = false
  local function place(v)
    v = math.max(0, math.min(100, v or 0))
    thumb:ClearAllPoints()
    thumb:SetPoint("LEFT", track, "LEFT", (v / 100) * (w - 12), 0)
  end
  local function read()
    local ok1, tl = pcall(thumb.GetLeft, thumb)
    local ok2, kl = pcall(track.GetLeft, track)
    if not (ok1 and ok2 and tl and kl) then return nil end
    local usable = w - 12
    if usable <= 0 then return nil end
    local off = tl - kl
    if off < 0 then off = 0 elseif off > usable then off = usable end
    return math.floor(off / usable * 100 + 0.5)
  end
  thumb:SetScript("OnDragStart", function()
    pcall(thumb.SetMovable, thumb, true)
    pcall(thumb.StartMoving, thumb)          -- warm-up 两步（UnrealQuest StartFrameDrag 实测配方）
    pcall(thumb.StopMovingOrSizing, thumb)
    if pcall(thumb.StartMoving, thumb) then dragging = true end
  end)
  thumb:SetScript("OnUpdate", function()
    if not dragging then return end
    local v = read()
    if v then set(v) valText:SetText(tostring(v)) end
  end)
  thumb:SetScript("OnDragStop", function()
    local v = read()
    dragging = false
    pcall(thumb.StopMovingOrSizing, thumb)
    if v then set(v) valText:SetText(tostring(v)) end
    place(v or (get() or 0))
  end)
  if list then
    table.insert(list, text) table.insert(list, valText)
    table.insert(list, track) table.insert(list, thumb)
  end
  place(get() or 0)
  valText:SetText(tostring(get() or 0))
  return function() place(get() or 0) valText:SetText(tostring(get() or 0)) end
end

-- 章节标题
local function cfgHeader(parent, x, y, label, list)
  local t = uiText(parent, 11, 0.95, 0.80, 0.30)
  t:SetPoint("TOPLEFT", parent, "TOPLEFT", x, y)
  t:SetText(label)
  if list then table.insert(list, t) end
end

-- 构建配置窗口（只建一次；开关 = Show/Hide）
local function cfgBuild()
  if cfgWin.root then return cfgWin.root end
  local WIDE = (EVAL_GET_LANG() ~= "zhCN") -- 1.34.1 i18n：西文（英/俄）比中文宽 ~1.5 倍，窗口与右列自适应加宽
local W, H = WIDE and 700 or 560, 420
  local root = CreateFrame("Frame", "EVAL_HELP_CFG", UIParent)
  pcall(root.SetFrameStrata, root, "DIALOG")
  pcall(root.EnableMouse, root, true)
  pcall(root.SetMovable, root, true)
  root:SetWidth(W) root:SetHeight(H)
  -- 位置：默认左移错开 UnrealQuest 的居中设置窗口；拖动后按记忆位置恢复
  root:ClearAllPoints()
  local pos = c().cfgPos
  if pos and type(pos.point) == "string" then
    pcall(root.SetPoint, root, pos.point, UIParent, pos.relPoint or pos.point, pos.x or 0, pos.y or 0)
  else
    root:SetPoint("CENTER", UIParent, "CENTER", -320, -30)
  end

  -- 深底 + 1px 金边（四边纯色纹理，不依赖客户端贴图）
  local bg = root:CreateTexture(nil, "BACKGROUND")
  uiSolid(bg, 0.06, 0.05, 0.04, 0.95)
  bg:SetPoint("TOPLEFT", root, "TOPLEFT", 0, 0)
  bg:SetPoint("BOTTOMRIGHT", root, "BOTTOMRIGHT", 0, 0)
  for _, e in ipairs({ "TOP", "BOTTOM" }) do
    local t = root:CreateTexture(nil, "BORDER")
    uiSolid(t, 0.85, 0.70, 0.20, 1)
    t:SetPoint(e .. "LEFT", root, e .. "LEFT", 0, 0)
    t:SetPoint(e .. "RIGHT", root, e .. "RIGHT", 0, 0)
    t:SetHeight(1)
  end
  for _, side in ipairs({ "LEFT", "RIGHT" }) do
    local t = root:CreateTexture(nil, "BORDER")
    uiSolid(t, 0.85, 0.70, 0.20, 1)
    t:SetPoint("TOP" .. side, root, "TOP" .. side, 0, 0)
    t:SetPoint("BOTTOM" .. side, root, "BOTTOM" .. side, 0, 0)
    t:SetWidth(1)
  end

  -- 标题栏（拖动柄，与状态窗口同一套逻辑：Button + frame level +10，见状态窗口注释）
  local titleBar = CreateFrame("Button", nil, root)
  titleBar:SetPoint("TOPLEFT", root, "TOPLEFT", 1, -1)
  titleBar:SetPoint("TOPRIGHT", root, "TOPRIGHT", -1, -1)
  titleBar:SetHeight(20)
  local okLvl2, rootLvl2 = pcall(root.GetFrameLevel, root)
  if okLvl2 and type(rootLvl2) == "number" then
    pcall(titleBar.SetFrameLevel, titleBar, rootLvl2 + 10)
  end
  pcall(titleBar.RegisterForClicks, titleBar, "LeftButtonUp")
  local tbBg = titleBar:CreateTexture(nil, "BACKGROUND")
  uiSolid(tbBg, 0.16, 0.13, 0.08, 1)
  tbBg:SetPoint("TOPLEFT", titleBar, "TOPLEFT", 0, 0)
  tbBg:SetPoint("BOTTOMRIGHT", titleBar, "BOTTOMRIGHT", 0, 0)
  pcall(titleBar.EnableMouse, titleBar, true)
  pcall(titleBar.RegisterForDrag, titleBar, "LeftButton")
  titleBar:SetScript("OnDragStart", function()
    pcall(root.SetMovable, root, true)
    pcall(root.StartMoving, root)          -- warm-up 两步（UnrealQuest StartFrameDrag 实测配方）
    pcall(root.StopMovingOrSizing, root)
    pcall(root.StartMoving, root)
  end)
  titleBar:SetScript("OnDragStop", function()
    pcall(root.StopMovingOrSizing, root)
    local ok, point, _, relPoint, x, y = pcall(root.GetPoint, root, 1)
    if ok and type(point) == "string" then
      c().cfgPos = {
        point = point,
        relPoint = (type(relPoint) == "string") and relPoint or point,
        x = (type(x) == "number") and x or 0,
        y = (type(y) == "number") and y or 0,
      }
    end
  end)
  local title = uiText(titleBar, 12, 0.95, 0.82, 0.35)
  title:SetPoint("CENTER", titleBar, "CENTER", 0, 0)
  title:SetText(L("CFG_TITLE"))

  -- 语言选择（1.34.0 i18n P0）：标题栏右上角国旗行 [CN][EN][RU]——国旗纹理盖住 ASCII 徽标，
  -- 纹理加载失败徽标仍在（任何语言都能找到回家的路）；选中=不透明/未选=30%透/悬停=95%；
  -- 不入 G/Wp 页清单——常驻标题栏两个 Tab 都可见；切换存 cfg.lang + 新语言提示 /reload
  local EH_FLAGS = {
    { code = "zhCN", badge = "CN", flag = "cn" },
    { code = "enUS", badge = "EN", flag = "en" },
    { code = "ruRU", badge = "RU", flag = "ru" },
  }
  cfgWin.langBtns = {}
  EVAL_HELP_CFGWIN = cfgWin -- 全局桥：供 EVAL_HELP_LANG_REFRESH（定义在本 local 声明之前）使用
  for i, lg in ipairs(EH_FLAGS) do
    local fb = CreateFrame("Button", nil, root)
    fb:SetWidth(18) fb:SetHeight(14)
    fb:SetPoint("TOPRIGHT", root, "TOPRIGHT", -8 - (table.getn(EH_FLAGS) - i) * 21, -3)
    pcall(fb.EnableMouse, fb, true)
    pcall(fb.RegisterForClicks, fb, "LeftButtonUp")
    local okLF, tLvl = pcall(titleBar.GetFrameLevel, titleBar)
    if okLF and type(tLvl) == "number" then pcall(fb.SetFrameLevel, fb, tLvl + 5) end -- 高过拖动柄
    local fbg = fb:CreateTexture(nil, "BACKGROUND")
    uiSolid(fbg, 0.10, 0.09, 0.06, 1)
    fbg:SetPoint("TOPLEFT", fb, "TOPLEFT", 0, 0)
    fbg:SetPoint("BOTTOMRIGHT", fb, "BOTTOMRIGHT", 0, 0)
    local badge = uiText(fb, 9, 0.92, 0.92, 0.92)
    badge:SetPoint("CENTER", fb, "CENTER", 0, 0)
    badge:SetText(lg.badge)
    local ft = fb:CreateTexture(nil, "ARTWORK")
    ft:SetPoint("TOPLEFT", fb, "TOPLEFT", 0, 0)
    ft:SetPoint("BOTTOMRIGHT", fb, "BOTTOMRIGHT", 0, 0)
    pcall(ft.SetTexture, ft, "Interface\\AddOns\\EvalHelp\\media\\Flags\\" .. lg.flag .. ".tga")
    fb.langCode = lg.code
    fb:SetScript("OnClick", function()
      if EVAL_SET_LANG(lg.code) then EVAL_HELP_LANG_REFRESH() end
    end)
    fb:SetScript("OnEnter", function() if EVAL_GET_LANG() ~= lg.code then pcall(fb.SetAlpha, fb, 0.95) end end)
    fb:SetScript("OnLeave", function() EVAL_HELP_LANG_REFRESH() end)
    cfgWin.langBtns[i] = fb
  end
  EVAL_HELP_LANG_REFRESH()

  local refreshes = {}

  -- Tab 按钮行（全局 / 一键宏设置；选中=金底亮字，未选=暗底灰字——参考 UnrealQuest 标签页风格）
  local pages = {}
  cfgWin.pages = pages
  local tabNames = { L("TAB_GLOBAL"), L("TAB_MACRO") }
  for i, name in ipairs(tabNames) do
    local tb = CreateFrame("Button", nil, root)
    tb:SetWidth(90) tb:SetHeight(18)
    tb:SetPoint("TOPLEFT", root, "TOPLEFT", 12 + (i - 1) * 96, -26)
    pcall(tb.EnableMouse, tb, true)
    pcall(tb.RegisterForClicks, tb, "LeftButtonUp")
    local tbg = tb:CreateTexture(nil, "BACKGROUND")
    uiSolid(tbg, 0.16, 0.13, 0.08, 1)
    tbg:SetPoint("TOPLEFT", tb, "TOPLEFT", 0, 0)
    tbg:SetPoint("BOTTOMRIGHT", tb, "BOTTOMRIGHT", 0, 0)
    local tt = uiText(tb, 11, 0.95, 0.82, 0.35)
    tt:SetPoint("CENTER", tb, "CENTER", 0, 0)
    tt:SetText(name)
    local idx = i
    tb:SetScript("OnClick", function() EVAL_HELP_CFG_SETTAB(idx) end)
    pages[i] = { btn = tb, bg = tbg, text = tt, widgets = {} }
  end

  local LX, RX, RW = 18, WIDE and 330 or 250, 160 -- RX 右列随语言加宽

  -- ===== Tab 1「全局」：日志 / 界面 / 帮助（非职业相关） =====
  local G = pages[1].widgets
  cfgHeader(root, LX, -56, L("G_LOG_H"), G)
  table.insert(refreshes, cfgCheck(root, LX, -74, L("G_LOG_FILE"),
    function() return c().log end, function(v) c().log = v end, G))
  table.insert(refreshes, cfgCheck(root, LX, -98, L("G_LOG_AUTO"),
    function() return c().auto end, function(v) c().auto = v end, G))

  cfgHeader(root, LX, -138, L("G_UI_H"), G)
  table.insert(refreshes, cfgCheck(root, LX, -156, L("G_UI_COMBAT"),
    function() local u = c(); return u.ui and u.ui.enabled end,
    function(v)
      local u = c()
      if not u.ui then u.ui = { enabled = false, x = 0, y = -180, scale = 1 } end
      if v ~= (u.ui.enabled and true or false) then EVAL_HELP_UI_TOGGLE() end
    end, G))
  table.insert(refreshes, cfgCheck(root, LX, -180, L("G_UI_STATE"),
    function() local u = c(); return u.st and u.st.enabled end,
    function(v)
      local u = c()
      if not u.st then u.st = { enabled = false, x = 330, y = -180 } end
      if v ~= (u.st.enabled and true or false) then EVAL_HELP_ST_TOGGLE() end
    end, G))

  cfgHeader(root, RX, -56, L("G_HELP_H"), G)
  -- 分组排版（1.21.5）：金色小标题 + 缩进条目 + 组间留白；命令行用亮米色区分
  -- 1.32.7 重整：清掉战士残留（猛击 Alt），补五分类/Shift切方案/重扫按钮/导入导出
  local helpLines = { -- 1.34.0 i18n：全部走语言包键
    { L("HELP_QS_H"), h = true },
    { L("HELP_QS_1") },
    { L("HELP_QS_2") },
    { L("HELP_QS_3") },
    { L("HELP_PROF_H"), h = true },
    { L("HELP_PROF_1"), cmd = true },
    { L("HELP_PROF_2"), cmd = true },
    { L("HELP_PROF_3"), cmd = true },
    { L("HELP_PROF_4"), cmd = true },
    { L("HELP_ADV_H"), h = true },
    { L("HELP_ADV_1") },
    { L("HELP_ADV_2") },
    { L("HELP_ADV_3") },
    { L("HELP_MISC_H"), h = true },
    { L("HELP_MISC_1") },
    { L("HELP_MISC_2") },
  }
  local hy = -74
  for _, e in ipairs(helpLines) do
    local ht
    if e.h then
      ht = uiText(root, 10, 0.95, 0.82, 0.35)         -- 组标题：金色，上方留白
      ht:SetPoint("TOPLEFT", root, "TOPLEFT", RX, hy - 4)
      hy = hy - 21
    elseif e.cmd then
      ht = uiText(root, 9, 0.88, 0.82, 0.58)         -- 命令示例：亮米色
      ht:SetPoint("TOPLEFT", root, "TOPLEFT", RX + 12, hy)
      hy = hy - 14
    else
      ht = uiText(root, 9, 0.65, 0.65, 0.65)         -- 普通条目：灰色
      ht:SetPoint("TOPLEFT", root, "TOPLEFT", RX + 12, hy)
      hy = hy - 14
    end
    ht:SetText(e[1])
    table.insert(G, ht)
  end

  -- ===== Tab 2「一键宏设置」：多方案 + 技能规则列表（可视化编辑器，全职业通用） =====
  local Wp = pages[2].widgets
  local warUI = { rows = {}, profBtns = {}, picker = {}, editing = nil, pickSkill = nil }
  cfgWin.warUI = warUI
  local MAXPROF = 12 -- 1.42.0 方案上限 4→12（间距 21→19 紧凑排列装下）

  -- 左栏：方案列表（多方案 Tab；最后一个 [+] 新建方案）
  cfgHeader(root, LX, -56, L("W_PROF_H"), Wp)
  for i = 1, MAXPROF + 1 do
    local pb = CreateFrame("Button", nil, root)
    pb:SetWidth(90) pb:SetHeight(17)
    pb:SetPoint("TOPLEFT", root, "TOPLEFT", LX, -74 - (i - 1) * 19)
    pcall(pb.EnableMouse, pb, true)
    pcall(pb.RegisterForClicks, pb, "LeftButtonUp")
    local pbg = pb:CreateTexture(nil, "BACKGROUND")
    uiSolid(pbg, 0.16, 0.13, 0.08, 1)
    pbg:SetPoint("TOPLEFT", pb, "TOPLEFT", 0, 0)
    pbg:SetPoint("BOTTOMRIGHT", pb, "BOTTOMRIGHT", 0, 0)
    local pt = uiText(pb, 10, 0.92, 0.88, 0.80)
    pt:SetPoint("CENTER", pb, "CENTER", 0, 0)
    local pidx = i
    pcall(pb.RegisterForClicks, pb, "LeftButtonUp", "RightButtonUp")
    pb:SetScript("OnClick", function(a, b)
      local w2 = warCfg()
      local mbtn = (type(a) == "string" and a) or (type(b) == "string" and b) or (type(arg1) == "string" and arg1) or "LeftButton"
      -- 右键 = 重命名弹窗（1.17.0：替代底部输入框流程，EditBox 不渲染也有回声行）
      if mbtn == "RightButton" and pidx <= table.getn(w2.profiles) then
        EVAL_HELP_RP_OPEN(pidx)
        return
      end
      if pidx <= table.getn(w2.profiles) then
        w2.activeProfile = pidx
      elseif pidx == table.getn(w2.profiles) + 1 and table.getn(w2.profiles) < MAXPROF then
        table.insert(w2.profiles, { name = "方案" .. tostring(table.getn(w2.profiles) + 1), skills = {} })
        w2.activeProfile = table.getn(w2.profiles)
        say("新建方案: " .. tostring(w2.profiles[w2.activeProfile].name))
      end
      EVAL_WAR_TAB_REFRESH()
    end)
    -- [删] 按钮（二次确认：5 秒内再点一次才删，防误删）
    local delB = CreateFrame("Button", nil, root)
    delB:SetWidth(15) delB:SetHeight(17)
    delB:SetPoint("TOPLEFT", root, "TOPLEFT", LX + 92, -74 - (i - 1) * 19) -- 1.58.1 修偏移：与方案按钮同 19 间距（旧 21 逐行下沉，越往后越错位）
    pcall(delB.EnableMouse, delB, true)
    pcall(delB.RegisterForClicks, delB, "LeftButtonUp")
    local delBg = delB:CreateTexture(nil, "BACKGROUND")
    uiSolid(delBg, 0.25, 0.10, 0.10, 1)
    delBg:SetPoint("TOPLEFT", delB, "TOPLEFT", 0, 0)
    delBg:SetPoint("BOTTOMRIGHT", delB, "BOTTOMRIGHT", 0, 0)
    local delT = uiText(delB, 8, 0.95, 0.6, 0.5)
    delT:SetPoint("CENTER", delB, "CENTER", 0, 0)
    delT:SetText("删")
    delB:SetScript("OnClick", function()
      local w2 = warCfg()
      if pidx > table.getn(w2.profiles) then return end
      if warUI.delArm == pidx and GetTime() - (warUI.delArmT or 0) < 5 then
        warUI.delArm = nil
        EVAL_WAR_DEL_PROFILE(pidx)
      else
        warUI.delArm = pidx
        warUI.delArmT = GetTime()
        say("再点一次 [删] 确认删除方案: " .. tostring(w2.profiles[pidx].name))
        EVAL_WAR_TAB_REFRESH()
      end
    end)
    warUI.profBtns[i] = { btn = pb, bg = pbg, text = pt, del = delB, delBg = delBg }
    table.insert(Wp, pb)
    table.insert(Wp, delB)
  end

  -- 左栏下方：全局开关
  local swY = -74 - (MAXPROF + 1) * 19 - 18
  cfgHeader(root, LX, swY, L("W_SWITCH_H"), Wp)
  table.insert(refreshes, cfgCheck(root, LX, swY - 18, L("W_ENABLE"),
    function() return warCfg().enabled ~= false end,
    function(v) warCfg().enabled = v end, Wp))
  table.insert(refreshes, cfgCheck(root, LX, swY - 42, L("W_AUTOATK"),
    function() return warCfg().attack ~= false end,
    function(v) warCfg().attack = v end, Wp, L("W_AUTOATK_TIP")))
  table.insert(refreshes, cfgCheck(root, LX, swY - 66, L("W_DEBUG"),
    function() return c().wdebug end, function(v) c().wdebug = v end, Wp))

  -- 右侧：技能规则列表（顺序=优先级；勾选=技能配置开关）
  local RX2 = 128
  cfgHeader(root, RX2, -56, L("W_LIST_H"), Wp)
  -- 1.60.0 列表高度衍生到底部：行数按窗口高度动态算（旧固定 8 行，底部大片空置）——
  -- 起始 y=-74、行距 24，底部给关闭按钮留 120px
  local ROWS = math.floor((H - 120) / 24)
  local function mkSmall(x, y, w, label, fn, list, rightAnch) -- 1.32.2 list：传 G 挂全局页；1.34.1 rightAnch：右缘锚定（i18n 宽窗自适应）
    local b = CreateFrame("Button", nil, root)
    b:SetWidth(w) b:SetHeight(15)
    if rightAnch then b:SetPoint("TOPRIGHT", root, "TOPRIGHT", -x, y)
    else b:SetPoint("TOPLEFT", root, "TOPLEFT", x, y) end
    pcall(b.EnableMouse, b, true)
    pcall(b.RegisterForClicks, b, "LeftButtonUp")
    local bb = b:CreateTexture(nil, "BACKGROUND")
    uiSolid(bb, 0.16, 0.13, 0.08, 1)
    bb:SetPoint("TOPLEFT", b, "TOPLEFT", 0, 0)
    bb:SetPoint("BOTTOMRIGHT", b, "BOTTOMRIGHT", 0, 0)
    local bt = uiText(b, 9, 0.95, 0.82, 0.35)
    bt:SetPoint("CENTER", b, "CENTER", 0, 0)
    bt:SetText(label)
    b:SetScript("OnClick", fn)
    table.insert(list or Wp, b)
    if list then table.insert(list, bt) end -- 文本属按钮子件随动，但 G 列表契约要求显式登记
    return b, bt
  end
  -- 方案导入/导出窗口入口（md 文本互转）
  -- [添加技能]：直接打开技能编辑窗新增（技能下拉 + 条件逐行配置 + 保存即入列表）
  mkSmall(WIDE and 122 or 92, -56, WIDE and 112 or 80, L("W_ADD"), function()
    EVAL_HELP_SE_OPEN(warCfg().activeProfile or 1)
  end, nil, true)
  mkSmall(16, -56, WIDE and 98 or 68, L("W_IO"), function() EVAL_HELP_IO_TOGGLE() end, nil, true)

  -- 全局 Tab「一键宏」组（1.32.2）：重扫动作条按钮，等同 /eh go rescan——拖动过技能后点一下即可
  cfgHeader(root, LX, -212, L("G_MACRO_H"), G)
  local rsB, rsT = mkSmall(LX, -232, 130, L("G_RESCAN"), function() EVAL_GO_RESCAN() end, G)
  local rsTip = uiText(root, 8, 0.6, 0.6, 0.6)
  rsTip:SetPoint("TOPLEFT", root, "TOPLEFT", LX, -252)
  rsTip:SetText(L("G_RESCAN_TIP"))
  table.insert(G, rsTip)
  -- 执行去抖窗口（1.54.2）：EVAL_GO 最小执行间隔秒数，默认 0.30（[-][+] 步进 0.05，0=关闭去抖）
  local dbLabel = uiText(root, 9, 0.75, 0.75, 0.75)
  dbLabel:SetPoint("TOPLEFT", root, "TOPLEFT", LX, -272)
  dbLabel:SetText(L("G_DEBOUNCE"))
  table.insert(G, dbLabel)
  local dbVal = uiText(root, 9, 1, 0.85, 0.35)
  dbVal:SetPoint("TOPLEFT", root, "TOPLEFT", LX + 124, -272)
  table.insert(G, dbVal)
  local function dbGet() return tonumber(c().goDebounce) or 0.3 end
  local function dbShow() dbVal:SetText(string.format("%.2fs", dbGet())) end
  local function dbStep(dv)
    local v = math.floor((dbGet() + dv) * 100 + 0.5) / 100
    if v < 0 then v = 0 elseif v > 1 then v = 1 end
    c().goDebounce = v
    dbShow()
  end
  mkSmall(LX + 100, -270, 20, "-", function() dbStep(-0.05) end, G)
  mkSmall(LX + 164, -270, 20, "+", function() dbStep(0.05) end, G)
  table.insert(refreshes, dbShow)

  -- （1.21.6 起移除底部「激活方案」下拉：与左侧方案栏/战斗信息UI方案行/Shift+按宏//eh go prof N 功能重复）

  for ri = 1, ROWS do
    local y = -74 - (ri - 1) * 24
    local row = {}
    local chk = CreateFrame("Button", nil, root)
    chk:SetWidth(14) chk:SetHeight(14)
    chk:SetPoint("TOPLEFT", root, "TOPLEFT", RX2, y)
    pcall(chk.EnableMouse, chk, true)
    pcall(chk.RegisterForClicks, chk, "LeftButtonUp")
    local cOut = chk:CreateTexture(nil, "BACKGROUND")
    uiSolid(cOut, 0.85, 0.70, 0.20, 1)
    cOut:SetPoint("TOPLEFT", chk, "TOPLEFT", 0, 0)
    cOut:SetPoint("BOTTOMRIGHT", chk, "BOTTOMRIGHT", 0, 0)
    local cIn = chk:CreateTexture(nil, "ARTWORK")
    uiSolid(cIn, 0.10, 0.09, 0.06, 1)
    cIn:SetPoint("TOPLEFT", chk, "TOPLEFT", 1, -1)
    cIn:SetPoint("BOTTOMRIGHT", chk, "BOTTOMRIGHT", -1, 1)
    local cMark = chk:CreateTexture(nil, "OVERLAY")
    uiSolid(cMark, 0.95, 0.80, 0.25, 1)
    cMark:SetPoint("TOPLEFT", chk, "TOPLEFT", 3, -3)
    cMark:SetPoint("BOTTOMRIGHT", chk, "BOTTOMRIGHT", -3, 3)
    chk:SetScript("OnClick", function()
      local p = warCfg().profiles[warCfg().activeProfile or 1]
      local r = p and p.skills[ri + (warUI.offset or 0)]
      if r then
        r.enabled = (r.enabled == false) and true or false
        EVAL_WAR_TAB_REFRESH()
      end
    end)
    row.chk, row.mark = chk, cMark
    table.insert(Wp, chk)
    local icon = root:CreateTexture(nil, "ARTWORK")
    icon:SetPoint("TOPLEFT", root, "TOPLEFT", RX2 + 18, y)
    icon:SetWidth(15) icon:SetHeight(15)
    row.icon = icon
    table.insert(Wp, icon)
    local nm = uiText(root, 10, 0.92, 0.88, 0.80)
    nm:SetPoint("TOPLEFT", root, "TOPLEFT", RX2 + 38, y - 2)
    row.name = nm
    table.insert(Wp, nm)
    local cds = uiText(root, 9, 0.70, 0.70, 0.70)
    cds:SetPoint("TOPLEFT", root, "TOPLEFT", RX2 + 102, y - 3)
    pcall(cds.SetWidth, cds, WIDE and 356 or 236) -- 1.33.0 让位滚动条；1.34.1 宽语言再加宽
    pcall(cds.SetJustifyH, cds, "LEFT")
    row.conds = cds
    table.insert(Wp, cds)
    -- 1.61.0 调序按钮改为 ^/v 箭头 + 新增下移（文本「上」→ ^，新增 v）
    row.up = mkSmall(88, y, 16, "^", function()
      local p = warCfg().profiles[warCfg().activeProfile or 1]
      local idx = ri + (warUI.offset or 0)
      if p and idx > 1 and p.skills[idx] and p.skills[idx - 1] then
        p.skills[idx], p.skills[idx - 1] = p.skills[idx - 1], p.skills[idx]
        EVAL_WAR_TAB_REFRESH()
      end
    end, nil, true)
    row.dn = mkSmall(72, y, 16, "v", function()
      local p = warCfg().profiles[warCfg().activeProfile or 1]
      local idx = ri + (warUI.offset or 0)
      if p and p.skills[idx] and p.skills[idx + 1] then
        p.skills[idx], p.skills[idx + 1] = p.skills[idx + 1], p.skills[idx]
        EVAL_WAR_TAB_REFRESH()
      end
    end, nil, true)
    row.edit = mkSmall(44, y, 24, L("W_EDIT"), function()
      -- 打开技能编辑窗（独立条件属性行 + & / | 关系调整）
      local w2 = warCfg()
      local p = w2.profiles[w2.activeProfile or 1]
      local idx = ri + (warUI.offset or 0)
      if p and p.skills[idx] then
        EVAL_HELP_SE_OPEN(w2.activeProfile or 1, idx)
      end
    end, nil, true)
    row.del = mkSmall(16, y, 24, L("W_DEL"), function()
      local p = warCfg().profiles[warCfg().activeProfile or 1]
      local idx = ri + (warUI.offset or 0)
      if p and p.skills[idx] then
        table.remove(p.skills, idx)
        EVAL_WAR_TAB_REFRESH()
      end
    end, nil, true)
    warUI.rows[ri] = row
  end

  -- 滚动条（1.33.0：技能数取消上限后的超高滚动）：^ 上翻 / v 下翻 + 滚轮；仅超出可见行数时显示
  warUI.offset = warUI.offset or 0
  warUI.scrollUp = mkSmall(94, -74, 14, "^", function()
    warUI.offset = math.max(0, (warUI.offset or 0) - 1)
    EVAL_WAR_TAB_REFRESH()
  end, nil, true)
  warUI.scrollDn = mkSmall(94, -74 - (ROWS - 1) * 24, 14, "v", function() -- 1.60.0 跟随动态行数（旧硬编码 -242）
    warUI.offset = (warUI.offset or 0) + 1
    EVAL_WAR_TAB_REFRESH() -- 上限在刷新里收敛
  end, nil, true)
  local okWheel = pcall(root.EnableMouseWheel, root, true)
  if okWheel then
    root:SetScript("OnMouseWheel", function()
      local d = arg1 -- 1.12 风格：滚轮方向在全局 arg1（上=+1）
      if type(d) ~= "number" then return end
      warUI.offset = math.max(0, (warUI.offset or 0) - d)
      EVAL_WAR_TAB_REFRESH()
    end)
  end

  -- 底部关闭按钮（截图同款右下「关闭」）
  local close = CreateFrame("Button", nil, root)
  close:SetWidth(64) close:SetHeight(22)
  close:SetPoint("BOTTOMRIGHT", root, "BOTTOMRIGHT", -12, 10)
  pcall(close.EnableMouse, close, true)
  pcall(close.RegisterForClicks, close, "LeftButtonUp")
  local cbg = close:CreateTexture(nil, "BACKGROUND")
  uiSolid(cbg, 0.16, 0.13, 0.08, 1)
  cbg:SetPoint("TOPLEFT", close, "TOPLEFT", 0, 0)
  cbg:SetPoint("BOTTOMRIGHT", close, "BOTTOMRIGHT", 0, 0)
  local ct = uiText(close, 11, 0.95, 0.82, 0.35)
  ct:SetPoint("CENTER", close, "CENTER", 0, 0)
  ct:SetText(L("CLOSE"))
  close:SetScript("OnClick", function() root:Hide() end)

  cfgWin.root = root
  root:SetScript("OnHide", function() EVAL_DD_HIDE() end) -- 关窗收起下拉（1.19.0）
  cfgWin.refresh = function() for _, r in ipairs(refreshes) do pcall(r) end end
  EVAL_HELP_CFG_SETTAB(c().cfgTab or 1)
  return root
end

-- ===== 方案重命名弹窗（1.17.0：替代底部输入框改名流程） =====
-- EditBox 在本客户端可能不渲染 → 加回声行（OnTextChanged 实时镜像输入内容，盲打也可见）
local rpUI = {}

function EVAL_HELP_RP_BUILD()
  if rpUI.root then return end
  local W, H = 300, 150
  local root = CreateFrame("Frame", "EVAL_HELP_RP", UIParent)
  root:SetWidth(W) root:SetHeight(H)
  root:SetPoint("CENTER", UIParent, "CENTER", 0, 130)
  pcall(root.SetFrameStrata, root, "DIALOG")
  pcall(root.SetFrameLevel, root, 120)
  pcall(root.SetMovable, root, true)
  pcall(root.EnableMouse, root, true)
  if uiOffscreen(root) then
    root:ClearAllPoints()
    root:SetPoint("CENTER", UIParent, "CENTER", 0, 100)
  end
  local bg = root:CreateTexture(nil, "BACKGROUND")
  uiSolid(bg, 0.06, 0.05, 0.04, 0.98)
  bg:SetPoint("TOPLEFT", root, "TOPLEFT", 0, 0)
  bg:SetPoint("BOTTOMRIGHT", root, "BOTTOMRIGHT", 0, 0)
  for _, e in ipairs({ "TOP", "BOTTOM" }) do
    local t = root:CreateTexture(nil, "BORDER")
    uiSolid(t, 0.85, 0.70, 0.20, 1)
    t:SetPoint(e .. "LEFT", root, e .. "LEFT", 0, 0)
    t:SetPoint(e .. "RIGHT", root, e .. "RIGHT", 0, 0)
    t:SetHeight(1)
  end
  for _, side in ipairs({ "LEFT", "RIGHT" }) do
    local t = root:CreateTexture(nil, "BORDER")
    uiSolid(t, 0.85, 0.70, 0.20, 1)
    t:SetPoint("TOP" .. side, root, "TOP" .. side, 0, 0)
    t:SetPoint("BOTTOM" .. side, root, "BOTTOM" .. side, 0, 0)
    t:SetWidth(1)
  end
  local titleBar = CreateFrame("Button", nil, root)
  titleBar:SetWidth(W - 4) titleBar:SetHeight(22)
  titleBar:SetPoint("TOP", root, "TOP", 0, -2)
  pcall(titleBar.SetFrameLevel, titleBar, 121)
  pcall(titleBar.EnableMouse, titleBar, true)
  pcall(titleBar.RegisterForClicks, titleBar, "LeftButtonUp")
  pcall(titleBar.RegisterForDrag, titleBar, "LeftButton")
  local tbBg = titleBar:CreateTexture(nil, "BACKGROUND")
  uiSolid(tbBg, 0.14, 0.11, 0.06, 1)
  tbBg:SetPoint("TOPLEFT", titleBar, "TOPLEFT", 0, 0)
  tbBg:SetPoint("BOTTOMRIGHT", titleBar, "BOTTOMRIGHT", 0, 0)
  local title = uiText(titleBar, 10, 0.95, 0.82, 0.35)
  title:SetPoint("CENTER", titleBar, "CENTER", 0, 0)
  title:SetText(L("RP_TITLE"))
  titleBar:SetScript("OnDragStart", function()
    pcall(root.SetMovable, root, true)
    pcall(root.StartMoving, root)
    pcall(root.StopMovingOrSizing, root)
    pcall(root.StartMoving, root)
  end)
  titleBar:SetScript("OnDragStop", function() pcall(root.StopMovingOrSizing, root) end)

  local lab = uiText(root, 10, 0.85, 0.85, 0.85)
  lab:SetPoint("TOPLEFT", root, "TOPLEFT", 16, -36)
  lab:SetText("新方案名：")

  -- 输入框（单行）
  local okEb, eb = pcall(CreateFrame, "EditBox", "EVAL_HELP_RP_EB", root)
  if okEb and eb then
    pcall(eb.SetAutoFocus, eb, false)
    pcall(eb.EnableMouse, eb, true)
    eb:SetWidth(220) eb:SetHeight(18)
    eb:SetPoint("TOPLEFT", root, "TOPLEFT", 20, -54)
    local setF = false
    for _, fo in ipairs({ "GameFontHighlightSmall", "ChatFontNormal", "GameFontNormal" }) do
      if pcall(eb.SetFontObject, eb, fo) then setF = true break end
    end
    if not setF then
      for _, fp in ipairs({ "Fonts\\FZLBJW.TTF", "Fonts\\FRIZQT__.TTF", "Fonts\\ARIALN.TTF" }) do
        local okF, ok2 = pcall(eb.SetFont, eb, fp, 11, "")
        if okF and ok2 then setF = true break end
      end
    end
    if not setF then pcall(eb.SetTextHeight, eb, 11) end
    pcall(eb.SetTextColor, eb, 1, 1, 1)
    local ebBg = root:CreateTexture(nil, "BACKGROUND")
    uiSolid(ebBg, 0.10, 0.09, 0.06, 1)
    ebBg:SetPoint("TOPLEFT", root, "TOPLEFT", 14, -48)
    ebBg:SetWidth(W - 28) ebBg:SetHeight(24)
    local ebEdge = root:CreateTexture(nil, "BORDER")
    uiSolid(ebEdge, 0.85, 0.70, 0.20, 0.8)
    ebEdge:SetPoint("TOPLEFT", root, "TOPLEFT", 14, -48)
    ebEdge:SetWidth(W - 28) ebEdge:SetHeight(1)
    rpUI.eb = eb
  else
    local noEb = uiText(root, 9, 0.7, 0.5, 0.5)
    noEb:SetPoint("TOPLEFT", root, "TOPLEFT", 16, -54)
    noEb:SetText(L("RP_NOEB"))
  end

  -- 回声行：实时镜像输入内容（EditBox 不渲染时的保底可见性）
  local echo = uiText(root, 11, 1, 0.9, 0.4)
  echo:SetPoint("TOPLEFT", root, "TOPLEFT", 20, -80)
  pcall(echo.SetWidth, echo, W - 40)
  pcall(echo.SetJustifyH, echo, "LEFT")
  rpUI.echo = echo
  if rpUI.eb then
    rpUI.eb:SetScript("OnTextChanged", function()
      local ok, t = pcall(rpUI.eb.GetText, rpUI.eb)
      if ok and type(t) == "string" then echo:SetText(t) end
    end)
  end

  local function apply()
    local nm = ""
    if rpUI.eb then
      local ok, t = pcall(rpUI.eb.GetText, rpUI.eb)
      if ok and type(t) == "string" then nm = t end
    end
    nm = string.gsub(nm, "^%s*(.-)%s*$", "%1")
    local w2 = warCfg()
    local p = rpUI.target and w2.profiles[rpUI.target]
    if p and nm ~= "" then
      p.name = nm
      say("方案已改名: " .. nm)
    end
    rpUI.target = nil
    root:Hide()
    EVAL_WAR_TAB_REFRESH()
  end
  if rpUI.eb then
    rpUI.eb:SetScript("OnEnterPressed", function() apply() end)
    rpUI.eb:SetScript("OnEscapePressed", function() root:Hide() end)
  end

  local function bBtn(x, label, fn)
    local b = CreateFrame("Button", nil, root)
    b:SetWidth(80) b:SetHeight(22)
    b:SetPoint("BOTTOMLEFT", root, "BOTTOMLEFT", x, 12)
    pcall(b.EnableMouse, b, true)
    pcall(b.RegisterForClicks, b, "LeftButtonUp")
    local bb = b:CreateTexture(nil, "BACKGROUND")
    uiSolid(bb, 0.22, 0.18, 0.10, 1)
    bb:SetPoint("TOPLEFT", b, "TOPLEFT", 0, 0)
    bb:SetPoint("BOTTOMRIGHT", b, "BOTTOMRIGHT", 0, 0)
    local bt = uiText(b, 10, 0.95, 0.82, 0.35)
    bt:SetPoint("CENTER", b, "CENTER", 0, 0)
    bt:SetText(label)
    b:SetScript("OnClick", fn)
  end
  bBtn(70, L("BTN_OK"), function() apply() end)
  bBtn(160, L("BTN_CANCEL"), function() root:Hide() end)

  root:Hide()
  rpUI.root = root
end

function EVAL_HELP_RP_OPEN(idx)
  EVAL_HELP_RP_BUILD()
  local w2 = warCfg()
  if not w2.profiles[idx] then return end
  rpUI.target = idx
  local nm = tostring(w2.profiles[idx].name or "")
  if rpUI.eb then
    pcall(rpUI.eb.SetText, rpUI.eb, nm)
    pcall(rpUI.eb.SetFocus, rpUI.eb)
  end
  if rpUI.echo then rpUI.echo:SetText(nm) end
  rpUI.root:Show()
end


-- ===== 通用名称输入弹窗（1.29.0：仿 1.17.0 重命名弹窗回声行范式——EditBox 可能不渲染 → 金色回声行保底） =====
-- EVAL_TN_OPEN(标题, 当前值, onOk(名称))；确定/回车回调，取消/Esc 直接关。
local tnUI = {}

function EVAL_TN_BUILD()
  if tnUI.root then return end
  local W, H = 300, 150
  local root = CreateFrame("Frame", "EVAL_HELP_TN", UIParent)
  root:SetWidth(W) root:SetHeight(H)
  root:SetPoint("CENTER", UIParent, "CENTER", 0, 130)
  pcall(root.SetFrameStrata, root, "DIALOG")
  pcall(root.SetFrameLevel, root, 130) -- 高于技能编辑窗(100)
  pcall(root.SetMovable, root, true)
  pcall(root.EnableMouse, root, true)
  if uiOffscreen(root) then
    root:ClearAllPoints()
    root:SetPoint("CENTER", UIParent, "CENTER", 0, 100)
  end
  local bg = root:CreateTexture(nil, "BACKGROUND")
  uiSolid(bg, 0.06, 0.05, 0.04, 0.98)
  bg:SetPoint("TOPLEFT", root, "TOPLEFT", 0, 0)
  bg:SetPoint("BOTTOMRIGHT", root, "BOTTOMRIGHT", 0, 0)
  for _, e in ipairs({ "TOP", "BOTTOM" }) do
    local t = root:CreateTexture(nil, "BORDER")
    uiSolid(t, 0.85, 0.70, 0.20, 1)
    t:SetPoint(e .. "LEFT", root, e .. "LEFT", 0, 0)
    t:SetPoint(e .. "RIGHT", root, e .. "RIGHT", 0, 0)
    t:SetHeight(1)
  end
  for _, side in ipairs({ "LEFT", "RIGHT" }) do
    local t = root:CreateTexture(nil, "BORDER")
    uiSolid(t, 0.85, 0.70, 0.20, 1)
    t:SetPoint("TOP" .. side, root, "TOP" .. side, 0, 0)
    t:SetPoint("BOTTOM" .. side, root, "BOTTOM" .. side, 0, 0)
    t:SetWidth(1)
  end
  local titleBar = CreateFrame("Button", nil, root)
  titleBar:SetWidth(W - 4) titleBar:SetHeight(22)
  titleBar:SetPoint("TOP", root, "TOP", 0, -2)
  pcall(titleBar.SetFrameLevel, titleBar, 131)
  pcall(titleBar.EnableMouse, titleBar, true)
  pcall(titleBar.RegisterForClicks, titleBar, "LeftButtonUp")
  pcall(titleBar.RegisterForDrag, titleBar, "LeftButton")
  local tbBg = titleBar:CreateTexture(nil, "BACKGROUND")
  uiSolid(tbBg, 0.14, 0.11, 0.06, 1)
  tbBg:SetPoint("TOPLEFT", titleBar, "TOPLEFT", 0, 0)
  tbBg:SetPoint("BOTTOMRIGHT", titleBar, "BOTTOMRIGHT", 0, 0)
  local title = uiText(titleBar, 10, 0.95, 0.82, 0.35)
  title:SetPoint("CENTER", titleBar, "CENTER", 0, 0)
  tnUI.titleText = title
  titleBar:SetScript("OnDragStart", function()
    pcall(root.SetMovable, root, true)
    pcall(root.StartMoving, root)
    pcall(root.StopMovingOrSizing, root)
    pcall(root.StartMoving, root)
  end)
  titleBar:SetScript("OnDragStop", function() pcall(root.StopMovingOrSizing, root) end)

  local lab = uiText(root, 10, 0.85, 0.85, 0.85)
  lab:SetPoint("TOPLEFT", root, "TOPLEFT", 16, -36)
  lab:SetText("目标名称：")

  local okEb, eb = pcall(CreateFrame, "EditBox", "EVAL_HELP_TN_EB", root)
  if okEb and eb then
    pcall(eb.SetAutoFocus, eb, false)
    pcall(eb.EnableMouse, eb, true)
    eb:SetWidth(220) eb:SetHeight(18)
    eb:SetPoint("TOPLEFT", root, "TOPLEFT", 20, -54)
    local setF = false
    for _, fo in ipairs({ "GameFontHighlightSmall", "ChatFontNormal", "GameFontNormal" }) do
      if pcall(eb.SetFontObject, eb, fo) then setF = true break end
    end
    if not setF then
      for _, fp in ipairs({ "Fonts\\FZLBJW.TTF", "Fonts\\FRIZQT__.TTF", "Fonts\\ARIALN.TTF" }) do
        local okF, ok2 = pcall(eb.SetFont, eb, fp, 11, "")
        if okF and ok2 then setF = true break end
      end
    end
    if not setF then pcall(eb.SetTextHeight, eb, 11) end
    pcall(eb.SetTextColor, eb, 1, 1, 1)
    local ebBg = root:CreateTexture(nil, "BACKGROUND")
    uiSolid(ebBg, 0.10, 0.09, 0.06, 1)
    ebBg:SetPoint("TOPLEFT", root, "TOPLEFT", 14, -48)
    ebBg:SetWidth(W - 28) ebBg:SetHeight(24)
    tnUI.eb = eb
  else
    local noEb = uiText(root, 9, 0.7, 0.5, 0.5)
    noEb:SetPoint("TOPLEFT", root, "TOPLEFT", 16, -54)
    noEb:SetText(L("TN_NOEB"))
  end

  -- 回声行：实时镜像输入内容（盲打保底可见）
  local echo = uiText(root, 11, 1, 0.9, 0.4)
  echo:SetPoint("TOPLEFT", root, "TOPLEFT", 20, -80)
  pcall(echo.SetWidth, echo, W - 40)
  pcall(echo.SetJustifyH, echo, "LEFT")
  tnUI.echo = echo
  if tnUI.eb then
    tnUI.eb:SetScript("OnTextChanged", function()
      local ok, t = pcall(tnUI.eb.GetText, tnUI.eb)
      if ok and type(t) == "string" then echo:SetText(t) end
    end)
  end

  local function apply()
    local nm = ""
    if tnUI.eb then
      local ok, t = pcall(tnUI.eb.GetText, tnUI.eb)
      if ok and type(t) == "string" then nm = t end
    end
    nm = string.gsub(nm, "^%s*(.-)%s*$", "%1")
    if nm ~= "" and tnUI.onOk then tnUI.onOk(nm) end
    root:Hide()
  end
  if tnUI.eb then
    tnUI.eb:SetScript("OnEnterPressed", function() apply() end)
    tnUI.eb:SetScript("OnEscapePressed", function() root:Hide() end)
  end

  local function bBtn(x, label, fn)
    local b = CreateFrame("Button", nil, root)
    b:SetWidth(80) b:SetHeight(22)
    b:SetPoint("BOTTOMLEFT", root, "BOTTOMLEFT", x, 12)
    pcall(b.EnableMouse, b, true)
    pcall(b.RegisterForClicks, b, "LeftButtonUp")
    local bb = b:CreateTexture(nil, "BACKGROUND")
    uiSolid(bb, 0.22, 0.18, 0.10, 1)
    bb:SetPoint("TOPLEFT", b, "TOPLEFT", 0, 0)
    bb:SetPoint("BOTTOMRIGHT", b, "BOTTOMRIGHT", 0, 0)
    local bt = uiText(b, 10, 0.95, 0.82, 0.35)
    bt:SetPoint("CENTER", b, "CENTER", 0, 0)
    bt:SetText(label)
    b:SetScript("OnClick", fn)
  end
  bBtn(70, L("BTN_OK"), function() apply() end)
  bBtn(160, L("BTN_CANCEL"), function() root:Hide() end)

  root:Hide()
  root:SetScript("OnHide", function() tnUI.onOk = nil end)
  tnUI.root = root
end

function EVAL_TN_OPEN(title, cur, onOk)
  EVAL_TN_BUILD()
  tnUI.onOk = onOk
  if tnUI.titleText then tnUI.titleText:SetText(title or "输入名称") end
  if tnUI.eb then
    pcall(tnUI.eb.SetText, tnUI.eb, cur or "")
    pcall(tnUI.eb.SetFocus, tnUI.eb)
  end
  if tnUI.echo then tnUI.echo:SetText(cur or "") end
  tnUI.root:Show()
end

-- 删除方案（至少保留一个；activeProfile 随删除左移/收敛）
function EVAL_WAR_DEL_PROFILE(idx)
  local w2 = warCfg()
  if table.getn(w2.profiles) <= 1 then say("至少保留一个方案") return false end
  if not w2.profiles[idx] then return false end
  say("已删除方案: " .. tostring(w2.profiles[idx].name))
  table.remove(w2.profiles, idx)
  if (w2.activeProfile or 1) > table.getn(w2.profiles) then
    w2.activeProfile = table.getn(w2.profiles)
  elseif (w2.activeProfile or 1) > idx then
    w2.activeProfile = (w2.activeProfile or 1) - 1
  end
  pcall(EVAL_WAR_TAB_REFRESH)
  return true
end

-- 一键宏 Tab 列表刷新（方案按钮选中态 / 技能行内容 / 图标选择器高亮）
function EVAL_WAR_TAB_REFRESH()
  if not EVAL_IS_SCANNED() then EVAL_GO_RESCAN(true) end -- 1.32.9 自愈：初始化重扫若早于动作条就绪，这里补扫（否则技能行图标全灰）
  local warUI = cfgWin.warUI
  if not warUI then return end
  local w2 = warCfg()
  for i, pb in ipairs(warUI.profBtns) do
    local prof = w2.profiles[i]
    if prof then
      pb.text:SetText(tostring(prof.name or ("方案" .. i)))
      local sel = (w2.activeProfile or 1) == i
      pcall(pb.bg.SetVertexColor, pb.bg, sel and 0.45 or 0.16, sel and 0.35 or 0.13, sel and 0.10 or 0.08, 1)
      pcall(pb.text.SetTextColor, pb.text, sel and 1 or 0.75, sel and 0.9 or 0.72, sel and 0.4 or 0.6)
    elseif i == table.getn(w2.profiles) + 1 then
      pb.text:SetText("+")
      pcall(pb.bg.SetVertexColor, pb.bg, 0.10, 0.10, 0.10, 1)
    else
      pb.text:SetText("")
      pcall(pb.bg.SetVertexColor, pb.bg, 0.06, 0.05, 0.04, 1)
    end
    -- [删] 仅存在的方案显示；待确认状态红色高亮
    if pb.del then
      if prof then
        pb.del:Show()
        local armed = (warUI.delArm == i) and (GetTime() - (warUI.delArmT or 0) < 5)
        pcall(pb.delBg.SetVertexColor, pb.delBg, armed and 0.75 or 0.25, 0.10, 0.10, 1)
      else
        pb.del:Hide()
      end
    end
  end
  local p = w2.profiles[w2.activeProfile or 1]
  -- 1.33.0 滚动：offset 收敛到合法范围；滚动按钮仅在超高时显示
  local cnt = (p and p.skills) and table.getn(p.skills) or 0
  local rowsN = table.getn(warUI.rows) -- 1.33.3 修：ROWS 是 cfgBuild 内 local，本函数拿不到（nil 算术报错）
  local maxOff = math.max(0, cnt - rowsN)
  warUI.offset = math.max(0, math.min(warUI.offset or 0, maxOff))
  if warUI.scrollUp then
    if cnt > rowsN then
      pcall(warUI.scrollUp.Show, warUI.scrollUp) pcall(warUI.scrollDn.Show, warUI.scrollDn)
    else
      pcall(warUI.scrollUp.Hide, warUI.scrollUp) pcall(warUI.scrollDn.Hide, warUI.scrollDn)
    end
  end
  for ri, row in ipairs(warUI.rows) do
    local r = p and p.skills[ri + warUI.offset]
    local widgets = { row.chk, row.icon, row.name, row.conds, row.up, row.dn, row.edit, row.del }
    for _, wgt in ipairs(widgets) do
      if r then pcall(wgt.Show, wgt) else pcall(wgt.Hide, wgt) end
    end
    if r then
      if r.enabled ~= false then row.mark:Show() else row.mark:Hide() end
      local t0 = wicon(r.skill)
      if t0 then
        pcall(row.icon.SetTexture, row.icon, t0)
        pcall(row.icon.SetVertexColor, row.icon, 1, 1, 1)
      else
        uiSolid(row.icon, 0.25, 0.25, 0.25, 1)
      end
      row.name:SetText(tostring(r.skill))
      row.conds:SetText(uiEsc(EVAL_GROUP_STR(r.groups))) -- 1.61.1 | 显示转义
    end
  end
end

-- Tab 切换：按控件列表显式 Show/Hide（本客户端可见性契约：走控件列表，不靠父框架传播）
function EVAL_HELP_CFG_SETTAB(idx)
  if not cfgWin.pages then return end
  cfgWin.tab = idx
  c().cfgTab = idx
  for i, p in ipairs(cfgWin.pages) do
    local on = (i == idx)
    for _, wgt in ipairs(p.widgets) do
      if on then pcall(wgt.Show, wgt) else pcall(wgt.Hide, wgt) end
    end
    if on then
      pcall(p.bg.SetVertexColor, p.bg, 0.45, 0.35, 0.10, 1)
      pcall(p.text.SetTextColor, p.text, 1, 0.90, 0.40)
    else
      pcall(p.bg.SetVertexColor, p.bg, 0.16, 0.13, 0.08, 1)
      pcall(p.text.SetTextColor, p.text, 0.70, 0.65, 0.55)
    end
  end
  if idx == 2 then pcall(EVAL_WAR_TAB_REFRESH) end
end

function EVAL_HELP_CFG_TOGGLE()
  local win = cfgBuild()
  if win:IsVisible() then
    win:Hide()
  else
    -- 每次弹窗计算位置：飞出屏幕（拖太远/改过分辨率）→ 回归视野中心
    if uiOffscreen(win) then
      win:ClearAllPoints()
      win:SetPoint("CENTER", UIParent, "CENTER", -320, 60)
      c().cfgPos = nil
    end
    if cfgWin.refresh then cfgWin.refresh() end
    EVAL_HELP_CFG_SETTAB(cfgWin.tab or c().cfgTab or 1)
    win:Show()
  end
end

-- 小地图图标：挂在小地图左侧的金色 EH 按钮。
-- UnrealQuest 实测要点：parent 用 UIParent（不是 Minimap——它是地图外的 chrome）；
-- 锚链 Minimap → MinimapCluster → UIParent 右上角；RegisterForClicks 注册点击；
-- 悬停用 OnEnter/OnLeave 改边框色 + GameTooltip 提示（不用 SetHighlightTexture）。
-- 按钮本身支持拖拽换位（Button 手柄配方），位置存 cfg.mbPos，重登恢复；
-- 拖动松手会跟着触发一次 OnClick，用 mbDragMoved 标记抑制这次误触。
local minimapBtn = nil
local mbDragMoved = false
do
  local mb = CreateFrame("Button", "EVAL_HELP_MINIMAP", UIParent)
  mb:SetWidth(24) mb:SetHeight(24)
  pcall(mb.SetFrameStrata, mb, "MEDIUM")
  pcall(mb.EnableMouse, mb, true)
  pcall(mb.RegisterForClicks, mb, "LeftButtonUp")
  pcall(mb.RegisterForDrag, mb, "LeftButton")
  local anchored = false
  if type(Minimap) == "table" or type(Minimap) == "userdata" then
    anchored = pcall(mb.SetPoint, mb, "TOPRIGHT", Minimap, "TOPLEFT", -6, 0)
  end
  if not anchored and (type(MinimapCluster) == "table" or type(MinimapCluster) == "userdata") then
    anchored = pcall(mb.SetPoint, mb, "TOPRIGHT", MinimapCluster, "TOPLEFT", -6, -6)
  end
  if not anchored then
    pcall(mb.SetPoint, mb, "TOPRIGHT", UIParent, "TOPRIGHT", -8, -8)
  end
  local ring = mb:CreateTexture(nil, "BACKGROUND")
  uiSolid(ring, 0.85, 0.70, 0.20, 1)
  ring:SetPoint("TOPLEFT", mb, "TOPLEFT", 0, 0)
  ring:SetPoint("BOTTOMRIGHT", mb, "BOTTOMRIGHT", 0, 0)
  local inner = mb:CreateTexture(nil, "ARTWORK")
  uiSolid(inner, 0.12, 0.10, 0.06, 1)
  inner:SetPoint("TOPLEFT", mb, "TOPLEFT", 2, -2)
  inner:SetPoint("BOTTOMRIGHT", mb, "BOTTOMRIGHT", -2, 2)
  local mt = uiText(mb, 11, 1, 0.85, 0.30)
  mt:SetPoint("CENTER", mb, "CENTER", 0, 0)
  mt:SetText("EH")
  mb:SetScript("OnDragStart", function()
    mbDragMoved = false
    pcall(mb.SetMovable, mb, true)
    pcall(mb.StartMoving, mb)              -- warm-up 两步（实测配方）
    pcall(mb.StopMovingOrSizing, mb)
    pcall(mb.StartMoving, mb)
  end)
  mb:SetScript("OnDragStop", function()
    pcall(mb.StopMovingOrSizing, mb)
    mbDragMoved = true
    local ok, point, _, relPoint, x, y = pcall(mb.GetPoint, mb, 1)
    if ok and type(point) == "string" then
      c().mbPos = {
        point = point,
        relPoint = (type(relPoint) == "string") and relPoint or point,
        x = (type(x) == "number") and x or 0,
        y = (type(y) == "number") and y or 0,
      }
    end
  end)
  mb:SetScript("OnEnter", function()
    pcall(ring.SetVertexColor, ring, 1, 0.88, 0.40, 1)
    if GameTooltip and GameTooltip.SetOwner then
      pcall(GameTooltip.SetOwner, GameTooltip, mb, "ANCHOR_LEFT")
      if GameTooltip.AddLine then
        pcall(GameTooltip.AddLine, GameTooltip, "全职业施法工具 · 设置")
        pcall(GameTooltip.AddLine, GameTooltip, "点击打开配置窗口，按住可拖动", 0.7, 0.7, 0.7)
      end
      pcall(GameTooltip.Show, GameTooltip)
    end
  end)
  mb:SetScript("OnLeave", function()
    pcall(ring.SetVertexColor, ring, 0.85, 0.70, 0.20, 1)
    if GameTooltip and GameTooltip.Hide then pcall(GameTooltip.Hide, GameTooltip) end
  end)
  mb:SetScript("OnClick", function()
    if mbDragMoved then mbDragMoved = false return end -- 拖动松手后的那次抬起不算点击
    EVAL_HELP_CFG_TOGGLE()
  end)
  minimapBtn = mb
end

-- ============ 状态信息 UI（展示 Cat 式角色状态表 EVAL_HELP_STATE 的实时值） ============
-- /eh st 开关；标题栏拖动（位置记忆+越界回归）；每 0.15s 刷新一次 EVAL_HELP_UPDATE_STATE()。
-- 内容 = 状态模块全部字段：玩家数值/战斗计时/姿态/修饰键/普攻 + 目标可攻击/可流血/精英Boss 等。

local stui = { root = nil, body = nil }
local stLastTick = 0
local ST_TICK = 0.15

local function stCfg()
  local cc = c()
  if not cc.st then cc.st = { enabled = false, x = 330, y = -180 } end
  return cc.st
end

local function stYesNo(v)
  return v and "|cff00ff00是|r" or "|cffff5040否|r"
end

function EVAL_HELP_ST_BUILD()
  local sc = stCfg()
  if stui.root then
    stui.root:Hide()
    pcall(stui.root.SetScript, stui.root, "OnUpdate", nil)
  end
  local W = 250
  local pad = 8
  local titleBarH = 16
  local root = CreateFrame("Frame", "EVAL_HELP_STUI", UIParent)
  pcall(root.SetFrameStrata, root, "MEDIUM")
  pcall(root.SetMovable, root, true)
  -- 本体不吃鼠标（UnrealQuest：容器 mouse-disabled，不吞世界点击）；拖动走标题栏 Button
  pcall(root.EnableMouse, root, false)

  local bg = root:CreateTexture(nil, "BACKGROUND")
  uiSolid(bg, 0.06, 0.05, 0.04, 0.92)
  bg:SetPoint("TOPLEFT", root, "TOPLEFT", 0, 0)
  bg:SetPoint("BOTTOMRIGHT", root, "BOTTOMRIGHT", 0, 0)
  for _, e in ipairs({ "TOP", "BOTTOM" }) do
    local t = root:CreateTexture(nil, "BORDER")
    uiSolid(t, 0.85, 0.70, 0.20, 1)
    t:SetPoint(e .. "LEFT", root, e .. "LEFT", 0, 0)
    t:SetPoint(e .. "RIGHT", root, e .. "RIGHT", 0, 0)
    t:SetHeight(1)
  end
  for _, side in ipairs({ "LEFT", "RIGHT" }) do
    local t = root:CreateTexture(nil, "BORDER")
    uiSolid(t, 0.85, 0.70, 0.20, 1)
    t:SetPoint("TOP" .. side, root, "TOP" .. side, 0, 0)
    t:SetPoint("BOTTOM" .. side, root, "BOTTOM" .. side, 0, 0)
    t:SetWidth(1)
  end

  -- 标题栏拖动柄（Button 配方）
  local titleBar = CreateFrame("Button", nil, root)
  titleBar:SetPoint("TOPLEFT", root, "TOPLEFT", 1, -1)
  titleBar:SetPoint("TOPRIGHT", root, "TOPRIGHT", -1, -1)
  titleBar:SetHeight(titleBarH)
  local okLvl, rootLvl = pcall(root.GetFrameLevel, root)
  if okLvl and type(rootLvl) == "number" then
    pcall(titleBar.SetFrameLevel, titleBar, rootLvl + 10)
  end
  local tbBg = titleBar:CreateTexture(nil, "BACKGROUND")
  uiSolid(tbBg, 0.16, 0.13, 0.08, 1)
  tbBg:SetPoint("TOPLEFT", titleBar, "TOPLEFT", 0, 0)
  tbBg:SetPoint("BOTTOMRIGHT", titleBar, "BOTTOMRIGHT", 0, 0)
  pcall(titleBar.EnableMouse, titleBar, true)
  pcall(titleBar.RegisterForClicks, titleBar, "LeftButtonUp")
  pcall(titleBar.RegisterForDrag, titleBar, "LeftButton")
  local title = uiText(titleBar, 10, 0.95, 0.82, 0.35)
  title:SetPoint("CENTER", titleBar, "CENTER", 0, 0)
  title:SetText("状态信息")
  titleBar:SetScript("OnDragStart", function()
    pcall(root.SetMovable, root, true)
    pcall(root.StartMoving, root)
    pcall(root.StopMovingOrSizing, root)
    pcall(root.StartMoving, root)
  end)
  titleBar:SetScript("OnDragStop", function()
    pcall(root.StopMovingOrSizing, root)
    local ok, cx, cy = pcall(root.GetCenter, root)
    if ok and cx then
      local okw, w2 = pcall(UIParent.GetWidth, UIParent)
      local okh, h2 = pcall(UIParent.GetHeight, UIParent)
      if okw and okh and w2 and h2 then
        local oke, es = pcall(root.GetEffectiveScale, root)
        local k = (oke and type(es) == "number" and es > 0) and es or 1
        sc.x = (cx - w2 / 2) / k
        sc.y = (cy - h2 / 2) / k
      end
    end
  end)

  -- 正文：一个多行 FontString，逐行展示状态变量
  local body = uiText(root, 10, 0.85, 0.85, 0.85)
  body:SetPoint("TOPLEFT", root, "TOPLEFT", pad, -(titleBarH + pad))
  pcall(body.SetWidth, body, W - pad * 2)
  pcall(body.SetJustifyH, body, "LEFT")

  root:SetWidth(W)
  root:SetHeight(titleBarH + pad * 2 + 15 * 14)
  root:ClearAllPoints()
  root:SetPoint("CENTER", UIParent, "CENTER", sc.x or 330, sc.y or -180)
  if uiOffscreen(root) then
    root:ClearAllPoints()
    root:SetPoint("CENTER", UIParent, "CENTER", 330, -180)
    sc.x, sc.y = 330, -180
  end

  stui.root, stui.body = root, body
  root:SetScript("OnUpdate", function()
    local now = GetTime()
    if now - stLastTick < ST_TICK then return end
    stLastTick = now
    EVAL_HELP_ST_TICK()
  end)
end

-- 每次心跳：刷新状态表，逐行重排正文（Cat 的 CatUI-Melee 状态行同款展示）
function EVAL_HELP_ST_TICK()
  if not stui.root or not stui.root:IsVisible() then return end
  EVAL_HELP_UPDATE_STATE()
  local lines = {}
  table.insert(lines, string.format("%s  Lv%d %s%s",
    st.playerName or "?", st.level or 0, st.classLoc or "",
    st.raceLoc and (" · " .. st.raceLoc) or ""))
  table.insert(lines, string.format("血 %d/%d (%.0f%%)", st.hp, st.hpMax, st.hpPct))
  table.insert(lines, string.format("%s %d/%d (%.0f%%)%s", powerLabel(), st.power, st.powerMax, st.powerPct,
    (st.class == "ROGUE" or st.class == "DRUID") and string.format(" · 连击 %d", st.combo or 0) or ""))
  table.insert(lines, string.format("%s%s · %s",
    st.inCombat and "|cffff5040战斗中|r" or "|cff80ff80非战斗|r",
    st.inCombat and string.format(" %.1fs", st.combatTime) or "",
    st.form or "无姿态"))
  table.insert(lines, string.format("Alt:%s Shift:%s Ctrl:%s 普攻:%s",
    stYesNo(st.alt), stYesNo(st.shift), stYesNo(st.ctrl), stYesNo(st.autoAttack)))
  if st.atkSpd then -- 1.55.0 挥击计时行：攻速 + 距下次攻击（无锚点数据=—）
    local rem = EVAL_SWING_REMAIN and EVAL_SWING_REMAIN()
    table.insert(lines, string.format("攻速 %.1fs · 距下次攻击 %s%s", st.atkSpd,
      rem and string.format("%.1fs", rem) or "—",
      st.atkSpdOff and string.format("（副手 %.1fs）", st.atkSpdOff) or ""))
  end
  if st.castName then -- 1.38.0 施法中实时显示（含读条剩余秒数）
    table.insert(lines, string.format("施法中: %s%s", tostring(st.castName),
      st.castUntil and string.format(" 剩%.1fs", math.max(0, st.castUntil - GetTime())) or ""))
  end
  if st.hasTarget then
    table.insert(lines, string.format("目标: %s  Lv%d%s%s",
      tostring(st.targetName), st.tLevel or 0,
      st.isBoss and " |cffff4040Boss|r" or "",
      (not st.isBoss and st.isElite) and " |cffff9040精英|r" or ""))
    table.insert(lines, string.format("目标血 %.0f%% · 距离:%s · 可攻击:%s · 可流血:%s · 关系:%s",
      st.tHpPct, st.tRange or "—", stYesNo(st.canAttack), stYesNo(st.canBleed),
      st.tFriendly and "友善" or (st.tNeutral and "中立" or (st.tHostile and "敌对" or "?"))))
    table.insert(lines, string.format("类型:%s 分级:%s%s · 职业:%s",
      st.tCreatureType or "?", st.tClassification or "?",
      st.tInCombat and " · 目标战斗中" or "",
      tostring(st.tClassName or st.tClass or "?")))
  else
    table.insert(lines, "目标: |cff808080无|r")
  end
  -- 最近释放：技能 + 触发原因 + 条件逐项判定明细（规则引擎 trace）
  if st.castLog and table.getn(st.castLog) > 0 then
    table.insert(lines, "|cffc8a04a— 最近释放 —|r")
    local now = GetTime()
    for i = 1, 3 do
      local e = st.castLog[i]
      if not e then break end
      local ago = now - (e.t or now)
      table.insert(lines, string.format("|cff909090%.0fs前|r |cffffd050%s|r%s%s",
        ago, tostring(e.skill),
        (e.target and e.target ~= "") and ("→" .. e.target) or "",
        (e.why and e.why ~= "") and (" |cff909090← " .. tostring(e.why) .. "|r") or ""))
      if e.trace and e.trace ~= "" then
        table.insert(lines, "  |cff70b070" .. e.trace .. "|r")
      end
    end
  end
  stui.body:SetText(table.concat(lines, "\n"))
end

function EVAL_HELP_ST_TOGGLE()
  local sc = stCfg()
  if stui.root and stui.root:IsVisible() then
    stui.root:Hide()
    sc.enabled = false
    say("状态信息UI: |cffff0000关|r")
  else
    EVAL_HELP_ST_BUILD()
    if stui.root then stui.root:Show() end
    sc.enabled = true
    say("状态信息UI: |cff00ff00开|r（Cat 状态变量实时总览）")
  end
end

-- ============ 技能编辑窗（技能循环选择 + 独立条件属性行 + & / | 连接符） ============
-- 编辑模型：ed.conds = 线性条件列表 { {conn=nil|"&"|"|", cd=条件}, ... }；
-- conn 语义：& 并入当前组、| 新开一组 → 与引擎 groups（组内 & 、组间 | ）一一对应。
-- 本客户端无下拉控件：技能/条件类型/比较符/技能名全部用「点击循环」按钮实现。

local SE_TYPES = {
  { id = "power",      name = "怒气/能量",   kind = "num",   n = 30 },
  { id = "tHpPct",     name = "目标血%",     kind = "num",   n = 10 },
  { id = "hpPct",      name = "自身血%",     kind = "num",   n = 50 },
  { id = "powerPct",   name = "能量%",       kind = "num",   n = 10 },
  { id = "combatTime", name = "进战秒数",    kind = "num",   n = 3 },
  { id = "combo",      name = "连击点数",    kind = "num",   n = 1 }, -- 1.54.4 初始值 1（域 1-5）
  { id = "swingLeft",  name = "距下次攻击",  kind = "num",   n = 0.1 }, -- 1.57.0 挥击计时（秒）；1.58.0 时间型初始 0.1
  { id = "combat",     name = "战斗状态",    kind = "bool" },
  { id = "hasTarget",  name = "目标存在",    kind = "bool" },
  { id = "canAttack",  name = "目标可攻击",  kind = "bool" },
  { id = "canBleed",   name = "目标可流血",  kind = "bool" },
  { id = "tFriendly",  name = "目标友善",    kind = "bool" },
  { id = "tHostile",   name = "目标敌对",    kind = "bool" },
  { id = "tNeutral",   name = "目标中立",    kind = "bool" },
  { id = "isElite",    name = "目标精英",    kind = "bool" },
  { id = "isBoss",     name = "目标Boss",    kind = "bool" },
  { id = "tInCombat",  name = "目标战斗中",  kind = "bool" },
  { id = "autoAttack", name = "普攻已开",    kind = "bool" },
  { id = "autoShot",   name = "自动射击已开", kind = "bool" }, -- 1.51.0 猎人
  { id = "wandShoot",  name = "魔杖射击已开", kind = "bool" }, -- 1.51.0 法系
  { id = "alt",        name = "Alt按住",     kind = "bool" },
  { id = "shift",      name = "Shift按住",   kind = "bool" },
  { id = "ctrl",       name = "Ctrl按住",    kind = "bool" },
  { id = "form",       name = "当前姿态",    kind = "form" },
  { id = "hasBuff",    name = "自身buff检查",   kind = "skill", s = "战斗怒吼" }, -- 1.54.0 合并（是/否切换）
  { id = "pDebuff",    name = "自身debuff检查", kind = "skill", s = "" },          -- 1.54.0 新增
  { id = "hasDebuff",  name = "目标debuff检查", kind = "skill", s = "断筋" },      -- 1.54.0 合并（是/否切换）
  { id = "tBuff",      name = "目标buff检查",   kind = "skill", s = "" },          -- 1.54.0 新增
  { id = "ready",      name = "冷却就绪",    kind = "flag" },
  { id = "usable",     name = "技能可用",    kind = "flag" },
  { id = "notQueued",  name = "未排队",      kind = "flag" },
  { id = "target",     name = "选取目标",    kind = "target", s = "nearEnemy", hidden = true }, -- 1.32.0 提为技能级（技能下拉「目标选取」），新增条件下拉不再提供；存量条件仍渲染/求值
  { id = "tClass",     name = "目标职业",    kind = "class" },
  { id = "immune",    name = "目标免疫技能", kind = "skill", s = "撕裂" }, -- 1.36.1 免疫学习表判定
  { id = "inRange",   name = "施法范围内",  kind = "skill", s = "冲锋" }, -- 1.37.0 IsActionInRange
  { id = "casting",   name = "施法中",      kind = "skill", s = "" }, -- 1.38.0 SPELLCAST_* 事件驱动 -- 1.41.0 默认空=任意施法
  { id = "castEl",    name = "自身读条进行", kind = "num", n = 0.1 }, -- 1.58.0 时间型：初始 0.1（步进 0.1 区间 0-10）
  { id = "castLeft",  name = "自身读条剩余", kind = "num", n = 0.1 },
  { id = "tCasting",  name = "目标施法中",  kind = "skill", s = "" }, -- 1.40.0 空参数=任意施法
  { id = "tCastEl",   name = "读条已进行",  kind = "num", n = 0.1 }, -- 1.58.0 时间型：初始 0.1
  { id = "tCastLeft", name = "读条剩余",    kind = "num", n = 0.1 },
}
local SE_BY_K = {}
for i, td in ipairs(SE_TYPES) do SE_BY_K[td.id] = i end
SE_BY_K["formNot"] = SE_BY_K["form"]
SE_BY_K["noBuff"] = SE_BY_K["hasBuff"] -- 1.54.0 存量数据归并显示
SE_BY_K["noDebuff"] = SE_BY_K["hasDebuff"]
local SE_OPS = { ">", ">=", "<", "<=", "==", "~=" }

-- 条件类型分组（1.32.5 下拉美化）：金色组标题行不可选；SE_TYPES 本体顺序不动，仅展示层分组
local SE_TYPE_GROUPS = {
  { label = "CTG_1", ids = { "power", "hpPct", "powerPct", "combatTime", "combo", "swingLeft", "combat", "autoAttack", "autoShot", "wandShoot", "alt", "shift", "ctrl", "form", "castEl", "castLeft" } },
  { label = "CTG_2", ids = { "tHpPct", "hasTarget", "canAttack", "canBleed", "tFriendly", "tHostile", "tNeutral", "isElite", "isBoss", "tInCombat", "tClass", "immune", "tCasting", "tCastEl", "tCastLeft" } },
  { label = "CTG_3", ids = { "hasBuff", "pDebuff", "hasDebuff", "tBuff" } }, -- 1.54.0 光环检查四型
  { label = "CTG_4", ids = { "ready", "usable", "notQueued", "inRange", "casting" } },
}

local seUI = { root = nil, ed = nil, rows = {} }

local function seDefaultCond(ti)
  local td = SE_TYPES[ti]
  if td.kind == "num" then return { k = td.id, op = ">", n = td.n }
  elseif td.kind == "bool" then return { k = td.id, v = true }
  elseif td.kind == "form" then return { k = "form", n = 1 }
  elseif td.kind == "skill" then
    local cd0 = { k = td.id, s = td.s }
    if td.id == "hasBuff" or td.id == "hasDebuff" or td.id == "tBuff" or td.id == "pDebuff" then cd0.v = true end -- 1.54.0 光环检查型默认「是」
    return cd0
  elseif td.kind == "target" then return { k = td.id, s = td.s }
  elseif td.kind == "class" then return { k = td.id, cs = { WARRIOR = true } }
  else return { k = td.id } end
end

-- groups → 线性编辑列表（复制条件，避免保存前污染已存数据）
local function seGroupsToLinear(groups)
  local list = {}
  for gi, g in ipairs(groups or {}) do
    for ci, cd in ipairs(g) do
      local conn
      if gi > 1 and ci == 1 then conn = "|"
      elseif ci > 1 then conn = "&" end
      local cp = {}
      for k, v in pairs(cd) do
        if type(v) == "table" then -- cs 等表字段拷一层，避免编辑期污染已存数据
          local c2 = {}
          for k2, v2 in pairs(v) do c2[k2] = v2 end
          cp[k] = c2
        else
          cp[k] = v
        end
      end
      -- 1.54.0 存量归一：noBuff/noDebuff → hasBuff/hasDebuff + v=false（编辑保存后即新格式）
      if cp.k == "noBuff" then cp.k = "hasBuff" cp.v = false
      elseif cp.k == "noDebuff" then cp.k = "hasDebuff" cp.v = false end
      table.insert(list, { conn = conn, cd = cp })
    end
  end
  return list
end

-- 线性列表 → groups：| 新开组，& 并入当前组
local function seLinearToGroups(list)
  local groups, cur = {}, nil
  for _, it in ipairs(list or {}) do
    if it.conn == "|" or not cur then
      cur = {}
      table.insert(groups, cur)
    end
    if it.cd then table.insert(cur, it.cd) end
  end
  return groups
end

local function seBtn(parent, x, y, w, h, label, fn)
  local b = CreateFrame("Button", nil, parent)
  b:SetWidth(w) b:SetHeight(h)
  b:SetPoint("TOPLEFT", parent, "TOPLEFT", x, y)
  pcall(b.EnableMouse, b, true)
  pcall(b.RegisterForClicks, b, "LeftButtonUp")
  local bb = b:CreateTexture(nil, "BACKGROUND")
  uiSolid(bb, 0.16, 0.13, 0.08, 1)
  bb:SetPoint("TOPLEFT", b, "TOPLEFT", 0, 0)
  bb:SetPoint("BOTTOMRIGHT", b, "BOTTOMRIGHT", 0, 0)
  local bt = uiText(b, 9, 0.92, 0.88, 0.80)
  bt:SetPoint("CENTER", b, "CENTER", 0, 0)
  bt:SetText(label)
  b:SetScript("OnClick", fn)
  return { btn = b, bg = bb, text = bt }
end

-- ===== 全局模拟下拉列表面板（1.19.0 由 SE 专用泛化：任意窗口可调用） =====
-- EVAL_DD_OPEN(锚点按钮, 选项表, 回调)；多列 12 行/列，贴屏底自动上翻；EVAL_DD_HIDE() 收起。
local DD_COLS = 12
local ddUI = {}

local function DD_BUILD()
  if ddUI.root then return end
  local dd = CreateFrame("Frame", "EVAL_HELP_DD", UIParent)
  pcall(dd.SetFrameStrata, dd, "DIALOG")
  pcall(dd.SetFrameLevel, dd, 250)
  pcall(dd.EnableMouse, dd, true)
  local bg = dd:CreateTexture(nil, "BACKGROUND")
  uiSolid(bg, 0.06, 0.05, 0.04, 0.98)
  bg:SetPoint("TOPLEFT", dd, "TOPLEFT", 0, 0)
  bg:SetPoint("BOTTOMRIGHT", dd, "BOTTOMRIGHT", 0, 0)
  for _, e in ipairs({ "TOP", "BOTTOM" }) do
    local t = dd:CreateTexture(nil, "BORDER")
    uiSolid(t, 0.85, 0.70, 0.20, 1)
    t:SetPoint(e .. "LEFT", dd, e .. "LEFT", 0, 0)
    t:SetPoint(e .. "RIGHT", dd, e .. "RIGHT", 0, 0)
    t:SetHeight(1)
  end
  for _, side in ipairs({ "LEFT", "RIGHT" }) do
    local t = dd:CreateTexture(nil, "BORDER")
    uiSolid(t, 0.85, 0.70, 0.20, 1)
    t:SetPoint("TOP" .. side, dd, "TOP" .. side, 0, 0)
    t:SetPoint("BOTTOM" .. side, dd, "BOTTOM" .. side, 0, 0)
    t:SetWidth(1)
  end
  ddUI.rows = {}
  for i = 1, 48 do -- 1.27.0 加倍：技能清单+实时debuff/buff 追加项可能超 24
    local rb = CreateFrame("Button", nil, dd)
    rb:SetWidth(104) rb:SetHeight(14)
    pcall(rb.EnableMouse, rb, true)
    pcall(rb.RegisterForClicks, rb, "LeftButtonUp")
    local rbg = rb:CreateTexture(nil, "BACKGROUND")
    uiSolid(rbg, 0.10, 0.09, 0.06, 1)
    rbg:SetPoint("TOPLEFT", rb, "TOPLEFT", 0, 0)
    rbg:SetPoint("BOTTOMRIGHT", rb, "BOTTOMRIGHT", 0, 0)
    local rt = uiText(rb, 9, 0.85, 0.85, 0.85)
    rt:SetPoint("LEFT", rb, "LEFT", 4, 0)
    local ri = rb:CreateTexture(nil, "ARTWORK") -- 1.32.4 可选图标列（opts.icons）
    ri:SetWidth(12) ri:SetHeight(12)
    ri:SetPoint("LEFT", rb, "LEFT", 2, 0)
    ri:Hide()
    rb:SetScript("OnEnter", function() pcall(rbg.SetVertexColor, rbg, 0.38, 0.30, 0.10, 1) end)
    rb:SetScript("OnLeave", function() pcall(rbg.SetVertexColor, rbg, 0.10, 0.09, 0.06, 1) end)
    ddUI.rows[i] = { btn = rb, bg = rbg, text = rt, icon = ri }
  end
  dd:Hide()
  ddUI.root = dd
end

function EVAL_DD_HIDE() if ddUI.root then ddUI.root:Hide() end ddUI.anchor = nil end

-- anchorBtn 下方展开 items 列表；onPick(序号) 回调
-- opts.multi=true 多选模式（1.26.0）：点按切换选中（√ 金标）不关面板，onPick(序号, 是否选中) 逐项回调；
-- opts.selected = { [序号]=true } 初始选中集（面板重开时重建传入）。收起走 EVAL_DD_HIDE()/宿主窗 OnHide。
function EVAL_DD_OPEN(anchorBtn, items, onPick, opts)
  DD_BUILD()
  local dd = ddUI.root
  if not dd then return end
  -- 1.32.5 重复点击同一触发按钮 = 收起下拉（toggle）
  local okS, shown = pcall(dd.IsShown, dd)
  if okS and shown and ddUI.anchor == anchorBtn then EVAL_DD_HIDE() return end
  ddUI.anchor = anchorBtn
  ddUI.multi = (opts and opts.multi) and true or false
  ddUI.sel = (ddUI.multi and (opts.selected or {})) or nil -- 1.32.0 审计修复：multi 未传 selected 时索引 nil 隐患
  local n = table.getn(items)
  local cols = math.ceil(n / DD_COLS)
  local icons = opts and opts.icons -- 1.32.4 可选图标列：与 items 同序的纹理表
  local colW = icons and 124 or 108
  for i, row in ipairs(ddUI.rows) do
    if i <= n then
      local pi = i
      local ic = icons and icons[i]
      if ic then
        pcall(row.icon.SetTexture, row.icon, ic)
        row.icon:Show()
        row.text:ClearAllPoints()
        row.text:SetPoint("LEFT", row.btn, "LEFT", 18, 0)
      else
        row.icon:Hide()
        row.text:ClearAllPoints()
        row.text:SetPoint("LEFT", row.btn, "LEFT", 4, 0)
      end
      if ddUI.multi then
        local function paint()
          local on = ddUI.sel and ddUI.sel[pi] and true or false
          row.text:SetText((on and "|cffffd100√|r " or "") .. tostring(items[pi]))
        end
        paint()
        row.btn:SetScript("OnClick", function()
          local nowOn = not (ddUI.sel[pi] and true or false)
          ddUI.sel[pi] = nowOn or nil
          paint()
          onPick(pi, nowOn)
        end)
      else
        row.text:SetText(tostring(items[i]))
        row.btn:SetScript("OnClick", function() dd:Hide() onPick(pi) end)
      end
      local col = math.floor((i - 1) / DD_COLS)
      local ri = math.mod(i - 1, DD_COLS)
      row.btn:ClearAllPoints()
      row.btn:SetPoint("TOPLEFT", dd, "TOPLEFT", 4 + col * colW, -4 - ri * 15)
      row.btn:Show()
    else
      row.btn:Hide()
    end
  end
  local rows = math.min(n, DD_COLS)
  dd:SetWidth(8 + cols * colW)
  dd:SetHeight(8 + rows * 15)
  dd:ClearAllPoints()
  dd:SetPoint("TOPLEFT", anchorBtn, "BOTTOMLEFT", 0, -2)
  -- 贴屏底时改为向上展开
  local okb, ab = pcall(anchorBtn.GetBottom, anchorBtn)
  if okb and type(ab) == "number" then
    local oke, es = pcall(dd.GetEffectiveScale, dd)
    local k = (oke and type(es) == "number" and es > 0) and es or 1
    if ab < (8 + rows * 15) * k + 20 then
      dd:ClearAllPoints()
      dd:SetPoint("BOTTOMLEFT", anchorBtn, "TOPLEFT", 0, 2)
    end
  end
  dd:Show()
end

function EVAL_HELP_SE_REFRESH()
  local ed = seUI.ed
  if not ed or not seUI.root then return end
  -- 技能选择器
  local t0 = wicon(ed.skill)
  if t0 then
    pcall(seUI.skillIcon.SetTexture, seUI.skillIcon, t0)
    pcall(seUI.skillIcon.SetVertexColor, seUI.skillIcon, 1, 1, 1)
  else
    uiSolid(seUI.skillIcon, 0.25, 0.25, 0.25, 1)
  end
  seUI.skillName:SetText(tostring(ed.skill))
  if seUI.catName then -- 分类按钮文字 = 当前技能所属类（1.32.3）
    local cl = { L("SK_CAT_1"), L("SK_CAT_2"), L("SK_CAT_3"), L("SK_CAT_4"), L("SK_CAT_5") }
    local ci = 2
    if ed.skill == "攻击" or ed.skill == "自动射击" or ed.skill == "射击" or cancelCastOf(ed.skill) or stanceOf(ed.skill) then ci = 1
    elseif petCmdOf(ed.skill) then ci = 3
    elseif targetSelOf(ed.skill) then ci = 4
    elseif itemOf(ed.skill) then ci = 5 end
    seUI.catName:SetText(cl[ci])
  end
  if ed.enabled then seUI.enMark:Show() else seUI.enMark:Hide() end
  -- 条件行
  for i, row in ipairs(seUI.rows) do
    local it = ed.conds[i]
    for _, wgt in ipairs(row.all) do pcall(wgt.Hide, wgt) end
    if it then
      local cd = it.cd
      row.conn.text:SetText(i == 1 and "当" or ((it.conn == "|") and "｜" or (it.conn or "&"))) -- 1.61.2 关系列同用全角竖线
      pcall(row.conn.btn.Show, row.conn.btn)
      local ti = SE_BY_K[cd.k] or 1
      local td = SE_TYPES[ti]
      row.typeBtn.text:SetText(L("CT_" .. string.upper(td.id)))
      pcall(row.typeBtn.btn.Show, row.typeBtn.btn)
      if td.kind == "num" then
        row.opBtn.text:SetText(cd.op or ">")
        -- 1.58.0 时间型一位小数显示（步进 0.1；防 0.30000000004 浮点噪音）
        local isTime = (cd.k == "swingLeft" or cd.k == "castEl" or cd.k == "castLeft" or cd.k == "tCastEl" or cd.k == "tCastLeft")
        row.valText:SetText(isTime and string.format("%.1f", cd.n or 0) or tostring(cd.n or 0))
        pcall(row.opBtn.btn.Show, row.opBtn.btn)
        pcall(row.minus.btn.Show, row.minus.btn)
        pcall(row.plus.btn.Show, row.plus.btn)
        pcall(row.valText.Show, row.valText)
      elseif td.kind == "bool" then
        row.valBtn.text:SetText(cd.v and "是" or "否")
        pcall(row.valBtn.btn.Show, row.valBtn.btn)
      elseif td.kind == "flag" then
        row.valBtn.text:SetText(cd.inv and "否" or "是")
        pcall(row.valBtn.btn.Show, row.valBtn.btn)
      elseif td.kind == "form" then
        row.valBtn.text:SetText(cd.k == "formNot" and "非" or "是")
        row.formN.text:SetText(tostring(cd.n or 1))
        pcall(row.valBtn.btn.Show, row.valBtn.btn)
        pcall(row.formN.btn.Show, row.formN.btn)
      elseif td.kind == "skill" then
        local disp = tostring(cd.s or "?")
        if cd.k == "tCasting" and (cd.s == nil or cd.s == "") then disp = L("TCAST_ANY") end -- 1.40.0 空参数=任意施法
        if cd.k == "casting" and (cd.s == nil or cd.s == "") then disp = L("TCAST_ANY") end -- 1.41.0 自身施法同规
        local auraChk = (cd.k == "hasBuff" or cd.k == "hasDebuff" or cd.k == "tBuff" or cd.k == "pDebuff") -- 1.54.0 光环检查型 是/否
        if cd.k == "immune" or cd.k == "inRange" or cd.k == "casting" or cd.k == "tCasting" or auraChk then
          if cd.k == "inRange" or cd.k == "casting" or cd.k == "tCasting" or auraChk then
            row.immBtn.text:SetText((cd.v == false) and L("SE_NO") or L("SE_YES"))
          else
            row.immBtn.text:SetText((cd.v == false) and L("IMM_N") or L("IMM_Y"))
          end
          pcall(row.immBtn.btn.Show, row.immBtn.btn)
        end
        local isDebuff = (cd.k == "hasDebuff" or cd.k == "noDebuff")
        if isDebuff then
          if type(cd.n) == "number" and cd.n > 1 then
            disp = disp .. (((cd.k == "noDebuff" or cd.v == false) and " <" or " ≥") .. cd.n) -- 1.54.0 合并后看 v 方向
          end
          row.stk.text:SetText(type(cd.n) == "number" and cd.n > 1 and ("层" .. cd.n) or "层")
          pcall(row.stk.btn.Show, row.stk.btn)
        end
        row.skillText:SetText(disp)
        pcall(row.sHit.Show, row.sHit)
        pcall(row.skillText.Show, row.skillText)
      elseif td.kind == "target" then
        local disp = (cd.s == "byName") and ("指定:" .. tostring(cd.nm or "未设")) or (TARGET_SEL_NAME[cd.s] or tostring(cd.s or "?"))
        row.skillText:SetText(disp)
        pcall(row.sHit.Show, row.sHit)
        pcall(row.skillText.Show, row.skillText)
      elseif td.kind == "class" then
        local ns = {}
        for _, c in ipairs(CLASS_LIST) do if cd.cs and cd.cs[c.id] then table.insert(ns, c.name) end end
        row.skillText:SetText(table.getn(ns) > 0 and table.concat(ns, "/") or "未选择（永不满足）")
        pcall(row.sHit.Show, row.sHit)
        pcall(row.skillText.Show, row.skillText)
      end
      row.preview:SetText(EVAL_COND_STR(cd))
      pcall(row.preview.Show, row.preview)
      pcall(row.del.btn.Show, row.del.btn)
    end
  end
  -- 底部实时预览（整串条件）
  seUI.preview:SetText(uiEsc(EVAL_GROUP_STR(seLinearToGroups(ed.conds)))) -- 1.61.1 | 显示转义
end

local function SE_BUILD()
  if seUI.root then return end
  local W, H = 470, 280
  local root = CreateFrame("Frame", "EVAL_HELP_SE", UIParent)
  root:SetWidth(W) root:SetHeight(H)
  root:SetPoint("CENTER", UIParent, "CENTER", 60, 80)
  -- 配置窗是 DIALOG strata：本窗必须同级 + 更高 frameLevel，否则被配置窗盖住（1.11.2 修复）
  pcall(root.SetFrameStrata, root, "DIALOG")
  pcall(root.SetFrameLevel, root, 100)
  pcall(root.SetMovable, root, true)
  pcall(root.EnableMouse, root, true)
  if uiOffscreen(root) then -- 越界回归视野中心
    root:ClearAllPoints()
    root:SetPoint("CENTER", UIParent, "CENTER", 0, 60)
  end
  local bg = root:CreateTexture(nil, "BACKGROUND")
  uiSolid(bg, 0.06, 0.05, 0.04, 0.97)
  bg:SetPoint("TOPLEFT", root, "TOPLEFT", 0, 0)
  bg:SetPoint("BOTTOMRIGHT", root, "BOTTOMRIGHT", 0, 0)
  for _, e in ipairs({ "TOP", "BOTTOM" }) do
    local t = root:CreateTexture(nil, "BORDER")
    uiSolid(t, 0.85, 0.70, 0.20, 1)
    t:SetPoint(e .. "LEFT", root, e .. "LEFT", 0, 0)
    t:SetPoint(e .. "RIGHT", root, e .. "RIGHT", 0, 0)
    t:SetHeight(1)
  end
  for _, side in ipairs({ "LEFT", "RIGHT" }) do
    local t = root:CreateTexture(nil, "BORDER")
    uiSolid(t, 0.85, 0.70, 0.20, 1)
    t:SetPoint("TOP" .. side, root, "TOP" .. side, 0, 0)
    t:SetPoint("BOTTOM" .. side, root, "BOTTOM" .. side, 0, 0)
    t:SetWidth(1)
  end
  local titleBar = CreateFrame("Button", nil, root)
  titleBar:SetPoint("TOPLEFT", root, "TOPLEFT", 1, -1)
  titleBar:SetPoint("TOPRIGHT", root, "TOPRIGHT", -1, -1)
  titleBar:SetHeight(16)
  local okLvl, rootLvl = pcall(root.GetFrameLevel, root)
  if okLvl and type(rootLvl) == "number" then pcall(titleBar.SetFrameLevel, titleBar, rootLvl + 10) end
  local tbBg = titleBar:CreateTexture(nil, "BACKGROUND")
  uiSolid(tbBg, 0.16, 0.13, 0.08, 1)
  tbBg:SetPoint("TOPLEFT", titleBar, "TOPLEFT", 0, 0)
  tbBg:SetPoint("BOTTOMRIGHT", titleBar, "BOTTOMRIGHT", 0, 0)
  pcall(titleBar.EnableMouse, titleBar, true)
  pcall(titleBar.RegisterForClicks, titleBar, "LeftButtonUp")
  pcall(titleBar.RegisterForDrag, titleBar, "LeftButton")
  local title = uiText(titleBar, 10, 0.95, 0.82, 0.35)
  title:SetPoint("CENTER", titleBar, "CENTER", 0, 0)
  title:SetText(L("SE_TITLE"))
  titleBar:SetScript("OnDragStart", function()
    pcall(root.SetMovable, root, true)
    pcall(root.StartMoving, root)
    pcall(root.StopMovingOrSizing, root)
    pcall(root.StartMoving, root)
  end)
  titleBar:SetScript("OnDragStop", function() pcall(root.StopMovingOrSizing, root) end)

  -- 技能选择行（1.32.3 二级下拉 UI）：[分类▾] [图标] [具体项▾]　启用
  -- 分类按钮在左（替代旧"技能:"标签位），项按钮在右——点哪个弹哪级，所见即两级
  local function seCatOfSkill(skill) -- 技能名 → 分类序号（EVAL_GO_SKILL_CATEGORIES 顺序）
    if skill == "攻击" or skill == "自动射击" or skill == "射击" or cancelCastOf(skill) or stanceOf(skill) then return 1 end
    if petCmdOf(skill) then return 3 end
    if targetSelOf(skill) then return 4 end
    if itemOf(skill) then return 5 end
    return 2
  end
  -- 项列表 → 图标表（1.32.4：下拉行左侧显示技能/物品图标；wicon 统一入口含宠物/选取/物品兜底）
  local function seItemIcons(items)
    local icons, any = {}, false
    for i, v in ipairs(items) do
      local nm = string.match(v, "^(物品[:：].-)×%d+$") or v
      local t = wicon(nm)
      if t then icons[i] = t any = true end
    end
    return any and icons or nil
  end
  -- 项选中落值（两个下拉共用）：特殊项弹输入框，物品项剥 ×数量 展示后缀
  local function seApplySkillPick(v)
    if not v then return end
    if v == L("SE_PICK_ITEM") then
      EVAL_TN_OPEN(L("SE_TN_ITEM"), "", function(nm)
        if nm and nm ~= "" then seUI.ed.skill = "物品:" .. nm EVAL_HELP_SE_REFRESH() end
      end)
      return
    end
    if v == L("SE_PICK_TGT") then
      EVAL_TN_OPEN(L("SE_TN_TARGET"), "", function(nm)
        if nm and nm ~= "" then seUI.ed.skill = "选取目标:指定名称:" .. nm EVAL_HELP_SE_REFRESH() end
      end)
      return
    end
    seUI.ed.skill = string.match(v, "^(物品[:：].-)×%d+$") or v
    EVAL_HELP_SE_REFRESH()
  end
  -- 分类下拉（一级）
  local catW = seBtn(root, 16, -24, 72, 16, "", function()
    if not seUI.ed then return end
    local cats = EVAL_GO_SKILL_CATEGORIES()
    local labels = {}
    for _, c in ipairs(cats) do table.insert(labels, c.label) end
    EVAL_DD_OPEN(seUI.catBtn, labels, function(ci)
      local cat = cats[ci]
      if not cat then return end
      -- 选完分类立即续弹该类的项列表（沿用 byName 续弹范式）
      local items = cat.items()
      EVAL_DD_OPEN(seUI.skillBtn, items, function(pi)
        seApplySkillPick(items[pi])
      end, { icons = seItemIcons(items) })
    end)
  end)
  seUI.catBtn = catW.btn
  seUI.catName = catW.text
  local icon = root:CreateTexture(nil, "ARTWORK")
  icon:SetPoint("TOPLEFT", root, "TOPLEFT", 94, -24)
  icon:SetWidth(15) icon:SetHeight(15)
  seUI.skillIcon = icon
  -- 具体项下拉（二级）：直接弹当前分类的项列表
  -- 注意：seBtn 返回包裹表 { btn, bg, text }，不是按钮本体——锚点/加文字一律用 .btn（1.21.4 修复）
  local skW = seBtn(root, 114, -24, 100, 16, "", function()
    if not seUI.ed then return end
    local cats = EVAL_GO_SKILL_CATEGORIES()
    local cat = cats[seCatOfSkill(seUI.ed.skill)]
    if not cat then return end
    local items = cat.items()
    EVAL_DD_OPEN(seUI.skillBtn, items, function(pi)
      seApplySkillPick(items[pi])
    end, { icons = seItemIcons(items) })
  end)
  local skBtn = skW.btn
  seUI.skillBtn = skBtn
  local skName = uiText(skBtn, 10, 1, 0.9, 0.5)
  skName:SetPoint("CENTER", skBtn, "CENTER", 0, 0)
  pcall(skName.SetWidth, skName, 96) -- 长名（物品:xxx）裁剪防溢出到启用框
  pcall(skName.SetNonSpaceWrap, skName, false)
  seUI.skillName = skName
  local enChk = CreateFrame("Button", nil, root)
  enChk:SetWidth(14) enChk:SetHeight(14)
  enChk:SetPoint("TOPLEFT", root, "TOPLEFT", 216, -25)
  pcall(enChk.EnableMouse, enChk, true)
  pcall(enChk.RegisterForClicks, enChk, "LeftButtonUp")
  local enOut = enChk:CreateTexture(nil, "BACKGROUND")
  uiSolid(enOut, 0.85, 0.70, 0.20, 1)
  enOut:SetPoint("TOPLEFT", enChk, "TOPLEFT", 0, 0)
  enOut:SetPoint("BOTTOMRIGHT", enChk, "BOTTOMRIGHT", 0, 0)
  local enIn = enChk:CreateTexture(nil, "ARTWORK")
  uiSolid(enIn, 0.10, 0.09, 0.06, 1)
  enIn:SetPoint("TOPLEFT", enChk, "TOPLEFT", 1, -1)
  enIn:SetPoint("BOTTOMRIGHT", enChk, "BOTTOMRIGHT", -1, 1)
  local enMark = enChk:CreateTexture(nil, "OVERLAY")
  uiSolid(enMark, 0.95, 0.80, 0.25, 1)
  enMark:SetPoint("TOPLEFT", enChk, "TOPLEFT", 3, -3)
  enMark:SetPoint("BOTTOMRIGHT", enChk, "BOTTOMRIGHT", -3, 3)
  enChk:SetScript("OnClick", function()
    if seUI.ed then seUI.ed.enabled = not seUI.ed.enabled EVAL_HELP_SE_REFRESH() end
  end)
  seUI.enMark = enMark
  local enLabel = uiText(root, 9, 0.75, 0.75, 0.75)
  enLabel:SetPoint("TOPLEFT", root, "TOPLEFT", 234, -27)
  enLabel:SetText(L("SE_ENABLE"))

  -- 条件表头
  local hd = uiText(root, 9, 0.60, 0.55, 0.40)
  hd:SetPoint("TOPLEFT", root, "TOPLEFT", 16, -48)
  hd:SetText(L("SE_HEADER"))

  -- 8 行条件池
  for i = 1, 8 do
    local y = -64 - (i - 1) * 20
    local row = { all = {} }
    local function reg(w) table.insert(row.all, w) return w end
    row.conn = seBtn(root, 16, y, 26, 15, L("SE_WHEN"), function()
      local ed = seUI.ed
      if ed and i > 1 and ed.conds[i] then
        ed.conds[i].conn = (ed.conds[i].conn == "|") and "&" or "|"
        EVAL_HELP_SE_REFRESH()
      end
    end)
    reg(row.conn.btn)
    row.typeBtn = seBtn(root, 46, y, 92, 15, L("SE_TYPE_PH"), function()
      -- 点开下拉列表：全部 26 种条件类型可见可选（1.14.0：替代盲循环；1.25.0 选取目标；1.26.0 目标职业；1.28.0 连击点数）
      local ed = seUI.ed
      local it = ed and ed.conds[i]
      if not it then return end
      -- 1.32.5 分组美化：金色组标题（idxMap=0 不可选）+ 四类分组；hidden 类型（选取目标）不进下拉
      local items, idxMap = {}, {}
      for _, grp in ipairs(SE_TYPE_GROUPS) do
        table.insert(items, "|cffffd100· " .. L(grp.label) .. " ·|r")
        table.insert(idxMap, 0)
        for _, id in ipairs(grp.ids) do
          local ti2 = SE_BY_K[id]
          if ti2 and not SE_TYPES[ti2].hidden then table.insert(items, L("CT_" .. string.upper(SE_TYPES[ti2].id))) table.insert(idxMap, ti2) end
        end
      end
      EVAL_DD_OPEN(row.typeBtn.btn, items, function(ti0)
        local ti = idxMap[ti0]
        if not ti or ti == 0 then return end
        local old, new = it.cd, seDefaultCond(ti)
        if old.op and new.op then new.op, new.n = old.op, old.n end -- 同族参数保留
        local oldTd = SE_TYPES[SE_BY_K[old.k] or 1]
        if old.s and new.s and oldTd and oldTd.kind == SE_TYPES[ti].kind then new.s = old.s end -- s 仅同族保留
        it.cd = new
        EVAL_HELP_SE_REFRESH()
      end)
    end)
    reg(row.typeBtn.btn)
    -- 数值参数：[比较符] [-] 值 [+]
    row.opBtn = seBtn(root, 142, y, 34, 15, ">", function()
      -- 比较符下拉（1.19.0：替代点按循环，可选项全可见）
      local it = seUI.ed and seUI.ed.conds[i]
      if not (it and it.cd.op) then return end
      EVAL_DD_OPEN(row.opBtn.btn, SE_OPS, function(oi)
        it.cd.op = SE_OPS[oi]
        EVAL_HELP_SE_REFRESH()
      end)
    end)
    reg(row.opBtn.btn)
    -- 1.58.0 时间类型（秒）：步进 0.1、区间 0.0-10.0
    local SE_TIME_K = { swingLeft = true, castEl = true, castLeft = true, tCastEl = true, tCastLeft = true }
    row.minus = seBtn(root, 180, y, 20, 15, "-", function()
      local it = seUI.ed and seUI.ed.conds[i]
      if it and it.cd.n then
        if it.cd.k == "combo" then it.cd.n = math.max(1, it.cd.n - 1) -- 1.54.3 连击点数域 1-5（GetComboPoints 上限 5）
        elseif SE_TIME_K[it.cd.k] then it.cd.n = math.max(0, math.floor((it.cd.n - 0.1) * 10 + 0.5) / 10) -- 时间型 0.1 步进
        else it.cd.n = math.max(0, it.cd.n - 5) end
        EVAL_HELP_SE_REFRESH()
      end
    end)
    reg(row.minus.btn)
    local vt = uiText(root, 9, 1, 0.9, 0.5)
    vt:SetPoint("TOPLEFT", root, "TOPLEFT", 204, y - 3)
    row.valText = vt
    reg(vt)
    row.plus = seBtn(root, 230, y, 20, 15, "+", function()
      local it = seUI.ed and seUI.ed.conds[i]
      if it and it.cd.n then
        if it.cd.k == "combo" then it.cd.n = math.min(5, it.cd.n + 1) -- 1.54.3 连击点数域 1-5
        elseif SE_TIME_K[it.cd.k] then it.cd.n = math.min(10, math.floor((it.cd.n + 0.1) * 10 + 0.5) / 10) -- 时间型 0.1 步进 上限 10.0
        else it.cd.n = math.min(300, it.cd.n + 5) end
        EVAL_HELP_SE_REFRESH()
      end
    end)
    reg(row.plus.btn)
    -- 布尔/标志/姿态：是/否循环
    row.valBtn = seBtn(root, 142, y, 44, 15, L("SE_YES"), function()
      local it = seUI.ed and seUI.ed.conds[i]
      if it then
        local cd = it.cd
        local ti = SE_BY_K[cd.k] or 1
        local kind = SE_TYPES[ti].kind
        if kind == "bool" then cd.v = not cd.v
        elseif kind == "flag" then cd.inv = not cd.inv
        elseif kind == "form" then cd.k = (cd.k == "form") and "formNot" or "form" end
        EVAL_HELP_SE_REFRESH()
      end
    end)
    reg(row.valBtn.btn)
    -- 姿态号下拉（1.19.0：替代 1/2/3 循环）
    -- 1.59.0 按角色实际姿态栏动态生成（GetNumShapeshiftForms + 名称；旧版硬编码 1/2/3，无姿态职业/德鲁伊对不上）
    row.formN = seBtn(root, 190, y, 30, 15, "1", function()
      local it = seUI.ed and seUI.ed.conds[i]
      if not (it and it.cd.n) then return end
      local items = {}
      if type(GetNumShapeshiftForms) == "function" then
        local okn, n = pcall(GetNumShapeshiftForms)
        if okn and n and n > 0 then
          for si = 1, n do
            local oki, _ic, nm = pcall(GetShapeshiftFormInfo, si)
            table.insert(items, tostring(si) .. ((oki and nm) and (" " .. nm) or ""))
          end
        end
      end
      if table.getn(items) == 0 then items = { "1" } end -- 无姿态栏职业兜底
      EVAL_DD_OPEN(row.formN.btn, items, function(ni)
        it.cd.n = ni -- onPick 传回序号=姿态栏索引
        EVAL_HELP_SE_REFRESH()
      end)
    end)
    reg(row.formN.btn)
    -- buff/debuff 技能名：显示 + [v] 下拉（1.19.0 移除 [<][>] 循环）
    local st2 = uiText(root, 9, 1, 0.9, 0.5)
    st2:SetPoint("TOPLEFT", root, "TOPLEFT", 142, y - 3)
    row.skillText = st2
    reg(st2)
    -- 1.35.2 布局优化：[v] 箭头按钮取消——文字本身就是触发区（透明热区覆盖，悬停高亮提示可点）
    local sHit = CreateFrame("Button", nil, root)
    sHit:SetWidth(120) sHit:SetHeight(15)
    sHit:SetPoint("TOPLEFT", root, "TOPLEFT", 140, y)
    pcall(sHit.EnableMouse, sHit, true)
    pcall(sHit.RegisterForClicks, sHit, "LeftButtonUp")
    sHit:SetScript("OnEnter", function() pcall(st2.SetTextColor, st2, 1, 1, 0.85) end)
    sHit:SetScript("OnLeave", function() pcall(st2.SetTextColor, st2, 1, 0.9, 0.5) end)
    row.sHit = sHit
    reg(sHit)
    -- [v] 下拉：buff/debuff 技能名全列表（1.35.2 起按钮本体常驻隐藏，仅作处理器宿主）
    row.sDrop = seBtn(root, 246, y, 16, 15, "v", function()
      local it = seUI.ed and seUI.ed.conds[i]
      if not it then return end
      local tdi = SE_TYPES[SE_BY_K[it.cd.k] or 1]
      if tdi and tdi.kind == "class" then
        -- 目标职业：多选下拉（或关系），点按切换 √ 不关面板（1.26.0）
        it.cd.cs = it.cd.cs or {}
        local items, sel = {}, {}
        for ci, c in ipairs(CLASS_LIST) do
          table.insert(items, c.name)
          if it.cd.cs[c.id] then sel[ci] = true end
        end
        EVAL_DD_OPEN(row.sHit, items, function(pi, on)
          it.cd.cs[CLASS_LIST[pi].id] = on or nil
          EVAL_HELP_SE_REFRESH()
        end, { multi = true, selected = sel })
        return
      end
      if tdi and tdi.kind == "target" then
        -- 指定名称的名称下拉（1.29.0）：最近 5 敌名（循环枚举法）+ 自定义输入弹窗
        local function openNameDrop()
          local items = {}
          for _, n in ipairs(EVAL_NEARBY_ENEMY_NAMES(5)) do table.insert(items, n) end
          table.insert(items, "✎ 自定义名称…")
          local customIdx = table.getn(items)
          EVAL_DD_OPEN(row.sHit, items, function(pi)
            if pi >= customIdx then
              EVAL_TN_OPEN("指定目标名称（盲打看金色回声行）", it.cd.nm or "", function(nm)
                it.cd.nm = nm
                EVAL_HELP_SE_REFRESH()
              end)
            else
              it.cd.nm = items[pi]
              EVAL_HELP_SE_REFRESH()
            end
          end)
        end
        if it.cd.s == "byName" then
          openNameDrop() -- 已是指定名称：本下拉=选名称（换种类重选条件类型即可）
        else
          -- 选取目标：下拉官方 Targetting 函数种类（1.25.0 七种 + 1.29.0 目标的目标/指定名称）
          local items = {}
          for _, t in ipairs(TARGET_SEL) do table.insert(items, t.name) end
          EVAL_DD_OPEN(row.sHit, items, function(pi)
            it.cd.s = TARGET_SEL[pi].id
            EVAL_HELP_SE_REFRESH()
            if it.cd.s == "byName" then openNameDrop() end -- 选完种类立即选名称
          end)
        end
        return
      end
      -- 1.32.9 重构：并行 names 表（显示前缀不入值，不做字符串解析）；排除伪技能（宠物/选取/物品——没有光环概念，1.32.9 修混入）；
      -- 实时项 ◆目标debuff/○自身buff（1.27.0）+ 已学习名 ◇（跨会话持久，buff 消失也能选——修「药水 buff 不及时显示」）；图标经 auraTexOf
      local items, names = {}, {}
      local function push(disp, nm) table.insert(items, disp) table.insert(names, nm) end
      for _, n in ipairs(EVAL_GO_SKILL_CHOICES()) do
        if not petCmdOf(n) and not targetSelOf(n) and not itemOf(n) and not stanceOf(n) and not cancelCastOf(n) then push(n, n) end
      end
      local k0 = it.cd.k
      local isAura = (k0 == "hasDebuff" or k0 == "noDebuff" or k0 == "hasBuff" or k0 == "noBuff" or k0 == "tBuff" or k0 == "pDebuff")
      if k0 == "hasDebuff" or k0 == "noDebuff" then
        for _, d in ipairs(EVAL_TARGET_DEBUFF_LIST()) do push("◆" .. d.name, d.name) end
      elseif k0 == "hasBuff" or k0 == "noBuff" then
        for _, d in ipairs(EVAL_PLAYER_BUFF_LIST()) do push("○" .. d.name, d.name) end
      elseif k0 == "tBuff" then -- 1.54.0 ●目标buff 实时项
        for _, d in ipairs(EVAL_TARGET_BUFF_LIST()) do push("●" .. d.name, d.name) end
      elseif k0 == "pDebuff" then -- 1.54.0 ▲自身debuff 实时项
        for _, d in ipairs(EVAL_PLAYER_DEBUFF_LIST()) do push("▲" .. d.name, d.name) end
      end
      if isAura then
        local seen = {}
        for _, n in ipairs(names) do seen[n] = true end
        local w2c = EVAL_HELP_CONFIG and EVAL_HELP_CONFIG.war
        local lt = w2c and w2c.debuffTex
        if lt then
          local ln = {}
          for n in pairs(lt) do table.insert(ln, n) end
          table.sort(ln)
          for _, n in ipairs(ln) do if not seen[n] then push("◇" .. n, n) end end
        end
      end
      local icons = {}
      local anyIcon = false
      for i2, nm in ipairs(names) do
        local t = auraTexOf(nm)
        if t then icons[i2] = t anyIcon = true end
      end
      EVAL_DD_OPEN(row.sHit, items, function(pi)
        it.cd.s = names[pi]
        EVAL_HELP_SE_REFRESH()
      end, { icons = anyIcon and icons or nil })
    end)
    row.sDrop.btn:Hide() -- 1.35.2 v 按钮常驻隐藏
    sHit:SetScript("OnClick", function() local c = row.sDrop.btn:GetScript("OnClick") if c then c() end end)
    reg(row.sDrop.btn)
    -- 免疫条件的 免疫/未免疫 切换（1.36.3：kind=skill 共用参数区，仅 immune 类型显示）
    -- 1.36.4 修：此块 1.36.3 误嵌进 sDrop 调用中间，导致只在点击时才赋值（刷新时 immBtn nil 报错）
    row.immBtn = seBtn(root, 250, y, 52, 15, "", function()
      local it = seUI.ed and seUI.ed.conds[i]
      if not it then return end
      it.cd.v = (it.cd.v == false) and true or false
      EVAL_HELP_SE_REFRESH()
    end)
    reg(row.immBtn.btn)
    row.stk = seBtn(root, 266, y, 20, 15, L("SE_STK"), function()
      local it = seUI.ed and seUI.ed.conds[i]
      if not it then return end
      local stkItems = { L("SE_STK_UNLIM") } for si = 2, 5 do table.insert(stkItems, L("SE_STK_FMT", si)) end
      EVAL_DD_OPEN(row.stk.btn, stkItems, function(pi)
        it.cd.n = (pi > 1) and pi or nil -- 序号2-5即层数2-5
        EVAL_HELP_SE_REFRESH()
      end)
    end)
    reg(row.stk.btn)
    -- 结果预览 + 删除
    local pv = uiText(root, 9, 0.55, 0.75, 0.55)
    pv:SetPoint("TOPLEFT", root, "TOPLEFT", 288, y - 3)
    row.preview = pv
    reg(pv)
    row.del = seBtn(root, 420, y, 28, 15, L("W_DEL"), function()
      local ed = seUI.ed
      if ed and ed.conds[i] then table.remove(ed.conds, i) EVAL_HELP_SE_REFRESH() end
    end)
    reg(row.del.btn)
    seUI.rows[i] = row
  end

  -- 添加条件 + 预览 + 保存/取消
  seBtn(root, 16, -64 - 8 * 20 - 6, 96, 16, L("SE_ADD"), function()
    local ed = seUI.ed
    if ed and table.getn(ed.conds) < 8 then
      table.insert(ed.conds, { conn = (table.getn(ed.conds) > 0) and "&" or nil, cd = seDefaultCond(1) })
      EVAL_HELP_SE_REFRESH()
    end
  end)
  -- 1.36.2 预览挪到 [+添加条件] 右侧同行（原在底部与 保存/取消 按钮重叠）
  local pvLabel = uiText(root, 9, 0.60, 0.55, 0.40)
  pvLabel:SetPoint("TOPLEFT", root, "TOPLEFT", 122, -64 - 8 * 20 - 9)
  pvLabel:SetText(L("SE_PREVIEW"))
  local pv = uiText(root, 9, 0.95, 0.82, 0.35)
  pv:SetPoint("TOPLEFT", root, "TOPLEFT", 158, -64 - 8 * 20 - 9)
  pcall(pv.SetWidth, pv, 300)
  pcall(pv.SetJustifyH, pv, "LEFT")
  seUI.preview = pv
  local function bBtn(x, w, label, fn)
    local b = CreateFrame("Button", nil, root)
    b:SetWidth(w) b:SetHeight(22)
    b:SetPoint("BOTTOMLEFT", root, "BOTTOMLEFT", x, 12)
    pcall(b.EnableMouse, b, true)
    pcall(b.RegisterForClicks, b, "LeftButtonUp")
    local bb = b:CreateTexture(nil, "BACKGROUND")
    uiSolid(bb, 0.22, 0.18, 0.10, 1)
    bb:SetPoint("TOPLEFT", b, "TOPLEFT", 0, 0)
    bb:SetPoint("BOTTOMRIGHT", b, "BOTTOMRIGHT", 0, 0)
    local bt = uiText(b, 10, 0.95, 0.82, 0.35)
    bt:SetPoint("CENTER", b, "CENTER", 0, 0)
    bt:SetText(label)
    b:SetScript("OnClick", fn)
  end
  bBtn(150, 80, L("SE_SAVE"), function() EVAL_HELP_SE_SAVE() end)
  bBtn(240, 80, L("BTN_CANCEL"), function() root:Hide() end)
  root:Hide()
  root:SetScript("OnHide", function() EVAL_DD_HIDE() end)
  seUI.root = root
end

function EVAL_HELP_SE_SAVE()
  local ed = seUI.ed
  if not ed then return end
  local w2 = warCfg()
  local p = w2.profiles[ed.profIdx]
  if not p then if seUI.root then seUI.root:Hide() end return end
  local groups = seLinearToGroups(ed.conds)
  if ed.skillIdx and p.skills[ed.skillIdx] then
    local r = p.skills[ed.skillIdx]
    r.skill = ed.skill
    r.enabled = ed.enabled
    r.groups = groups
    say("已保存技能: " .. tostring(ed.skill) .. " → " .. uiEsc(EVAL_GROUP_STR(groups)))
  else
    -- 1.33.0 取消 8 技能上限（配置窗列表支持滚动）
    table.insert(p.skills, { skill = ed.skill, enabled = ed.enabled, groups = groups, why = ed.skill })
    say("已添加技能: " .. tostring(ed.skill) .. " → " .. uiEsc(EVAL_GROUP_STR(groups)))
  end
  pcall(EVAL_WAR_TAB_REFRESH)
  if seUI.root then seUI.root:Hide() end
end

-- 打开编辑窗：skillIdx=nil 表示新增（presetSkill 预选技能）
function EVAL_HELP_SE_OPEN(profIdx, skillIdx, presetSkill)
  SE_BUILD()
  local w2 = warCfg()
  local p = w2.profiles[profIdx]
  if not p then return end
  local ed = { profIdx = profIdx, skillIdx = skillIdx }
  if skillIdx and p.skills[skillIdx] then
    local r = p.skills[skillIdx]
    ed.skill = r.skill
    ed.enabled = r.enabled ~= false
    ed.conds = seGroupsToLinear(r.groups)
  else
    ed.skill = presetSkill or "攻击" -- 1.48.0 白名单已删，兜底用「攻击」
    ed.enabled = true
    ed.conds = {}
  end
  seUI.ed = ed
  EVAL_HELP_SE_REFRESH()
  seUI.root:Show()
end

-- ============ 方案 导入/导出（md 文本互转，复制粘贴快速分享） ============
-- 存储/交换格式（与案例模版库 EVAL_IO_TEMPLATES 同格式；1.48.0 起 example/zs_wq.md 已删，模版在游戏内）：
--   # 方案: 武器战
--   - 压制 | 怒气>5 & 可用 & 就绪
--   - !猛击 | Alt & 怒气>20        （技能名前 ! = 该技能停用）
-- 解析容忍 markdown 杂物：# 开头 = 方案名，> 或 < 开头/超长行忽略，无 | 的行忽略。

local ioUI = { root = nil, eb = nil }
local tplUI = { root = nil } -- 1.44.0 案例模版选单

-- 案例模版库（1.44.0）：按职业分组，导入弹窗内 [案例模版] 打开选单直接导入。
-- text 与导入导出同 md 格式（EVAL_PROFILE_FROM_TEXT 解析）；原「武器战示例」按钮已并入此处。
EVAL_IO_TEMPLATES = {
  { cls = "战士", list = {
    { name = "武器战", desc = "姿态开怪/压制优先/怒吼保持/断筋撕裂/猛击Alt", text = "# 方案: 武器战\n\n" ..
      "- 姿态:战斗姿态 | 非战斗 & 非姿态1 & 可攻击\n" ..
      "- 压制 | 怒气>5 & 可用 & 就绪\n" ..
      "- 战斗怒吼 | 怒气>9 & 无buff:战斗怒吼\n" ..
      "- 断筋 | 目标血<30 & 怒气>9 & 无debuff:断筋\n" ..
      "- 撕裂 | 可流血 & 目标血>10 & 怒气>9 & 无debuff:撕裂\n" ..
      "- 血性狂暴 | 战斗中 & 无buff:血性狂暴 & 就绪\n" ..
      "- 猛击 | Alt & 怒气>20\n" ..
      "- 英勇打击 | 怒气>30 & 未排队" },
  }},
  -- 1.56.1 法师案例×2（用户实配收录）：法师一键输出 + 通用法系周围补buff
  { cls = "法师", list = {
    { name = "法师一键", desc = "选敌开怪/寒冰箭射程内/火球补刀/霜甲智慧保持", text = "# 方案: 法师一键\n\n" ..
      "- 选取目标:最近敌人 | 非战斗 & 无目标\n" ..
      "- 寒冰箭 | 范围内:寒冰箭 & 就绪 & 可攻击\n" ..
      "- 火球术 | 可攻击 & 就绪\n" ..
      "- 霜甲术 | 能量%>30 & 无buff:霜甲术\n" ..
      "- 奥术智慧 | 无buff:奥术智慧" },
    { name = "周围补buff", desc = "通用法系：切最近友方挨个补奥术智慧（切+补一键完成）", text = "# 方案: 周围补buff\n\n" ..
      "- 选取目标:最近友方 | 目标非战斗\n" ..
      "- 奥术智慧 | 无目标buff:奥术智慧" },
  }},
}

-- 文本导入共用入口（1.44.0 抽出）：导入按钮与案例模版同走；成功返回 true+提示
local function ioImportText(text)
  local prof, err = EVAL_PROFILE_FROM_TEXT(text)
  if not prof then return false, "导入失败: " .. tostring(err) end
  local w2 = warCfg()
  if table.getn(w2.profiles) < 12 then -- 1.44.0 修正：方案上限 1.42.0 已 4→12，此处残留旧值
    table.insert(w2.profiles, prof)
    w2.activeProfile = table.getn(w2.profiles)
    return true, "已导入为新方案: " .. tostring(prof.name) .. "（" .. table.getn(prof.skills) .. " 个技能）"
  end
  w2.profiles[w2.activeProfile or 1] = prof
  return true, "方案已满 12 个，已替换当前方案: " .. tostring(prof.name)
end

-- 方案 → md 文本（导出）
function EVAL_PROFILE_TO_TEXT(idx)
  local w2 = warCfg()
  local p = w2.profiles[idx or (w2.activeProfile or 1)]
  if not p then return "" end
  local lines = {}
  table.insert(lines, "# 方案: " .. tostring(p.name))
  table.insert(lines, "")
  for _, r in ipairs(p.skills or {}) do
    local dis = (r.enabled == false) and "!" or ""
    table.insert(lines, "- " .. dis .. tostring(r.skill) .. " | " .. EVAL_GROUP_STR(r.groups))
  end
  return table.concat(lines, "\n")
end

-- md 文本 → 方案表（导入）；失败返回 nil+原因
function EVAL_PROFILE_FROM_TEXT(text)
  if type(text) ~= "string" then return nil, "无文本" end
  text = string.gsub(text, "\r\n", "\n")
  text = string.gsub(text, "\r", "\n")
  local name, skills = nil, {}
  for line in string.gmatch(text .. "\n", "(.-)\n") do
    local l = EVAL_COND_TRIM(line)
    local nm = string.match(l, "^#%s*方案[:：]%s*(.+)$") or string.match(l, "^#%s*(.+)$")
    if nm then
      name = EVAL_COND_TRIM(nm)
    elseif string.sub(l, 1, 1) ~= ">" and string.sub(l, 1, 1) ~= "<" and l ~= "" then
      local body = string.match(l, "^[-*]%s*(.+)$") or l
      local sn, conds = string.match(body, "^([^|]+)|(.*)$")
      if sn then
        sn = condTrim(sn)
        local enabled = true
        if string.sub(sn, 1, 1) == "!" then enabled = false sn = condTrim(string.sub(sn, 2)) end
        -- 技能名合理性守卫：超长按说明文字处理。1.56.1 上限 24→48 字节（16 汉字）——
        -- 带前缀技能名更长：选取目标:指定名称:嗜血者=39B、物品:弱效巨魔之血药水=36B，旧 24B 上限会把它们静默丢行
        if sn ~= "" and string.len(sn) <= 48 then
          table.insert(skills, { skill = sn, enabled = enabled, groups = EVAL_PARSE_CONDS(conds or ""), why = sn })
        end
      end
    end
  end
  if table.getn(skills) == 0 then return nil, "没解析到技能行（格式: - 技能名 | 条件）" end
  return { name = name or "导入方案", skills = skills } -- 1.33.0 取消 8 技能上限
end

function EVAL_HELP_IO_BUILD()
  if ioUI.root then return end
  local W, H = 470, 350
  local root = CreateFrame("Frame", "EVAL_HELP_IO", UIParent)
  root:SetWidth(W) root:SetHeight(H)
  root:SetPoint("CENTER", UIParent, "CENTER", 0, 60)
  -- 同 1.11.2：抬到 DIALOG 同级 + 高 frameLevel，避免被配置窗（DIALOG）盖住
  pcall(root.SetFrameStrata, root, "DIALOG")
  pcall(root.SetFrameLevel, root, 90)
  pcall(root.SetMovable, root, true)
  pcall(root.EnableMouse, root, true)
  if uiOffscreen(root) then
    root:ClearAllPoints()
    root:SetPoint("CENTER", UIParent, "CENTER", 0, 40)
  end
  local bg = root:CreateTexture(nil, "BACKGROUND")
  uiSolid(bg, 0.06, 0.05, 0.04, 0.97)
  bg:SetPoint("TOPLEFT", root, "TOPLEFT", 0, 0)
  bg:SetPoint("BOTTOMRIGHT", root, "BOTTOMRIGHT", 0, 0)
  for _, e in ipairs({ "TOP", "BOTTOM" }) do
    local t = root:CreateTexture(nil, "BORDER")
    uiSolid(t, 0.85, 0.70, 0.20, 1)
    t:SetPoint(e .. "LEFT", root, e .. "LEFT", 0, 0)
    t:SetPoint(e .. "RIGHT", root, e .. "RIGHT", 0, 0)
    t:SetHeight(1)
  end
  for _, side in ipairs({ "LEFT", "RIGHT" }) do
    local t = root:CreateTexture(nil, "BORDER")
    uiSolid(t, 0.85, 0.70, 0.20, 1)
    t:SetPoint("TOP" .. side, root, "TOP" .. side, 0, 0)
    t:SetPoint("BOTTOM" .. side, root, "BOTTOM" .. side, 0, 0)
    t:SetWidth(1)
  end
  -- 标题栏拖动（Button 配方）
  local titleBar = CreateFrame("Button", nil, root)
  titleBar:SetPoint("TOPLEFT", root, "TOPLEFT", 1, -1)
  titleBar:SetPoint("TOPRIGHT", root, "TOPRIGHT", -1, -1)
  titleBar:SetHeight(16)
  local okLvl, rootLvl = pcall(root.GetFrameLevel, root)
  if okLvl and type(rootLvl) == "number" then pcall(titleBar.SetFrameLevel, titleBar, rootLvl + 10) end
  local tbBg = titleBar:CreateTexture(nil, "BACKGROUND")
  uiSolid(tbBg, 0.16, 0.13, 0.08, 1)
  tbBg:SetPoint("TOPLEFT", titleBar, "TOPLEFT", 0, 0)
  tbBg:SetPoint("BOTTOMRIGHT", titleBar, "BOTTOMRIGHT", 0, 0)
  pcall(titleBar.EnableMouse, titleBar, true)
  pcall(titleBar.RegisterForClicks, titleBar, "LeftButtonUp")
  pcall(titleBar.RegisterForDrag, titleBar, "LeftButton")
  local title = uiText(titleBar, 10, 0.95, 0.82, 0.35)
  title:SetPoint("CENTER", titleBar, "CENTER", 0, 0)
  title:SetText(L("IO_TITLE"))
  titleBar:SetScript("OnDragStart", function()
    pcall(root.SetMovable, root, true)
    pcall(root.StartMoving, root)
    pcall(root.StopMovingOrSizing, root)
    pcall(root.StartMoving, root)
  end)
  titleBar:SetScript("OnDragStop", function() pcall(root.StopMovingOrSizing, root) end)

  -- 操作说明
  local tip = uiText(root, 9, 0.75, 0.75, 0.75)
  tip:SetPoint("TOPLEFT", root, "TOPLEFT", 14, -26)
  tip:SetText(L("IO_TIP"))

  -- 多行输入框（1.15.1：字体对象优先；本客户端 EditBox 可能不渲染，下方有保底预览区）
  local okEb, eb = pcall(CreateFrame, "EditBox", "EVAL_HELP_IO_EB", root)
  if okEb and eb then
    pcall(eb.SetMultiLine, eb, true)
    pcall(eb.SetAutoFocus, eb, false)
    pcall(eb.EnableMouse, eb, true)
    -- 1.32.8 编辑区尺寸修正：EditBox 装进 ScrollFrame 精确裁剪到可视框（ebBg 内缩），
    -- 不再溢出盖住说明行/预览区；超高文本自动滚到底部。ScrollFrame 不可用时回退旧直挂布局。
    local okSF, sf = pcall(CreateFrame, "ScrollFrame", "EVAL_HELP_IO_SF", root)
    if okSF and sf and pcall(sf.SetScrollChild, sf, eb) then
      sf:SetPoint("TOPLEFT", root, "TOPLEFT", 16, -40)
      sf:SetWidth(W - 32) sf:SetHeight(136)
      eb:SetPoint("TOPLEFT", sf, "TOPLEFT", 4, -2)
      eb:SetWidth(W - 48) eb:SetHeight(132)
      eb:SetScript("OnTextChanged", function()
        pcall(sf.UpdateScrollChildRect, sf)
        local okr, range = pcall(sf.GetVerticalScrollRange, sf)
        if okr and type(range) == "number" then pcall(sf.SetVerticalScroll, sf, range) end
      end)
      ioUI.sf = sf
    else
      eb:SetWidth(W - 40) eb:SetHeight(128)
      eb:SetPoint("TOPLEFT", root, "TOPLEFT", 20, -44)
    end
    local setF = false
    for _, fo in ipairs({ "GameFontHighlightSmall", "ChatFontNormal", "GameFontNormal" }) do
      if pcall(eb.SetFontObject, eb, fo) then setF = true break end
    end
    if not setF then
      for _, fp in ipairs({ "Fonts\\FZLBJW.TTF", "Fonts\\FRIZQT__.TTF", "Fonts\\ARIALN.TTF" }) do
        local okF, ok2 = pcall(eb.SetFont, eb, fp, 10, "")
        if okF and ok2 then setF = true break end
      end
    end
    if not setF then pcall(eb.SetTextHeight, eb, 10) end
    pcall(eb.SetTextColor, eb, 1, 1, 1)
    local ebBg = root:CreateTexture(nil, "BACKGROUND")
    uiSolid(ebBg, 0.10, 0.09, 0.06, 1)
    ebBg:SetPoint("TOPLEFT", root, "TOPLEFT", 14, -38)
    ebBg:SetWidth(W - 28) ebBg:SetHeight(140)
    local ebEdge = root:CreateTexture(nil, "BORDER")
    uiSolid(ebEdge, 0.85, 0.70, 0.20, 0.8)
    ebEdge:SetPoint("TOPLEFT", root, "TOPLEFT", 14, -38)
    ebEdge:SetWidth(W - 28) ebEdge:SetHeight(1)
    eb:SetScript("OnEscapePressed", function() pcall(eb.ClearFocus, eb) end)
    ioUI.eb = eb
  else
    local noEb = uiText(root, 9, 0.7, 0.5, 0.5)
    noEb:SetPoint("TOPLEFT", root, "TOPLEFT", 14, -44)
    noEb:SetText(L("IO_NOEB"))
  end

  -- 保底预览区：当前方案文本以 FontString 渲染（EditBox 不显示时也始终可见）
  local pvLabel = uiText(root, 9, 0.95, 0.82, 0.35)
  pvLabel:SetPoint("TOPLEFT", root, "TOPLEFT", 14, -184)
  pvLabel:SetText(L("IO_PV"))
  ioUI.pvLines = {}
  for i = 1, 8 do
    local ln = uiText(root, 9, 0.82, 0.82, 0.82)
    ln:SetPoint("TOPLEFT", root, "TOPLEFT", 20, -196 - (i - 1) * 12)
    pcall(ln.SetWidth, ln, W - 40)
    pcall(ln.SetJustifyH, ln, "LEFT")
    ioUI.pvLines[i] = ln
  end

  -- 配置文件位置提示（1.20.2：EditBox 不可复制时的兜底——方案自动存盘，小退后文件即最新）
  local pathTip = uiText(root, 8, 0.55, 0.55, 0.55)
  pathTip:SetPoint("TOPLEFT", root, "TOPLEFT", 14, -288)
  pcall(pathTip.SetWidth, pathTip, W - 28)
  pcall(pathTip.SetJustifyH, pathTip, "LEFT")
  pathTip:SetText(L("IO_PATH1"))
  local pathTip2 = uiText(root, 8, 0.68, 0.62, 0.30)
  pathTip2:SetPoint("TOPLEFT", root, "TOPLEFT", 14, -300)
  pcall(pathTip2.SetWidth, pathTip2, W - 28)
  pcall(pathTip2.SetJustifyH, pathTip2, "LEFT")
  pathTip2:SetText("%LOCALAPPDATA%\\Azeroth\\Saved\\Account\\<你的账号>\\SavedVariables\\EVAL_HELP.lua")

  -- 底部按钮行
  local function ioBtn(x, w, label, fn)
    local b = CreateFrame("Button", nil, root)
    b:SetWidth(w) b:SetHeight(24)
    b:SetPoint("BOTTOMLEFT", root, "BOTTOMLEFT", x, 14)
    pcall(b.EnableMouse, b, true)
    pcall(b.RegisterForClicks, b, "LeftButtonUp")
    local bb = b:CreateTexture(nil, "BACKGROUND")
    uiSolid(bb, 0.22, 0.18, 0.10, 1)
    bb:SetPoint("TOPLEFT", b, "TOPLEFT", 0, 0)
    bb:SetPoint("BOTTOMRIGHT", b, "BOTTOMRIGHT", 0, 0)
    local bt = uiText(b, 10, 0.95, 0.82, 0.35)
    bt:SetPoint("CENTER", b, "CENTER", 0, 0)
    bt:SetText(label)
    b:SetScript("OnClick", fn)
    return b
  end
  ioBtn(14, 108, L("IO_IMPORT"), function()
    local text = ""
    if ioUI.eb then
      local ok, t = pcall(ioUI.eb.GetText, ioUI.eb)
      if ok and type(t) == "string" then text = t end
    end
    local ok, msg = ioImportText(text) -- 1.44.0 共用导入（含方案上限 12 修正）
    say(msg)
    if ok then pcall(EVAL_WAR_TAB_REFRESH) ioUI.root:Hide() end
  end)
  ioBtn(128, 108, L("IO_EXPORT"), function()
    if ioUI.eb then
      pcall(ioUI.eb.SetText, ioUI.eb, EVAL_PROFILE_TO_TEXT())
      pcall(ioUI.eb.SetFocus, ioUI.eb)
      pcall(ioUI.eb.HighlightText, ioUI.eb)
    end
    EVAL_HELP_IO_REFRESH()
    say("已导出到输入框并全选：Ctrl+C 复制，存成 .md 即可分享（输入框不显示就看下方预览区）")
  end)
  ioBtn(242, 108, L("IO_TPL"), function() EVAL_HELP_TPL_TOGGLE() end) -- 1.44.0 案例模版（按职业）
  ioBtn(392, 64, L("CLOSE"), function() ioUI.root:Hide() end)

  -- 1.44.0 IO 窗关闭时模版选单联动关闭
  root:SetScript("OnHide", function() if tplUI.root then tplUI.root:Hide() end end)
  root:Hide()
  ioUI.root = root
end

-- ============ 案例模版选单（1.44.0）：按职业分组，点击方案行直接导入 ============
function EVAL_HELP_TPL_BUILD()
  if tplUI.root then return end
  local W = 330
  local rows = 0
  for _, c in ipairs(EVAL_IO_TEMPLATES) do rows = rows + 1 + table.getn(c.list) end
  local H = 34 + rows * 20 + 34
  local root = CreateFrame("Frame", "EVAL_HELP_TPL", UIParent)
  root:SetWidth(W) root:SetHeight(H)
  root:SetPoint("CENTER", UIParent, "CENTER", 0, 80)
  pcall(root.SetFrameStrata, root, "DIALOG")
  pcall(root.SetFrameLevel, root, 95) -- 高于 IO 窗（90）
  pcall(root.SetMovable, root, true)
  pcall(root.EnableMouse, root, true)
  if uiOffscreen(root) then
    root:ClearAllPoints()
    root:SetPoint("CENTER", UIParent, "CENTER", 0, 40)
  end
  local bg = root:CreateTexture(nil, "BACKGROUND")
  uiSolid(bg, 0.06, 0.05, 0.04, 0.97)
  bg:SetPoint("TOPLEFT", root, "TOPLEFT", 0, 0)
  bg:SetPoint("BOTTOMRIGHT", root, "BOTTOMRIGHT", 0, 0)
  for _, e in ipairs({ "TOP", "BOTTOM" }) do
    local t = root:CreateTexture(nil, "BORDER")
    uiSolid(t, 0.85, 0.70, 0.20, 1)
    t:SetPoint(e .. "LEFT", root, e .. "LEFT", 0, 0)
    t:SetPoint(e .. "RIGHT", root, e .. "RIGHT", 0, 0)
    t:SetHeight(1)
  end
  for _, side in ipairs({ "LEFT", "RIGHT" }) do
    local t = root:CreateTexture(nil, "BORDER")
    uiSolid(t, 0.85, 0.70, 0.20, 1)
    t:SetPoint("TOP" .. side, root, "TOP" .. side, 0, 0)
    t:SetPoint("BOTTOM" .. side, root, "BOTTOM" .. side, 0, 0)
    t:SetWidth(1)
  end
  -- 标题栏拖动（Button 配方）
  local titleBar = CreateFrame("Button", nil, root)
  titleBar:SetPoint("TOPLEFT", root, "TOPLEFT", 1, -1)
  titleBar:SetPoint("TOPRIGHT", root, "TOPRIGHT", -1, -1)
  titleBar:SetHeight(16)
  local okLvl, rootLvl = pcall(root.GetFrameLevel, root)
  if okLvl and type(rootLvl) == "number" then pcall(titleBar.SetFrameLevel, titleBar, rootLvl + 10) end
  local tbBg = titleBar:CreateTexture(nil, "BACKGROUND")
  uiSolid(tbBg, 0.16, 0.13, 0.08, 1)
  tbBg:SetPoint("TOPLEFT", titleBar, "TOPLEFT", 0, 0)
  tbBg:SetPoint("BOTTOMRIGHT", titleBar, "BOTTOMRIGHT", 0, 0)
  pcall(titleBar.EnableMouse, titleBar, true)
  pcall(titleBar.RegisterForClicks, titleBar, "LeftButtonUp")
  pcall(titleBar.RegisterForDrag, titleBar, "LeftButton")
  local title = uiText(titleBar, 10, 0.95, 0.82, 0.35)
  title:SetPoint("CENTER", titleBar, "CENTER", 0, 0)
  title:SetText(L("TPL_TITLE"))
  titleBar:SetScript("OnDragStart", function()
    pcall(root.SetMovable, root, true)
    pcall(root.StartMoving, root)
    pcall(root.StopMovingOrSizing, root)
    pcall(root.StartMoving, root)
  end)
  titleBar:SetScript("OnDragStop", function() pcall(root.StopMovingOrSizing, root) end)

  -- 职业组标题（金色不可点）+ 方案行（点击即导入）
  local y = -26
  for _, c in ipairs(EVAL_IO_TEMPLATES) do
    local hd = uiText(root, 10, 0.95, 0.82, 0.35)
    hd:SetPoint("TOPLEFT", root, "TOPLEFT", 14, y)
    hd:SetText("【" .. tostring(c.cls) .. "】")
    y = y - 20
    for _, p in ipairs(c.list) do
      local b = CreateFrame("Button", nil, root)
      b:SetPoint("TOPLEFT", root, "TOPLEFT", 22, y)
      b:SetWidth(W - 36) b:SetHeight(18)
      pcall(b.EnableMouse, b, true)
      pcall(b.RegisterForClicks, b, "LeftButtonUp")
      local bb = b:CreateTexture(nil, "BACKGROUND")
      uiSolid(bb, 0.12, 0.10, 0.06, 1)
      bb:SetPoint("TOPLEFT", b, "TOPLEFT", 0, 0)
      bb:SetPoint("BOTTOMRIGHT", b, "BOTTOMRIGHT", 0, 0)
      local bt = uiText(b, 9, 0.88, 0.88, 0.88)
      bt:SetPoint("LEFT", b, "LEFT", 6, 0)
      bt:SetText(tostring(p.name) .. "  |cff777777" .. tostring(p.desc or "") .. "|r")
      b:SetScript("OnEnter", function() pcall(bb.SetVertexColor, bb, 0.30, 0.25, 0.12, 1) end)
      b:SetScript("OnLeave", function() pcall(bb.SetVertexColor, bb, 0.12, 0.10, 0.06, 1) end)
      b:SetScript("OnClick", function()
        local ok, msg = ioImportText(p.text)
        say(msg)
        if ok then
          pcall(EVAL_WAR_TAB_REFRESH)
          EVAL_HELP_IO_REFRESH()
          root:Hide()
        end
      end)
      y = y - 20
    end
  end

  local cb = CreateFrame("Button", nil, root)
  cb:SetWidth(64) cb:SetHeight(20)
  cb:SetPoint("BOTTOM", root, "BOTTOM", 0, 7)
  pcall(cb.EnableMouse, cb, true)
  pcall(cb.RegisterForClicks, cb, "LeftButtonUp")
  local cbb = cb:CreateTexture(nil, "BACKGROUND")
  uiSolid(cbb, 0.22, 0.18, 0.10, 1)
  cbb:SetPoint("TOPLEFT", cb, "TOPLEFT", 0, 0)
  cbb:SetPoint("BOTTOMRIGHT", cb, "BOTTOMRIGHT", 0, 0)
  local cbt = uiText(cb, 10, 0.95, 0.82, 0.35)
  cbt:SetPoint("CENTER", cb, "CENTER", 0, 0)
  cbt:SetText(L("CLOSE"))
  cb:SetScript("OnClick", function() root:Hide() end)

  root:Hide()
  tplUI.root = root
end

function EVAL_HELP_TPL_TOGGLE()
  if tplUI.root and tplUI.root:IsVisible() then tplUI.root:Hide() return end
  EVAL_HELP_TPL_BUILD()
  if tplUI.root then tplUI.root:Show() end
end

-- 预览区刷新：当前方案文本逐行填进保底 FontString（跳过空行；EditBox 不渲染时靠它看内容）
function EVAL_HELP_IO_REFRESH()
  if not ioUI.pvLines then return end
  local lines = {}
  for line in string.gmatch(EVAL_PROFILE_TO_TEXT() .. "\n", "(.-)\n") do
    if line ~= "" then table.insert(lines, line) end
  end
  for i, ln in ipairs(ioUI.pvLines) do
    ln:SetText(uiEsc(lines[i] or "")) -- 1.61.1 | 显示转义（编辑框原文不受影响）
  end
end

function EVAL_HELP_IO_TOGGLE()
  if ioUI.root and ioUI.root:IsVisible() then ioUI.root:Hide() return end
  EVAL_HELP_IO_BUILD()
  -- 每次打开默认填入当前方案的导出文本（看一眼格式 / 直接改）
  if ioUI.eb then pcall(ioUI.eb.SetText, ioUI.eb, EVAL_PROFILE_TO_TEXT()) end
  EVAL_HELP_IO_REFRESH()
  if ioUI.root then ioUI.root:Show() end
end

-- ============ 斜杠命令 /eh ============

if type(SlashCmdList) == "table" then
  SLASH_EVALHELP1 = "/eh"
  SLASH_EVALHELP2 = "/evalhelp"
  SlashCmdList["EVALHELP"] = function(msg)
    msg = string.lower(tostring(msg or ""))
    msg = string.gsub(msg, "^war", "go") -- /eh war 旧命令组兼容 → 通用 /eh go（1.21.1 改名）
    if msg == "log" then
      cfg.log = not cfg.log
      say("写日志文件: " .. (cfg.log and "|cff00ff00开|r" or "|cffff0000关|r"))
    elseif msg == "auto" then
      cfg.auto = not cfg.auto
      say("进出战斗自动输出: " .. (cfg.auto and "|cff00ff00开|r" or "|cffff0000关|r"))
    elseif msg == "ui" then
      EVAL_HELP_UI_TOGGLE()
    elseif msg == "cfg" or msg == "config" or msg == "set" then
      EVAL_HELP_CFG_TOGGLE()
    elseif msg == "st" or msg == "state" or msg == "info" then
      EVAL_HELP_ST_TOGGLE()
    elseif string.find(msg, "^go add ") then
      -- 兜底添加: /eh go add 技能名 条件串（如 /eh go add 压制 可用 & 就绪）
      local sn, conds = string.match(string.sub(msg, 8), "^(%S+)%s*(.*)$")
      if sn then
        local w2 = warCfg()
        local p = w2.profiles[w2.activeProfile or 1]
        if p then -- 1.33.4 取消 8 上限残留（1.33.0 漏改的 /eh go add 路径）
          table.insert(p.skills, { skill = sn, enabled = true, groups = EVAL_PARSE_CONDS(conds), why = sn })
          say("已添加: " .. sn .. " → " .. ((conds ~= "") and conds or "无条件"))
          pcall(EVAL_WAR_TAB_REFRESH)
        end
      end
    elseif string.find(msg, "^go del ") then
      local n = tonumber(string.sub(msg, 8))
      local w2 = warCfg()
      local p = w2.profiles[w2.activeProfile or 1]
      if p and n and p.skills[n] then
        say("已删除: " .. tostring(p.skills[n].skill))
        table.remove(p.skills, n)
        pcall(EVAL_WAR_TAB_REFRESH)
      end
    elseif string.find(msg, "^go newprof") then
      local nm = string.match(msg, "^go newprof%s*(.*)$")
      local w2 = warCfg()
      if table.getn(w2.profiles) < 4 then
        table.insert(w2.profiles, { name = (nm and nm ~= "") and nm or ("方案" .. tostring(table.getn(w2.profiles) + 1)), skills = {} })
        w2.activeProfile = table.getn(w2.profiles)
        say("新建并切换到: " .. tostring(w2.profiles[w2.activeProfile].name))
        pcall(EVAL_WAR_TAB_REFRESH)
      else
        say("最多 4 个方案")
      end
    elseif string.find(msg, "^go prof ") then
      local n = tonumber(string.sub(msg, 9))
      local w2 = warCfg()
      if n and w2.profiles[n] then
        w2.activeProfile = n
        say("切换到方案: " .. tostring(w2.profiles[n].name))
        pcall(EVAL_WAR_TAB_REFRESH)
      end
    elseif string.find(msg, "^go delprof") then
      local n = tonumber(string.match(msg, "^go delprof%s*(%d*)$"))
      local w2 = warCfg()
      EVAL_WAR_DEL_PROFILE(n or (w2.activeProfile or 1))
    elseif string.find(msg, "^go rename ") or string.find(msg, "^go name ") then
      local nm = string.match(msg, "^go %S+%s+(.+)$")
      local w2 = warCfg()
      local p = w2.profiles[w2.activeProfile or 1]
      if p and nm and nm ~= "" then
        p.name = nm
        say("方案已改名: " .. nm)
        pcall(EVAL_WAR_TAB_REFRESH)
      end
    elseif msg == "go next" then
      local w2 = warCfg()
      if table.getn(w2.profiles) > 1 then
        w2.activeProfile = (w2.activeProfile or 1) % table.getn(w2.profiles) + 1
        say("切换到方案: " .. tostring(w2.profiles[w2.activeProfile].name))
        pcall(EVAL_WAR_TAB_REFRESH)
      else
        say("只有一个方案（配置窗口 一键宏设置页 [+] 新建）")
      end
    elseif msg == "go io" or msg == "go export" or msg == "go import" then
      EVAL_HELP_IO_TOGGLE()
    elseif msg == "go list" then
      local w2 = warCfg()
      local p = w2.profiles[w2.activeProfile or 1]
      say("— 方案[" .. tostring(p and p.name) .. "] —")
      if p then
        for i, r in ipairs(p.skills) do
          say(string.format("%d. %s %s | %s", i, tostring(r.skill),
            (r.enabled ~= false) and "|cff00ff00开|r" or "|cffff0000关|r", uiEsc(EVAL_GROUP_STR(r.groups))))
        end
      end
    elseif msg == "go" then
      EVAL_GO_STATUS()
    elseif msg == "go rescan" then
      EVAL_GO_RESCAN(false)
    elseif msg == "go trace" then
      -- 执行追踪（1.54.2）：最近 12 次 EVAL_GO 调用时间戳+去抖标记——偶发「按一下执行两次」定位用
      local tr = EVAL_GO_TRACE
      if not tr or table.getn(tr) == 0 then
        say("执行追踪：暂无记录（先按几次宏再查）")
      else
        say("— EVAL_GO 执行追踪（新→旧，间隔=与前一次相差毫秒）—")
        for i, e in ipairs(tr) do
          local gap = (i > 1) and math.floor((tr[i - 1].t - e.t) * 1000 + 0.5) or 0
          say(string.format("%2d. t=%.3f  +%dms  %s", i, e.t, gap,
            e.skip and "|cffff5040×去抖丢弃|r" or "|cff00ff00√执行|r"))
        end
      end
    elseif msg == "go probe immune" then
      -- 免疫事件探针（1.35.1，免疫学习器前置验证）：30 秒全事件抓取——CHAT_MSG_* 或参数含「免疫/immune」
      -- 的写 UELog；对免疫怪放技能后翻日志拿真实事件名+文本格式，再写解析器（事件 wiki 无文档页）
      say("免疫探针启动：30 秒内对免疫怪放技能（如撕裂）→ /eh go probe dump 看结果")
      local pf = CreateFrame("Frame")
      local t0 = GetTime()
      -- 1.35.5：0 条说明全事件抓取可能没收到——加全事件计数（判定 RegisterAllEvents 是否有效）
      -- + 显式注册候选事件名对照（计数键带 [R] 前缀区分通道）
      cfg.probeLog = {}
      cfg.probeEvents = {}
      local CAND = { "CHAT_MSG_SPELL_SELF_DAMAGE", "CHAT_MSG_SPELL_FAILED_LOCALPLAYER", "CHAT_MSG_COMBAT_SELF_MISSES", "CHAT_MSG_SPELL_SELF_BUFF" }
      pf:SetScript("OnEvent", function()
        local a1, a2 = arg1, arg2
        local ev = (type(event) == "string") and event or nil
        local name = ev or (type(a1) == "string" and a1) or ""
        if name ~= "" then
          local pe = cfg.probeEvents
          pe[name] = (pe[name] or 0) + 1
          local sk = name .. "_s"
          if not pe[sk] then pe[sk] = tostring(a1) .. " | " .. tostring(a2) end
        end
        local hit = (string.find(name, "^CHAT_MSG") ~= nil)
        if not hit then
          for _, v in ipairs({ a1, a2 }) do
            if type(v) == "string" and (string.find(v, "免疫") or string.find(v, "immune")) then hit = true break end
          end
        end
        if hit then
          table.insert(cfg.probeLog, "PROBE " .. tostring(name) .. " | a1=" .. tostring(a1) .. " | a2=" .. tostring(a2))
          while table.getn(cfg.probeLog) > 120 do table.remove(cfg.probeLog, 1) end
        end
      end)
      local okAll = pcall(pf.RegisterAllEvents, pf)
      for _, en in ipairs(CAND) do pcall(pf.RegisterEvent, pf, "[R]" .. en) end -- 显式注册走同一帧（事件名前缀[R]区分）
      say("RegisterAllEvents pcall=" .. tostring(okAll) .. "；显式候选 " .. table.getn(CAND) .. " 个")
      pf:SetScript("OnUpdate", function()
        if GetTime() - t0 > 30 then
          pcall(pf.UnregisterAllEvents, pf)
          pf:SetScript("OnUpdate", nil)
          pf:SetScript("OnEvent", nil)
          say("免疫探针结束（30s），已记录 " .. table.getn(cfg.probeLog or {}) .. " 条 → /eh go probe dump 查看")
        end
      end)
    elseif string.sub(msg, 1, 15) == "go probe usable" then
      -- 可用性探针（1.60.1）：dump 技能格子的原始可用性值——IsUsableAction 在本客户端走缓存态
      -- （wiki 原文 Uses a cached usable state），疑似「可用却被跳过」时先跑这个拿现场数据。
      -- 用法：/eh go probe usable 冲锋（或 不带参数 = 当前方案全部动作条技能）
      local nm = string.match(msg, "^go probe usable%s*(.-)%s*$")
      local function dumpOne(n)
        local s = wslots[n]
        if not s then say(n .. ": |cffff0000不在动作条（先 /eh go rescan）|r") return end
        local oku, u, noMana = pcall(IsUsableAction, s.slot)
        local okr, inRg = pcall(IsActionInRange, s.slot)
        local okc, cst, dur = pcall(GetActionCooldown, s.slot)
        local okh, has = pcall(HasAction, s.slot)
        say(string.format("%s 格子%d: usable=%s(%s) noMana=%s inRange=%s cd=%s/%s HasAction=%s",
          n, s.slot,
          tostring(oku and u), tostring(oku), tostring(noMana),
          tostring(okr and inRg), tostring(cst), tostring(dur), tostring(okh and has)))
      end
      say("— 可用性探针 —")
      if nm and nm ~= "" then
        dumpOne(nm)
      else
        local p = warCfg().profiles[warCfg().activeProfile or 1]
        local any = false
        if p then for _, r in ipairs(p.skills) do if wslots[r.skill] then dumpOne(r.skill) any = true end end end
        if not any then say("（当前方案无动作条技能；可带参数：/eh go probe usable 冲锋）") end
      end
    elseif msg == "go probe dump" then
      -- 打印探针持久记录（1.35.4：UELog 不落盘的替代查看通道；打完免疫技能后用这个看）
      local pl = cfg.probeLog or {}
      say("— 探针记录 " .. table.getn(pl) .. " 条 —")
      for i, line in ipairs(pl) do say(i .. ". " .. line) end
      -- 1.35.5 全事件计数总览（判断事件系统是否工作）：按次数降序打前 25 个 + 首样本
      local pe = cfg.probeEvents or {}
      local names = {}
      for n, c2 in pairs(pe) do if type(c2) == "number" then table.insert(names, n) end end
      table.sort(names, function(a, b) return pe[a] > pe[b] end)
      say("— 事件计数（共 " .. table.getn(names) .. " 种）—")
      for i = 1, math.min(25, table.getn(names)) do
        local n = names[i]
        say(n .. " × " .. pe[n] .. "  样本: " .. tostring(pe[n .. "_s"]))
      end
      if table.getn(pl) == 0 and table.getn(names) == 0 then say("（全空——先 /eh go probe immune 并在 30 秒内对免疫怪放技能；若反复全空说明事件系统不可用）") end
    elseif msg == "go immune" then
      local im = (EVAL_HELP_CONFIG and EVAL_HELP_CONFIG.war and EVAL_HELP_CONFIG.war.immune) or {}
      local n, keys = 0, {}
      for k in pairs(im) do n = n + 1 table.insert(keys, k) end
      table.sort(keys)
      say("免疫学习记录 " .. n .. " 条（/eh go immune clear 清空）:")
      for _, k in ipairs(keys) do say("  " .. k) end
    elseif msg == "go immune clear" then
      if EVAL_HELP_CONFIG and EVAL_HELP_CONFIG.war then EVAL_HELP_CONFIG.war.immune = {} end
      say("免疫学习记录已清空")
    elseif msg == "go probe" then
      -- buff 探针（1.33.1）：两条枚举+tooltip 读名路径原始值打印，诊断药品类 buff 不进下拉
      say("— buff 探针（结果同时写日志文件） —")
      local function pr(s) say(s) logLine(s) end
      pr("GetPlayerBuff=" .. tostring(type(GetPlayerBuff)) .. " UnitBuff=" .. tostring(type(UnitBuff)) .. " SetPlayerBuff=" .. tostring(type(GameTooltip.SetPlayerBuff)) .. " SetUnitBuff=" .. tostring(type(GameTooltip.SetUnitBuff)))
      pr("BuffButton0=" .. tostring(getglobal("BuffButton0") ~= nil) .. " BuffFrame=" .. tostring(getglobal("BuffFrame") ~= nil))
      for i = 0, 3 do
        local okb, bi = pcall(GetPlayerBuff, i, "HELPFUL")
        pr(string.format("GPB(%d) ok=%s bi=%s(%s)", i, tostring(okb), tostring(bi), type(bi)))
        if okb and type(bi) == "number" and bi >= 0 then
          local okt, tex = pcall(GetPlayerBuffTexture, bi)
          pcall(function() GameTooltip:SetOwner(UIParent, "ANCHOR_NONE") end)
          pcall(function() GameTooltip:ClearLines() end)
          local oks, built = pcall(GameTooltip.SetPlayerBuff, GameTooltip, bi)
          local nm = GameTooltipTextLeft1 and GameTooltipTextLeft1.GetText and GameTooltipTextLeft1:GetText()
          pr("  tex=" .. tostring(okt and tex) .. " | SetPlayerBuff ok=" .. tostring(oks) .. " built=" .. tostring(built) .. " name=" .. tostring(nm))
          pcall(function() GameTooltip:Hide() end)
        end
      end
      for i = 1, 4 do
        local oku, tex, apps = pcall(UnitBuff, "player", i)
        pr(string.format("UnitBuff(%d) ok=%s tex=%s apps=%s", i, tostring(oku), tostring(tex), tostring(apps)))
        if oku and tex then
          pcall(function() GameTooltip:SetOwner(UIParent, "ANCHOR_NONE") end)
          pcall(function() GameTooltip:ClearLines() end)
          local oks, built = pcall(GameTooltip.SetUnitBuff, GameTooltip, "player", i)
          local nm = GameTooltipTextLeft1 and GameTooltipTextLeft1.GetText and GameTooltipTextLeft1:GetText()
          pr("  SetUnitBuff ok=" .. tostring(oks) .. " built=" .. tostring(built) .. " name=" .. tostring(nm))
          pcall(function() GameTooltip:Hide() end)
        end
      end
    elseif msg == "wdebug" or msg == "debug" then
      cfg.wdebug = not cfg.wdebug
      say("调试日志: " .. (cfg.wdebug and "|cff00ff00开|r" or "|cffff0000关|r"))
    elseif msg == "help" then
      say("—— EVAL_HELP 全职业施法工具（通用一键宏） ——")
      say("|cffffff00快速上手:|r ① 技能拖上动作条 ② /eh go rescan ③ 新建宏正文 /run EVAL_GO() 拖上按键连按")
      say("|cffffff00命令:|r /eh 输出状态 | /eh log 写日志开关 | /eh auto 进出战斗自动输出")
      say("/eh ui 战斗信息UI | /eh st 状态信息UI | /eh cfg 设置窗口（小地图旁 EH 图标同效）")
      say("/eh go 一键宏状态 | /eh go rescan 重扫动作条 | /eh debug 调试日志（/eh war 旧命令仍兼容）")
      say("方案命令：/eh go list 查看 | go add 技能 条件 | go del N | go newprof 名 | go prof N | go rename 新名 | go delprof N")
      say("方案导入导出（md 文本复制粘贴）：/eh go io，内置案例模版按职业直接导入")
      say("方案切换：Shift+按一键宏 | /eh go next | 战斗信息UI 方案按钮")
      say("|cffffff00执行指定方案:|r 新建宏正文 /run EVAL_GO(参数) —— 不传或0=当前激活方案；方案号1~4 或 \"方案名\" = 只跑该方案（不切激活）")
      say("　例：/run EVAL_GO(2) 跑2号方案 | /run EVAL_GO(\"测试\") 跑名为测试的方案 | /run EVAL_GO1()~GO4() 同效快捷写法；不同方案各绑一个按键即可多套输出")
      say("|cffffff00提示:|r 猛击需按住 Alt 按宏键；宏入口 /run EVAL_HELP() 输出状态日志")
      say("|cffffff00异常自救:|r 技能不识别/界面异常/刚更新过插件 → 先 /reload 重载（配置已存盘不会丢）；重扫动作条 /eh go rescan")
      say("|cffffff00问题反馈:|r https://gitee.com/xeval/emberveil_eval_help.git —— 插件持续优化中，欢迎测试并留下宝贵意见")
      say("日志文件: %LOCALAPPDATA%\\Azeroth\\Saved\\Logs")
    else
      EVAL_HELP()
    end
  end
end

-- ============ 初始化（SavedVariables 要等 VARIABLES_LOADED 才恢复） ============

local init = CreateFrame("Frame", "EVAL_HELPInitFrame", UIParent)
pcall(init.RegisterEvent, init, "VARIABLES_LOADED")
init:SetScript("OnEvent", function(a, b)
  -- 本客户端 OnEvent 参数传递有兼容差异：event 可能在第 1 参、第 2 参或全局 event
  local eventName
  if type(a) == "string" then eventName = a
  elseif type(b) == "string" then eventName = b
  elseif type(event) == "string" then eventName = event end

  if eventName == "VARIABLES_LOADED" then
    cfg = EVAL_HELP_CONFIG or {}
    EVAL_HELP_CONFIG = cfg
    ehResolveLang() -- 1.34.0 语言解析：cfg.lang 优先 → 客户端语言自动检测
    if cfg.log  == nil then cfg.log  = true  end -- 默认写日志文件
    if cfg.auto == nil then cfg.auto = false end -- 默认不自动输出
    if cfg.wdebug == nil then cfg.wdebug = false end
    if not cfg.war then
      cfg.war = { enabled = true, attack = true } -- 1.48.0 同上
    end
    -- 小地图按钮：恢复拖到的位置（越界则清掉记忆，回到默认锚点）
    if cfg.mbPos and minimapBtn then
      pcall(minimapBtn.ClearAllPoints, minimapBtn)
      pcall(minimapBtn.SetPoint, minimapBtn, cfg.mbPos.point, UIParent,
        cfg.mbPos.relPoint or cfg.mbPos.point, cfg.mbPos.x or 0, cfg.mbPos.y or 0)
      if uiOffscreen(minimapBtn) then
        cfg.mbPos = nil
        pcall(minimapBtn.ClearAllPoints, minimapBtn)
        if type(Minimap) == "table" or type(Minimap) == "userdata" then
          pcall(minimapBtn.SetPoint, minimapBtn, "TOPRIGHT", Minimap, "TOPLEFT", -6, 0)
        else
          pcall(minimapBtn.SetPoint, minimapBtn, "TOPRIGHT", UIParent, "TOPRIGHT", -8, -8)
        end
      end
    end
    -- 战斗信息UI：上次开着的话恢复显示
    if cfg.ui and cfg.ui.enabled then
      EVAL_HELP_UI_BUILD()
      if ui.root then ui.root:Show() end
    end
    -- 状态信息UI：上次开着的话恢复显示
    if cfg.st and cfg.st.enabled then
      EVAL_HELP_ST_BUILD()
      if stui.root then stui.root:Show() end
    end
    -- 注册进出战斗事件（pcall 防御：事件名若不存在不会崩）
    pcall(autoFrame.RegisterEvent, autoFrame, "PLAYER_REGEN_DISABLED")
    pcall(autoFrame.RegisterEvent, autoFrame, "PLAYER_REGEN_ENABLED")
    pcall(autoFrame.RegisterEvent, autoFrame, "PLAYER_TARGET_CHANGED") -- Cat：目标切换时刷新可流血等状态
    pcall(autoFrame.RegisterEvent, autoFrame, "CHAT_MSG_SPELL_SELF_DAMAGE") -- 1.36.0 免疫学习器（探针实测事件名）
    pcall(autoFrame.RegisterEvent, autoFrame, "CHAT_MSG_COMBAT_SELF_HITS") -- 1.55.0 挥击计时锚点（事件名不存在则静默无效）
    -- 1.38.0 施法中跟踪（1.12 无 UnitCastingInfo，只能走 SPELLCAST_* 事件；不存在则静默无效）
    for _, ev2 in ipairs({ "SPELLCAST_START", "SPELLCAST_STOP", "SPELLCAST_FAILED", "SPELLCAST_INTERRUPTED", "SPELLCAST_DELAYED", "SPELLCAST_CHANNEL_START", "SPELLCAST_CHANNEL_STOP" }) do
      pcall(autoFrame.RegisterEvent, autoFrame, ev2)
    end
    -- 1.40.0 目标施法跟踪（探针实测事件）：生物施法文字走 CHAT_MSG_SPELL_CREATURE_VS_* 频道
    pcall(autoFrame.RegisterEvent, autoFrame, "CHAT_MSG_SPELL_CREATURE_VS_SELF_DAMAGE")
    pcall(autoFrame.RegisterEvent, autoFrame, "CHAT_MSG_SPELL_CREATURE_VS_CREATURE_DAMAGE")
    pcall(autoFrame.RegisterEvent, autoFrame, "CHAT_MSG_SPELL_CREATURE_VS_SELF_BUFF")
    autoFrame:SetScript("OnEvent", function(ea, eb)
      local en
      if type(ea) == "string" then en = ea
      elseif type(eb) == "string" then en = eb
      elseif type(event) == "string" then en = event end
      if en == "PLAYER_REGEN_DISABLED" then
        EVAL_HELP_STATE.combatStart = GetTime() -- 精确进战时间（Cat 的 MPInCombatTime）
        onCombatEvent(true)
      elseif en == "PLAYER_REGEN_ENABLED" then
        EVAL_HELP_STATE.combatStart = nil
        onCombatEvent(false)
      elseif en == "PLAYER_TARGET_CHANGED" then
        EVAL_HELP_UPDATE_STATE()
      elseif en == "CHAT_MSG_SPELL_SELF_DAMAGE" then
        -- 消息文本取全局 arg1；ea/eb 若承载事件名则不当消息用（三态兼容）
        local msgT = (type(arg1) == "string" and arg1) or ((type(ea) == "string" and ea ~= en) and ea) or (type(eb) == "string" and eb)
        if msgT then EVAL_IMMUNE_LEARN(msgT) end
      elseif en == "CHAT_MSG_COMBAT_SELF_HITS" then
        -- 1.55.0 挥击计时：平砍命中锚定 lastSwing（三态兼容取消息文本）
        local msgS = (type(arg1) == "string" and arg1) or ((type(ea) == "string" and ea ~= en) and ea) or (type(eb) == "string" and eb ~= en and eb) or nil
        if msgS then EVAL_SWING_EVENT(msgS) end
      -- 1.38.0 施法中跟踪：参数顺序做启发式——字符串=技能名、数字=时长ms（CHANNEL_START 的顺序与 START 相反）
      elseif en == "SPELLCAST_START" or en == "SPELLCAST_CHANNEL_START" then
        local a1, a2 = arg1, arg2
        local nm = (type(a1) == "string" and a1) or (type(a2) == "string" and a2) or nil
        local dur = (type(a1) == "number" and a1) or (type(a2) == "number" and a2) or 0
        st.castName = nm or "?"
        st.castStart = GetTime() -- 1.38.1 读条起点（进度=剩余/总时长）
        st.castUntil = (dur > 0) and (GetTime() + dur / 1000) or nil
      elseif en == "SPELLCAST_STOP" or en == "SPELLCAST_FAILED" or en == "SPELLCAST_INTERRUPTED" or en == "SPELLCAST_CHANNEL_STOP" then
        st.castName, st.castUntil = nil, nil
      elseif en == "SPELLCAST_DELAYED" then
        local d = (type(arg1) == "number" and arg1) or 0
        if st.castName and st.castUntil then st.castUntil = st.castUntil + d / 1000 end
      -- 1.40.0 目标施法：「X开始施放Y。」开始（X=当前目标才记）/「Y击中你/对你造成」结束并学习总时长
      elseif en == "CHAT_MSG_SPELL_CREATURE_VS_SELF_DAMAGE" or en == "CHAT_MSG_SPELL_CREATURE_VS_CREATURE_DAMAGE" or en == "CHAT_MSG_SPELL_CREATURE_VS_SELF_BUFF" then
        local msgT = (type(arg1) == "string" and arg1) or ((type(ea) == "string" and ea ~= en) and ea) or (type(eb) == "string" and eb)
        if msgT then EVAL_TCAST_EVENT(msgT) end
      end
    end)
    say("全职业施法工具 " .. VERSION .. "（通用一键宏） — 一键宏 /run EVAL_GO() | /eh cfg 配置 | /eh help 帮助")
  end
end)